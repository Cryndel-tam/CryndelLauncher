!macro customHeader
  BrandingText "Cryndel Launcher · Установщик"
!macroend
