const fs = require('fs-extra');
const path = require('path');
const AdmZip = require('adm-zip');

function pickTomlString(block, key) {
  const re = new RegExp(`${key}\\s*=\\s*"([^"]+)"`);
  const m = block.match(re);
  return m ? m[1] : null;
}

class JarMetaProbe {
  async inspect(filePath) {
    const abs = path.resolve(filePath);
    const exists = await fs.pathExists(abs);
    if (!exists) {
      return { id: path.basename(abs, '.jar'), name: path.basename(abs), loader: 'unknown', version: null };
    }
    try {
      const zip = new AdmZip(abs);
      const fabric = zip.getEntry('fabric.mod.json');
      if (fabric) {
        const json = JSON.parse(fabric.getData().toString('utf8'));
        return {
          id: json.id || json.modid,
          name: json.name || json.id,
          version: json.version || null,
          loader: 'fabric',
          depends: json.depends || {},
          authors: json.authors || []
        };
      }
      const quilt = zip.getEntry('quilt.mod.json');
      if (quilt) {
        const json = JSON.parse(quilt.getData().toString('utf8'));
        const q = json.quilt_loader || json;
        return {
          id: (q.id) || json.id,
          name: (q.metadata && q.metadata.name) || q.id,
          version: q.version || null,
          loader: 'quilt',
          depends: (q.depends) || {},
          authors: []
        };
      }
      const toml = zip.getEntry('META-INF/mods.toml') || zip.getEntry('META-INF/neoforge.mods.toml');
      if (toml) {
        const text = toml.getData().toString('utf8');
        const first = text.split('[[mods]]')[1] || text;
        return {
          id: pickTomlString(first, 'modId') || path.basename(abs, '.jar'),
          name: pickTomlString(first, 'displayName') || pickTomlString(first, 'modId'),
          version: pickTomlString(first, 'version'),
          loader: zip.getEntry('META-INF/neoforge.mods.toml') ? 'neoforge' : 'forge',
          depends: {},
          authors: []
        };
      }
    } catch (_) {
      /* unreadable jar */
    }
    return {
      id: path.basename(abs, '.jar').replace(/\.disabled$/i, ''),
      name: path.basename(abs),
      version: null,
      loader: 'unknown',
      depends: {},
      authors: []
    };
  }
}

module.exports = new JarMetaProbe();
