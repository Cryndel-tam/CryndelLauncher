const fs = require('fs');
const path = require('path');

function resourcePath(name, options = {}) {
  const app = options.app || null;
  const existsSync = options.existsSync || fs.existsSync;
  const candidates = [];

  if (options.resourcesPath || process.resourcesPath) {
    candidates.push(path.join(options.resourcesPath || process.resourcesPath, 'resources', name));
  }
  if (app && typeof app.getAppPath === 'function') {
    try {
      candidates.push(path.join(app.getAppPath(), 'resources', name));
    } catch (_) {
      // The source-tree candidate remains available before Electron is ready.
    }
  }
  candidates.push(path.resolve(__dirname, '..', '..', 'resources', name));

  return candidates.find((candidate) => existsSync(candidate)) || candidates[0];
}

module.exports = resourcePath;
