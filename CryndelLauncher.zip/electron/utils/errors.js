class CryndelFault extends Error {
  constructor(code, message, details) {
    super(message);
    this.name = 'CryndelFault';
    this.code = code;
    this.details = details || null;
  }

  toJSON() {
    return { code: this.code, message: this.message, details: this.details };
  }
}

const FaultCodes = {
  AUTH: 'AUTH_FAULT',
  INSTANCE: 'INSTANCE_FAULT',
  MODRINTH: 'MODRINTH_FAULT',
  MOD: 'MOD_FAULT',
  LAUNCH: 'LAUNCH_FAULT',
  STORAGE: 'STORAGE_FAULT',
  JAVA: 'JAVA_FAULT',
  NETWORK: 'NETWORK_FAULT',
  VALIDATION: 'VALIDATION_FAULT'
};

function wrapFault(code, err) {
  if (err instanceof CryndelFault) return err;
  return new CryndelFault(code, err && err.message ? err.message : String(err));
}

module.exports = { CryndelFault, FaultCodes, wrapFault };
