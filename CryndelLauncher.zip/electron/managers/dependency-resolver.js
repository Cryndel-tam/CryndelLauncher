const logger = require('../utils/logger');

class WeavePlanner {
  constructor(modrinth, modManager) {
    this.modrinth = modrinth;
    this.modManager = modManager;
  }

  async resolveAndInstall(instanceId, versionId, visited = new Set(), extras = {}) {
    if (visited.has(versionId)) return { installed: [], optional: [], incompatible: [] };
    visited.add(versionId);

    const version = await this.modrinth.getVersion(versionId);
    const installed = [];
    const primaryFile = (version.files || []).find((f) => f.primary) || (version.files || [])[0];
    if (!primaryFile) {
      logger.warn('version has no files', { versionId });
      return { installed: [], optional: [], incompatible: [] };
    }

    await this.modManager.downloadAndPlace(
      instanceId,
      primaryFile.url,
      primaryFile.filename,
      version.project_id,
      versionId,
      primaryFile.hashes && primaryFile.hashes.sha512,
      {
        versionNumber: version.version_number,
        size: primaryFile.size,
        downloadUrl: primaryFile.url,
        loaders: version.loaders,
        gameVersions: version.game_versions
      }
    );

    installed.push({
      projectId: version.project_id,
      versionId,
      filename: primaryFile.filename,
      versionNumber: version.version_number
    });

    const optional = [];
    const incompatible = [];
    for (const dep of version.dependencies || []) {
      if (dep.dependency_type === 'optional') {
        optional.push(dep);
        continue;
      }
      if (dep.dependency_type === 'incompatible') {
        incompatible.push(dep);
        continue;
      }
      if (dep.dependency_type === 'embedded') continue;
      if (dep.dependency_type !== 'required') continue;

      let nestedVersionId = dep.version_id;
      if (!nestedVersionId && dep.project_id) {
        const versions = await this.modrinth.getProjectVersions(dep.project_id, {
          loader: extras.loader,
          mcVersion: extras.mcVersion
        });
        nestedVersionId = versions && versions[0] && versions[0].id;
      }
      if (!nestedVersionId) continue;
      const nested = await this.resolveAndInstall(instanceId, nestedVersionId, visited, extras);
      installed.push(...this.flatten(nested));
      if (nested && nested.optional) optional.push(...nested.optional);
      if (nested && nested.incompatible) incompatible.push(...nested.incompatible);
    }

    return { installed, optional, incompatible };
  }

  flatten(result) {
    if (Array.isArray(result)) return result;
    return result.installed || [];
  }
}

module.exports = WeavePlanner;
