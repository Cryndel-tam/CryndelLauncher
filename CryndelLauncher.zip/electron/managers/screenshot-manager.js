const fs = require('fs-extra');
const path = require('path');
const { shell } = require('electron');
const vault = require('../storage/json-db');
const CryndelPathVault = require('../utils/paths');

class FrameLedger {
  constructor() {
    this.watchers = [];
  }

  indexFile() {
    return CryndelPathVault.screenshotsIndex();
  }

  async list(limit, instances) {
    const shots = [];
    for (const inst of instances || []) {
      const dir = path.join(inst.gameDir, 'screenshots');
      if (!(await fs.pathExists(dir))) continue;
      const names = await fs.readdir(dir);
      for (const n of names) {
        if (!/\.(png|jpg|jpeg)$/i.test(n)) continue;
        const full = path.join(dir, n);
        const st = await fs.stat(full);
        shots.push({
          path: full,
          name: n,
          instanceId: inst.id,
          instanceName: inst.name,
          mtime: st.mtime.toISOString(),
          size: st.size
        });
      }
    }
    shots.sort((a, b) => (a.mtime < b.mtime ? 1 : -1));
    const sliced = typeof limit === 'number' ? shots.slice(0, limit) : shots;
    await vault.write(this.indexFile(), { version: 1, items: sliced.slice(0, 200) });
    return sliced;
  }

  async open(filePath) {
    return shell.openPath(filePath);
  }

  async openFolder(filePath) {
    shell.showItemInFolder(filePath);
    return { ok: true };
  }
}

module.exports = FrameLedger;
