const logger = require('../utils/logger');

// App ID для Rich Presence задаётся разработчиком в этой константе.
const DEFAULT_APP_ID = '1415814312852848681';
const RETRY_DELAYS = [2000, 8000, 20000, 60000];

class PresenceBeacon {
  constructor(appId) {
    this.client = null;
    this.ready = false;
    this.clientId = appId || DEFAULT_APP_ID;
    this.enabled = true;
    this.retryTimer = null;
    this.retryIndex = 0;
    this.activity = null;
    this.lastError = '';
  }

  get needsAppId() {
    return !String(this.clientId || '').trim();
  }

  scheduleRetry() {
    // Nothing to retry against without a real application id.
    if (!this.enabled || this.retryTimer || this.needsAppId) return;
    const delay = RETRY_DELAYS[Math.min(this.retryIndex, RETRY_DELAYS.length - 1)];
    this.retryIndex += 1;
    this.retryTimer = setTimeout(() => {
      this.retryTimer = null;
      this.connect().catch(() => { /* retried again */ });
    }, delay);
  }

  async connect(appId) {
    this.enabled = true;
    if (appId) this.clientId = appId;
    // Without a real application id the RPC library logs in against a bogus app
    // and Discord drops the connection, so the presence never appears. Bail out
    // early with a clear reason instead of retrying forever.
    if (this.needsAppId) {
      this.ready = false;
      this.lastError = 'Не задан Discord App ID в исходном коде лаунчера';
      return { ok: false, ready: false, error: this.lastError, needsAppId: true };
    }
    try {
      const RPC = require('discord-rpc');
      if (this.client) {
        try { await this.client.destroy(); } catch (_) { /* */ }
        this.client = null;
        this.ready = false;
      }
      const client = new RPC.Client({ transport: 'ipc' });
      this.client = client;
      client.on('ready', () => {
        this.ready = true;
        this.retryIndex = 0;
        logger.info('discord rpc ready');
        this.applyActivity(this.activity || {
          details: 'Cryndel Launcher',
          state: 'В лаунчере',
          startTimestamp: Date.now(),
          largeImageKey: 'cryndel',
          largeImageText: 'Cryndel Launcher'
        });
      });
      client.on('disconnected', () => {
        this.ready = false;
        this.client = null;
        // Discord may not be running yet; keep trying quietly.
        this.scheduleRetry();
      });
      await client.login({ clientId: this.clientId }).catch((err) => {
        this.lastError = err.message || String(err);
        logger.debug('discord rpc login failed', { message: this.lastError });
        this.scheduleRetry();
      });
    } catch (err) {
      this.lastError = err.message || String(err);
      logger.debug('discord rpc skipped', { message: this.lastError });
      this.scheduleRetry();
    }
  }

  async applyActivity(activity) {
    this.activity = activity;
    if (!this.ready || !this.client) return;
    try {
      await this.client.setActivity(activity);
    } catch (_) { /* rpc optional */ }
  }

  async disconnect() {
    this.enabled = false;
    this.ready = false;
    if (this.retryTimer) {
      clearTimeout(this.retryTimer);
      this.retryTimer = null;
    }
    if (!this.client) return;
    try { await this.client.clearActivity(); } catch (_) { /* */ }
    try { await this.client.destroy(); } catch (_) { /* */ }
    this.client = null;
  }

  async setPlaying(instance, _user) {
    this.enabled = true;
    if (!this.ready || !this.client) {
      this.scheduleRetry();
      return;
    }
    try {
      await this.applyActivity({
        details: instance ? instance.name : 'Cryndel',
        state: instance ? `${instance.mcVersion} · ${instance.modLoader}` : 'In launcher',
        startTimestamp: Date.now(),
        largeImageKey: 'cryndel',
        largeImageText: 'Cryndel Launcher',
        buttons: instance && instance.quickPlay && instance.quickPlay.enabled
          ? [{ label: 'Join Cryndel', url: 'https://ms.cryndel.ru' }]
          : undefined
      });
    } catch (_) { /* rpc optional */ }
  }

  async clear() {
    if (!this.ready || !this.client) return;
    this.activity = null;
    try {
      await this.applyActivity({
        details: 'Cryndel Launcher',
        state: 'В лаунчере',
        startTimestamp: Date.now(),
        largeImageKey: 'cryndel',
        largeImageText: 'Cryndel Launcher'
      });
    } catch (_) { /* rpc optional */ }
  }
}

module.exports = PresenceBeacon;
