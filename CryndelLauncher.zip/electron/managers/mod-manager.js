const fs = require('fs-extra');
const path = require('path');
const crypto = require('crypto');
const { dialog } = require('electron');
const CryndelPathVault = require('../utils/paths');
const { sanitizeName } = require('./download-manager');
const jarMeta = require('../utils/mod-file-parser');
const security = require('../utils/mod-security');
const logger = require('../utils/logger');

async function placeBeside(src, dest) {
  const from = path.resolve(src);
  const to = path.resolve(dest);
  if (from === to) return to;
  await fs.ensureDir(path.dirname(to));
  if (await fs.pathExists(to)) {
    try {
      const a = await fs.stat(from);
      const b = await fs.stat(to);
      if (a.ino && b.ino && a.ino === b.ino && a.dev === b.dev) return to;
    } catch (_) { /* copy anyway */ }
    await fs.remove(to);
  }
  try {
    await fs.link(from, to);
  } catch (_) {
    await fs.copy(from, to, { overwrite: true });
  }
  return to;
}

class CrateShepherd {
  constructor({ hauler, lockfile, modrinth, settings }) {
    this.hauler = hauler;
    this.lockfile = lockfile;
    this.modrinth = modrinth;
    this.settings = settings;
  }

  async options() {
    if (!this.settings) return {};
    try {
      return (await this.settings.getAll()).modrinth || {};
    } catch (_) {
      return {};
    }
  }

  modsDir(instanceId) {
    return path.join(CryndelPathVault.instanceDir(instanceId), 'mods');
  }

  async ensureModsDir(instanceId) {
    const dir = this.modsDir(instanceId);
    await fs.ensureDir(dir);
    return dir;
  }

  // True when the project (or a file with the same name) is already in the
  // instance, so installers can skip a duplicate download.
  async hasMod(instanceId, projectId, filename) {
    const mods = await this.listInstalled(instanceId);
    const wanted = String(projectId || '').toLowerCase();
    const wantedFile = filename ? sanitizeName(filename).toLowerCase() : '';
    return mods.some((m) => {
      if (wanted && (String(m.projectId || '').toLowerCase() === wanted || String(m.id || '').toLowerCase() === wanted)) return true;
      if (wantedFile && String(m.filename || '').toLowerCase().replace(/\.disabled$/i, '') === wantedFile) return true;
      return false;
    });
  }

  async scanJar(filePath) {
    return security.scan(filePath);
  }

  async scanInstance(instanceId) {
    const mods = await this.listInstalled(instanceId);
    const reports = [];
    for (const m of mods) {
      try {
        const r = await security.scan(m.file);
        reports.push({ ...r, filename: m.filename, name: m.name });
      } catch (err) {
        reports.push({ filename: m.filename, ok: false, error: err.message });
      }
    }
    return reports;
  }

  async downloadAndPlace(instanceId, url, filename, projectId, versionId, sha512, meta = {}) {
    const dir = await this.ensureModsDir(instanceId);
    const safe = sanitizeName(filename);
    const dest = path.join(dir, safe);
    const opt = await this.options();
    if (opt.skipDuplicates !== false && await this.hasMod(instanceId, projectId, safe)) {
      return { skipped: true, path: dest, reason: 'duplicate' };
    }
    const cached = await this.hauler.cacheModJar(url, safe, sha512);
    await placeBeside(cached.path, dest);
    const lockId = (meta.slug || projectId || path.basename(safe, '.jar')).toLowerCase();
    await this.lockfile.upsertEntry(instanceId, {
      id: lockId,
      projectId,
      versionId,
      versionNumber: meta.versionNumber || '',
      filename: safe,
      sha512: cached.sha512 || sha512 || '',
      source: 'modrinth',
      enabled: true,
      pinned: false,
      size: cached.size || meta.size || 0,
      downloadUrl: meta.downloadUrl || url,
      dependencies: meta.dependencies || []
    });
    logger.info('placed mod', { instanceId, filename: safe });
    return dest;
  }

  async installPluginMod(instanceId, source, modId, pluginId, displayName) {
    const instance = String(instanceId || '');
    if (!/^[A-Za-z0-9][\w.-]{0,63}$/.test(instance)) throw new Error('Неверная сборка');
    const file = path.resolve(String(source || ''));
    if (path.extname(file).toLowerCase() !== '.jar') throw new Error('Файл плагинного мода должен иметь расширение .jar');
    const stat = await fs.stat(file);
    if (!stat.isFile() || stat.size <= 0 || stat.size > 50 * 1024 * 1024) {
      throw new Error('Размер JAR должен быть от 1 байта до 50 МБ');
    }
    const filename = sanitizeName(`${String(modId || 'plugin-mod').slice(0, 80)}.jar`);
    const dir = await this.ensureModsDir(instance);
    const dest = path.join(dir, filename);
    if (await fs.pathExists(dest)) return { ok: false, error: 'Мод с таким файлом уже установлен' };
    const report = await security.scan(file);
    await fs.copy(file, dest);
    const bytes = await fs.readFile(dest);
    const meta = await jarMeta.inspect(dest);
    const sha512 = crypto.createHash('sha512').update(bytes).digest('hex');
    await this.lockfile.upsertEntry(instance, {
      id: String(modId || 'plugin-mod').toLowerCase(),
      projectId: null,
      versionId: null,
      versionNumber: meta.version || '',
      filename,
      sha512,
      source: `plugin:${String(pluginId || '').slice(0, 64)}`,
      enabled: true,
      pinned: true,
      size: bytes.length
    });
    return {
      ok: true,
      filename,
      name: String(meta.name || displayName || modId || filename).slice(0, 120),
      warning: report && report.risk === 'high' ? report.message : ''
    };
  }

  async listInstalled(instanceId) {
    const dir = await this.ensureModsDir(instanceId);
    const lock = await this.lockfile.load(instanceId);
    const names = await fs.readdir(dir);
    const jars = names.filter((n) => n.endsWith('.jar') || n.endsWith('.jar.disabled'));
    const byFile = new Map((lock.entries || []).map((e) => [e.filename, e]));
    const result = [];
    for (const name of jars) {
      const full = path.join(dir, name);
      const enabled = !name.endsWith('.disabled');
      const base = enabled ? name : name.replace(/\.disabled$/i, '');
      const entry = byFile.get(base) || byFile.get(name);
      let meta = null;
      try { meta = await jarMeta.inspect(full); } catch (_) { meta = null; }
      result.push({
        file: full,
        filename: name,
        enabled,
        id: (entry && entry.id) || (meta && meta.id) || base,
        projectId: entry && entry.projectId,
        versionId: entry && entry.versionId,
        versionNumber: (entry && entry.versionNumber) || (meta && meta.version),
        name: (meta && meta.name) || base,
        loader: (meta && meta.loader) || (lock.loader),
        source: (entry && entry.source) || 'local',
        pinned: Boolean(entry && entry.pinned),
        sha512: entry && entry.sha512,
        dependencies: (entry && entry.dependencies) || []
      });
    }
    return result;
  }

  async toggle(instanceId, modId, enabled) {
    const mods = await this.listInstalled(instanceId);
    const target = mods.find((m) => m.id === modId || m.filename === modId || m.projectId === modId);
    if (!target) return { ok: false };
    const dir = this.modsDir(instanceId);
    const current = path.join(dir, target.filename);
    if (enabled && target.filename.endsWith('.disabled')) {
      const next = target.filename.replace(/\.disabled$/i, '');
      await fs.move(current, path.join(dir, next), { overwrite: true });
      await this.lockfile.patchEntry(instanceId, modId, { enabled: true, filename: next });
    } else if (!enabled && !target.filename.endsWith('.disabled')) {
      const next = `${target.filename}.disabled`;
      await fs.move(current, path.join(dir, next), { overwrite: true });
      await this.lockfile.patchEntry(instanceId, modId, { enabled: false });
    }
    return { ok: true };
  }

  async remove(instanceId, modId) {
    const mods = await this.listInstalled(instanceId);
    const target = mods.find((m) => m.id === modId || m.filename === modId || m.projectId === modId);
    if (target) {
      try { await fs.remove(target.file); } catch (_) { /* gone */ }
    }
    await this.lockfile.removeEntry(instanceId, modId);
    return { ok: true };
  }

  async pin(instanceId, modId, pinned) {
    await this.lockfile.patchEntry(instanceId, modId, { pinned: Boolean(pinned) });
    return { ok: true };
  }

  async addFromFile(instanceId, parentWindow) {
    const picked = await dialog.showOpenDialog(parentWindow || undefined, {
      properties: ['openFile', 'multiSelections'],
      filters: [{ name: 'Mods', extensions: ['jar'] }]
    });
    if (picked.canceled || !picked.filePaths.length) return { ok: false, cancelled: true };
    const dir = await this.ensureModsDir(instanceId);
    const added = [];
    const skipped = [];
    const warnings = [];
    for (const src of picked.filePaths) {
      const name = sanitizeName(path.basename(src));
      const dest = path.join(dir, name);
      if (await fs.pathExists(dest)) {
        skipped.push(name);
        continue;
      }
      const report = await security.scan(src).catch(() => null);
      if (report && report.risk === 'high') {
        warnings.push({ filename: name, message: report.message, findings: report.findings });
      }
      await fs.copy(src, dest, { overwrite: true });
      const buf = await fs.readFile(dest);
      const sha512 = crypto.createHash('sha512').update(buf).digest('hex');
      const meta = await jarMeta.inspect(dest);
      await this.lockfile.upsertEntry(instanceId, {
        id: (meta.id || name).toLowerCase(),
        projectId: meta.id,
        versionId: null,
        versionNumber: meta.version,
        filename: name,
        sha512,
        source: 'file',
        enabled: true,
        size: buf.length
      });
      added.push(name);
    }
    return { ok: true, added, skipped, warnings };
  }

  async detectConflicts(instanceId) {
    const mods = await this.listInstalled(instanceId);
    const lock = await this.lockfile.load(instanceId);
    const conflicts = [];
    const byId = {};
    for (const mod of mods) {
      const key = mod.id;
      if (byId[key]) {
        conflicts.push({ type: 'duplicate', modId: key, files: [byId[key].file, mod.file] });
      } else {
        byId[key] = mod;
      }
      if (mod.loader && lock.loader && mod.loader !== 'unknown' && mod.loader !== lock.loader && mod.enabled) {
        conflicts.push({ type: 'loader', modId: key, expected: lock.loader, actual: mod.loader });
      }
    }
    for (const entry of lock.entries || []) {
      for (const dep of entry.dependencies || []) {
        const found = mods.find((m) => m.projectId === dep.projectId || m.id === dep.projectId);
        if (!found) {
          conflicts.push({ type: 'missing-dep', modId: entry.id, missing: dep.projectId });
        }
      }
    }
    return conflicts;
  }

  async verifyIntegrity(instanceId) {
    const lock = await this.lockfile.load(instanceId);
    const dir = await this.ensureModsDir(instanceId);
    const report = [];
    for (const entry of lock.entries || []) {
      const file = path.join(dir, entry.enabled === false ? `${entry.filename}.disabled` : entry.filename);
      const alt = path.join(dir, entry.filename);
      const target = (await fs.pathExists(file)) ? file : alt;
      if (!(await fs.pathExists(target))) {
        report.push({ filename: entry.filename, ok: false, reason: 'missing' });
        continue;
      }
      if (!entry.sha512) {
        report.push({ filename: entry.filename, ok: true, reason: 'no-hash' });
        continue;
      }
      const buf = await fs.readFile(target);
      const got = crypto.createHash('sha512').update(buf).digest('hex');
      report.push({ filename: entry.filename, ok: got === entry.sha512, reason: got === entry.sha512 ? 'match' : 'hash-mismatch' });
    }
    return report;
  }

  async checkAllUpdates(instanceId) {
    const lock = await this.lockfile.load(instanceId);
    const updates = [];
    for (const entry of lock.entries || []) {
      if (entry.pinned) continue;
      if (entry.source !== 'modrinth') continue;
      if (!entry.sha512) continue;
      try {
        const update = await this.modrinth.checkUpdateByHash(entry.sha512, {
          loader: lock.loader,
          mcVersion: lock.mcVersion
        });
        if (update && update.id && update.id !== entry.versionId) {
          const file = (update.files || []).find((f) => f.primary) || (update.files || [])[0];
          updates.push({
            projectId: entry.projectId,
            id: entry.id,
            currentVersion: entry.versionNumber,
            latestVersion: update.version_number,
            latestVersionId: update.id,
            changelog: update.changelog || '',
            downloadUrl: file && file.url,
            filename: file && file.filename
          });
        }
      } catch (err) {
        logger.warn('update check failed', { id: entry.id, message: err.message });
      }
    }
    return updates;
  }
}

module.exports = CrateShepherd;
