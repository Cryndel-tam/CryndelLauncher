const fs = require('fs-extra');
const path = require('path');
const vm = require('vm');
const AdmZip = require('adm-zip');
const CryndelPathVault = require('../utils/paths');
const logger = require('../utils/logger');

// Plugins are plain folders or .zip archives dropped into <userRoot>/plugins.
// Each one carries a manifest.json:
//   { "id": "hello", "name": "Hello", "version": "1.0.0", "main": "index.js",
//     "api": 1, "permissions": ["ui", "events"] }
//
// A plugin's `activate(api)` runs inside a `vm` context with only the globals we
// hand it. Everything it exports is wrapped so a throw in one plugin can never
// take down the launcher: errors are captured per plugin, surfaced as a warning
// and the rest keep running.
const PLUGIN_API_VERSION = 2;
const API_ALIAS_TARGETS = new Set([
  'log', 'warn', 'toast', 'config.get', 'config.set', 'config.all',
  'events.emit', 'instances.list', 'instances.get', 'modrinth.search',
  'modrinth.project', 'modrinth.versions', 'modrinth.version'
]);
const PLUGIN_PERMISSIONS = new Set([
  'ui', 'ui.theme', 'wallpaper', 'settings.read', 'settings.write', 'instances.read', 'net', 'downloads', 'install', 'events'
]);

class PluginForge {
  constructor(hub = {}) {
    this.hub = hub;
    this.loaded = new Map();
    this.warnings = [];
    this.hooks = new Map();
    this.disabled = new Set();
    this.schemas = new Map();
    this.navItems = [];
    this.uiPages = new Map();
    this.uiThemes = new Map();
    this.grants = new Map();
  }

  dir() {
    return CryndelPathVault.pluginsDir();
  }

  async ensure() {
    await fs.ensureDir(this.dir());
    await this.loadGrants();
    return this.dir();
  }

  grantsFile() {
    return path.join(this.dir(), '.permissions.json');
  }

  async loadGrants() {
    try {
      const entries = await fs.readJson(this.grantsFile());
      this.grants = new Map(Object.entries(entries || {}).map(([id, items]) => [
        id, Array.isArray(items) ? items.filter((item) => typeof item === 'string') : []
      ]));
    } catch (err) {
      if (err.code !== 'ENOENT') logger.warn('plugin permissions could not be loaded', { message: err.message });
      this.grants = new Map();
    }
  }

  async saveGrants() {
    await fs.writeJson(this.grantsFile(), Object.fromEntries(this.grants), { spaces: 2 });
  }

  async inspectPluginZip(zipPath) {
    const zip = new AdmZip(zipPath);
    const entry = zip.getEntries().find((item) => /(^|\/)manifest\.json$/i.test(item.entryName) && !item.isDirectory);
    if (!entry) return { ok: false, error: 'В архиве нет manifest.json' };
    let manifest;
    try { manifest = JSON.parse(entry.getData().toString('utf8')); } catch (_) {
      return { ok: false, error: 'manifest.json повреждён' };
    }
    const id = String(manifest.id || '');
    if (!/^[A-Za-z0-9][\w.-]{0,63}$/.test(id) || id === '.' || id === '..') {
      return { ok: false, error: 'В манифесте неверный id плагина' };
    }
    const permissions = Array.isArray(manifest.permissions) ? manifest.permissions.filter((p) => typeof p === 'string') : [];
    const supported = PLUGIN_PERMISSIONS;
    const unknown = permissions.filter((permission) => !supported.has(permission));
    if (unknown.length) return { ok: false, error: `Неизвестные разрешения в манифесте: ${unknown.join(', ')}` };
    return {
      ok: true,
      id,
      name: String(manifest.name || id).slice(0, 100),
      permissions
    };
  }

  apiPackDir() {
    return path.join(this.dir(), '.api');
  }

  async readApiPackFile(name, fallback) {
    const file = path.join(this.apiPackDir(), 'active', name);
    if (!await fs.pathExists(file)) return fallback;
    return fs.readJson(file);
  }

  async apiPackStatus() {
    let manifest = null;
    let error = '';
    try {
      manifest = await this.readApiPackFile('manifest.json', null);
      if (manifest) {
        if (manifest.type !== 'cryndel-plugin-api' || typeof manifest.version !== 'string') {
          throw new Error('manifest.json пакета API имеет неверный формат');
        }
        const api = await this.readApiPackFile('api.json', null);
        if (!api || !api.aliases || typeof api.aliases !== 'object' || Array.isArray(api.aliases)) {
          throw new Error('api.json отсутствует или имеет неверную структуру');
        }
        if (Object.keys(api.aliases).length > 100) throw new Error('Слишком много псевдонимов API');
        for (const [name, target] of Object.entries(api.aliases)) {
          if (!/^[a-z][a-zA-Z0-9]{1,31}$/.test(name) || !API_ALIAS_TARGETS.has(target)) {
            throw new Error(`Недопустимое расширение API: ${name}`);
          }
        }
      }
    } catch (err) { error = err.message; }
    let previous = null;
    try { previous = await fs.readJson(path.join(this.apiPackDir(), 'previous', 'manifest.json')); } catch (_) { /* No previous package. */ }
    return {
      installed: Boolean(manifest),
      version: manifest && manifest.version || 'Встроенная',
      previousVersion: previous && previous.version || '',
      resetUsed: await fs.pathExists(path.join(this.apiPackDir(), 'reset-used')),
      error
    };
  }

  validateApiPack(zip) {
    const entries = zip.getEntries();
    if (!entries.length || entries.length > 3) return { error: 'В пакете должно быть не более трёх файлов' };
    const files = entries.filter((entry) => !entry.isDirectory);
    if (files.length !== 2 || files.some((entry) => !['manifest.json', 'api.json'].includes(entry.entryName))) {
      return { error: 'Пакет должен содержать только manifest.json и api.json в корне' };
    }
    if (files.reduce((sum, entry) => sum + Number(entry.header.size || 0), 0) > 1024 * 1024) {
      return { error: 'Размер API-пакета превышает 1 МБ' };
    }
    let manifest;
    let api;
    try {
      manifest = JSON.parse(zip.readAsText('manifest.json'));
      api = JSON.parse(zip.readAsText('api.json'));
    } catch (_) {
      return { error: 'manifest.json или api.json повреждён' };
    }
    if (!manifest || manifest.type !== 'cryndel-plugin-api' || typeof manifest.version !== 'string'
      || !/^[\w.+-]{1,32}$/.test(manifest.version)) {
      return { error: 'Неверный формат manifest.json для API-пакета' };
    }
    const aliases = api && api.aliases;
    if (!aliases || typeof aliases !== 'object' || Array.isArray(aliases)
      || Object.keys(aliases).length > 100) {
      return { error: 'api.json должен содержать объект aliases (не более 100 записей)' };
    }
    for (const [name, target] of Object.entries(aliases)) {
      if (!/^[a-z][a-zA-Z0-9]{1,31}$/.test(name) || !API_ALIAS_TARGETS.has(target)) return { error: `Недопустимое расширение API: ${name}` };
    }
    return { manifest: { type: manifest.type, version: manifest.version, name: String(manifest.name || 'API-пакет').slice(0, 80) }, api: { aliases } };
  }

  async installApiPackFromZip(zipPath) {
    const stat = await fs.stat(zipPath);
    if (stat.size > 1024 * 1024) return { ok: false, error: 'Размер .PLcryn превышает 1 МБ' };
    const zip = new AdmZip(zipPath);
    const checked = this.validateApiPack(zip);
    if (checked.error) return { ok: false, error: checked.error };
    const root = this.apiPackDir();
    const active = path.join(root, 'active');
    const previous = path.join(root, 'previous');
    const staging = path.join(root, 'active-next');
    await fs.ensureDir(root);
    await fs.remove(staging);
    await fs.ensureDir(staging);
    await fs.writeJson(path.join(staging, 'manifest.json'), checked.manifest, { spaces: 2 });
    await fs.writeJson(path.join(staging, 'api.json'), checked.api, { spaces: 2 });
    await fs.remove(previous);
    if (await fs.pathExists(active)) await fs.rename(active, previous);
    try {
      await fs.rename(staging, active);
    } catch (err) {
      if (await fs.pathExists(previous) && !await fs.pathExists(active)) await fs.rename(previous, active);
      throw err;
    }
    await fs.remove(path.join(root, 'reset-used'));
    return { ok: true, version: checked.manifest.version };
  }

  async rollbackApiPack() {
    const root = this.apiPackDir();
    const active = path.join(root, 'active');
    const previous = path.join(root, 'previous');
    const staging = path.join(root, 'api-swap');
    if (!await fs.pathExists(previous)) return { ok: false, error: 'Предыдущей версии API нет' };
    await fs.remove(staging);
    if (await fs.pathExists(active)) await fs.rename(active, staging);
    await fs.rename(previous, active);
    if (await fs.pathExists(staging)) await fs.rename(staging, previous);
    await fs.remove(path.join(root, 'reset-used'));
    return { ok: true, status: await this.apiPackStatus() };
  }

  async resetApiPack() {
    const root = this.apiPackDir();
    const active = path.join(root, 'active');
    const previous = path.join(root, 'previous');
    const resetMarker = path.join(root, 'reset-used');
    if (await fs.pathExists(resetMarker)) {
      await fs.remove(active);
      await fs.remove(previous);
      await fs.remove(resetMarker);
      return { ok: true, version: 'Встроенная' };
    }
    if (await fs.pathExists(previous)) {
      const result = await this.rollbackApiPack();
      if (!result.ok) return result;
      await fs.writeFile(resetMarker, 'previous-restored', 'utf8');
      return { ok: true, version: result.status.version, restoredPrevious: true };
    }
    await fs.remove(active);
    return { ok: true, version: 'Встроенная' };
  }

    getUiContributions() {
      const pages = [];
      for (const [pluginId, items] of this.uiPages) {
        for (const item of items.values()) pages.push({ ...item, pluginId });
      }
      return {
        pages,
        themes: [...this.uiThemes.entries()].map(([pluginId, css]) => ({
          pluginId,
          css
        }))
      };
    }

    getPluginMods() {
      const result = [];
      for (const [pluginId, loaded] of this.loaded) {
        if (!this.hasPermission(pluginId, 'install')) continue;
        const items = Array.isArray(loaded.manifest.providedMods) ? loaded.manifest.providedMods : [];
        for (const item of items.slice(0, 40)) {
          if (!item || !/^[a-z0-9][a-z0-9_.-]{0,63}$/i.test(String(item.id || ''))) continue;
          const file = String(item.file || '');
          if (!file || path.isAbsolute(file) || file.split(/[\\/]/).some((part) => part === '..')) continue;
          result.push({
            pluginId,
            id: String(item.id),
            name: String(item.name || item.id).slice(0, 100),
            version: String(item.version || '').slice(0, 40),
            description: String(item.description || '').slice(0, 500),
            loaders: Array.isArray(item.loaders) ? item.loaders.filter((value) => typeof value === 'string').slice(0, 8).map((value) => value.toLowerCase()) : [],
            gameVersions: Array.isArray(item.gameVersions) ? item.gameVersions.filter((value) => typeof value === 'string').slice(0, 30) : [],
            iconSvg: String(item.iconSvg || '').slice(0, 8192)
          });
        }
      }
      return result;
    }

    registerUiPage(pluginId, page) {
      if (!this.hasPermission(pluginId, 'ui')) throw new Error('Плагину не выдано разрешение ui');
      const pageId = String(page && page.id || '');
      if (!page || !/^[a-z][\w.-]{1,47}$/i.test(pageId)) throw new Error('Неверный ID страницы плагина');
      const html = String(page.html || '');
      const css = String(page.css || '');
      if (html.length > 256 * 1024 || css.length > 128 * 1024) throw new Error('Размер страницы плагина превышает лимит');
      const pages = this.uiPages.get(pluginId) || new Map();
      if (!pages.has(pageId) && pages.size >= 12) throw new Error('Плагин может зарегистрировать не более 12 страниц');
      pages.set(pageId, {
        id: pageId,
        title: String(page.title || pageId).slice(0, 64),
        icon: /^[a-z]+$/.test(String(page.icon || 'page')) ? String(page.icon || 'page') : 'page',
        iconSvg: String(page.iconSvg || '').slice(0, 8192),
        homeButton: page.homeButton === true,
        html,
        css
      });
      this.uiPages.set(pluginId, pages);
      if (typeof this.hub.uiChanged === 'function') this.hub.uiChanged();
    }

    setPluginTheme(pluginId, css) {
      if (!this.hasPermission(pluginId, 'ui.theme')) throw new Error('Плагину не выдано разрешение ui.theme');
      const source = String(css || '');
      if (source.length > 128 * 1024) throw new Error('CSS темы превышает 128 КБ');
      if (/@import\b|url\s*\(|expression\s*\(|javascript\s*:/i.test(source)) {
        throw new Error('CSS темы не должен загружать внешние ресурсы или код');
      }
      this.uiThemes = this.uiThemes || new Map();
      if (source) this.uiThemes.set(pluginId, source);
      else this.uiThemes.delete(pluginId);
      if (typeof this.hub.uiChanged === 'function') this.hub.uiChanged();
      return { ok: true };
    }

    hasPermission(pluginId, permission) {
      if (!this.grants.has(pluginId)) return false;
      return this.grants.get(pluginId).includes(permission);
    }

    async setPermissions(pluginId, permissions) {
      if (!/^[A-Za-z0-9][\w.-]{0,63}$/.test(pluginId) || pluginId === '.' || pluginId === '..') {
        throw new Error('Неверный ID плагина');
      }
      const manifest = await fs.readJson(path.join(this.dir(), pluginId, 'manifest.json'));
      const declared = new Set(Array.isArray(manifest.permissions) ? manifest.permissions : []);
      if (!Array.isArray(permissions) || permissions.some((permission) => !declared.has(permission))) {
        throw new Error('Можно выдать только разрешения, перечисленные в манифесте плагина');
      }
      this.grants.set(pluginId, [...new Set(permissions)]);
      await this.saveGrants();
      return { ok: true, grantedPermissions: this.grants.get(pluginId) };
    }

    async callCapability(pluginId, method, args = []) {
      if (!Array.isArray(args) || args.length > 10) throw new Error('Недопустимые аргументы API');
      let serialized;
      try { serialized = JSON.stringify(args); } catch (_) { throw new Error('Аргументы API должны быть JSON-совместимыми'); }
      if (Buffer.byteLength(serialized) > 256 * 1024) throw new Error('Размер аргументов API превышает 256 КБ');
      const loaded = this.loaded.get(pluginId);
      if (!loaded) throw new Error('Плагин не активен');
      const requirePermission = (permission) => {
        if (!this.hasPermission(pluginId, permission)) throw new Error(`Не выдано разрешение: ${permission}`);
      };
      if (method === 'ui.toast') {
        loaded.api.ui.toast(args[0], args[1]);
        return { ok: true };
      }
      if (method === 'plugin.config.get') {
        return loaded.api.config.get(args[0], args[1]);
      }
      if (method === 'plugin.config.set') {
        return loaded.api.config.set(args[0], args[1]);
      }
      if (method === 'settings.get') {
        requirePermission('settings.read');
        const key = String(args[0] || '');
        if (!/^(ui|launcher|browser)(\.|$)/.test(key)) throw new Error('Этот раздел настроек недоступен плагинам');
        return this.hub.settings.get(key);
      }
      if (method === 'settings.set') {
        requirePermission('settings.write');
        const key = String(args[0] || '');
        if (!/^(ui|launcher|browser)\.[\w.-]+$/.test(key)) throw new Error('Недопустимый ключ настройки');
        if (key.split('.').some((part) => ['__proto__', 'prototype', 'constructor'].includes(part))) {
          throw new Error('Недопустимый ключ настройки');
        }
        await this.hub.settings.set(key, args[1]);
        if (typeof this.hub.settingChanged === 'function') await this.hub.settingChanged(key, args[1]);
        return { ok: true };
      }
      if (method === 'instances.list') {
        requirePermission('instances.read');
        return this.hub.instances ? this.hub.instances.list() : [];
      }
      if (method === 'instances.get') {
        requirePermission('instances.read');
        return this.hub.instances ? this.hub.instances.get(String(args[0] || '')) : null;
      }
      if (method === 'modrinth.search') {
        requirePermission('net');
        const options = args[0] || {};
        return this.hub.modrinth.search({
          ...options,
          limit: Math.min(50, Math.max(1, Number(options.limit) || 20)),
          offset: Math.max(0, Number(options.offset) || 0)
        });
      }
      if (method === 'modrinth.project') {
        requirePermission('net');
        return this.hub.modrinth.getProject(String(args[0] || ''));
      }
      if (method === 'modrinth.versions') {
        requirePermission('net');
        return this.hub.modrinth.getProjectVersions(String(args[0] || ''), args[1] || {});
      }
      if (method === 'net.fetch') {
        requirePermission('net');
        const url = new URL(String(args[0] || ''));
        if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Разрешены только HTTP и HTTPS ссылки');
        const opts = args[1] || {};
        const methodName = String(opts.method || 'GET').toUpperCase();
        if (!['GET', 'POST'].includes(methodName)) throw new Error('Plugin API разрешает только GET и POST');
        const body = opts.data;
        if (body != null && Buffer.byteLength(typeof body === 'string' ? body : JSON.stringify(body)) > 64 * 1024) {
          throw new Error('Размер запроса превышает 64 КБ');
        }
        const axios = require('axios');
        const response = await axios({
          url: url.href,
          method: methodName,
          data: body,
          headers: opts.headers && typeof opts.headers === 'object' ? opts.headers : undefined,
          timeout: 15000,
          maxContentLength: 1024 * 1024,
          maxBodyLength: 64 * 1024
        });
        return { ok: true, status: response.status, data: response.data };
      }
      if (method === 'downloads.save') {
        requirePermission('downloads');
        const url = new URL(String(args[0] || ''));
        if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Разрешены только HTTP и HTTPS ссылки');
        const axios = require('axios');
        const response = await axios.get(url.href, {
          responseType: 'arraybuffer',
          timeout: 60000,
          maxContentLength: 50 * 1024 * 1024,
          maxBodyLength: 50 * 1024 * 1024
        });
        const name = String(args[1] || path.basename(url.pathname) || 'plugin-download').slice(0, 150);
        const saved = await this.hub.inbox.saveBuffer(name, Buffer.from(response.data));
        return { ok: true, name: path.basename(saved) };
      }
      if (method === 'ui.setTheme') {
        return this.setPluginTheme(pluginId, args[0]);
      }
      if (method === 'wallpaper.set') {
        requirePermission('wallpaper');
        const relative = String(args[0] || '');
        const ownDir = path.join(this.dir(), pluginId);
        const source = path.resolve(ownDir, relative);
        const rel = path.relative(ownDir, source);
        if (!relative || rel.startsWith('..') || path.isAbsolute(rel) || path.extname(source).toLowerCase() !== '.svg') {
          throw new Error('Обои должны быть SVG-файлом внутри папки плагина');
        }
        const stat = await fs.stat(source);
        if (!stat.isFile() || stat.size > 256 * 1024) throw new Error('SVG обоев превышает лимит 256 КБ');
        const realOwnDir = await fs.realpath(ownDir);
        const realSource = await fs.realpath(source);
        const realRelative = path.relative(realOwnDir, realSource);
        if (realRelative.startsWith('..') || path.isAbsolute(realRelative)) throw new Error('SVG обоев не может быть символической ссылкой за пределы папки плагина');
        const svgText = await fs.readFile(source, 'utf8');
        const tags = [...svgText.matchAll(/<\/?([a-z][a-z0-9:-]*)\b/gi)].map((match) => match[1].toLowerCase());
        const allowedTags = new Set(['svg', 'g', 'path', 'rect', 'circle', 'ellipse', 'polygon', 'polyline', 'line', 'defs', 'lineargradient', 'radialgradient', 'stop']);
        const attributes = [...svgText.matchAll(/\s+([a-z_:][\w:.-]*)\s*=/gi)].map((match) => match[1].toLowerCase());
        const allowedAttributes = new Set([
          'xmlns', 'viewbox', 'width', 'height', 'id', 'x', 'y', 'cx', 'cy', 'r', 'rx', 'ry',
          'x1', 'x2', 'y1', 'y2', 'd', 'points', 'fill', 'fill-opacity', 'fill-rule',
          'stroke', 'stroke-width', 'stroke-opacity', 'stroke-linecap', 'stroke-linejoin',
          'opacity', 'offset', 'stop-color', 'stop-opacity'
        ]);
        if (!/^\s*<svg[\s>]/i.test(svgText) || !tags.length
          || tags.some((tag) => !allowedTags.has(tag))
          || attributes.some((attribute) => !allowedAttributes.has(attribute))
          || /<\?(?!xml\b)|xml-stylesheet|url\s*\(|javascript\s*:|<!DOCTYPE|<!ENTITY/i.test(svgText)) {
          throw new Error('SVG обоев содержит неподдерживаемые элементы');
        }
        const dest = path.join(CryndelPathVault.dataDir(), 'plugin-wallpapers', `${pluginId}.svg`);
        await fs.ensureDir(path.dirname(dest));
        await fs.writeFile(dest, svgText, 'utf8');
        await this.hub.settings.set('ui.backgroundFile', dest);
        await this.hub.settings.set('ui.backgroundKind', 'image');
        await this.hub.settings.set('ui.backgroundVideo', false);
        if (typeof this.hub.settingChanged === 'function') {
          await this.hub.settingChanged('ui.backgroundFile', dest);
          await this.hub.settingChanged('ui.backgroundKind', 'image');
          await this.hub.settingChanged('ui.backgroundVideo', false);
        }
        return { ok: true };
      }
      if (method === 'install.localMod') {
        requirePermission('install');
        const declared = this.getPluginMods().find((item) => item.pluginId === pluginId && item.id === String(args[1] || ''));
        if (!declared) throw new Error('Плагин не объявлял такой мод в providedMods');
        const instance = await this.hub.instances.get(String(args[0] || ''));
        if (!instance) throw new Error('Сборка не найдена');
        if (declared.loaders.length && !declared.loaders.includes(String(instance.modLoader || '').toLowerCase())) {
          throw new Error(`Мод не поддерживает загрузчик ${instance.modLoader || 'unknown'}`);
        }
        if (declared.gameVersions.length && !declared.gameVersions.includes('*')
          && !declared.gameVersions.includes(String(instance.mcVersion || ''))) {
          throw new Error(`Мод не поддерживает Minecraft ${instance.mcVersion || 'unknown'}`);
        }
        const ownDir = path.join(this.dir(), pluginId);
        const provided = loaded.manifest.providedMods.find((item) => item && String(item.id) === declared.id);
        if (!provided || !provided.file) throw new Error('Файл мода не объявлен');
        const source = path.resolve(ownDir, String(provided.file || ''));
        const rel = path.relative(ownDir, source);
        if (rel.startsWith('..') || path.isAbsolute(rel)) throw new Error('Путь мода выходит за пределы папки плагина');
        const realOwnDir = await fs.realpath(ownDir);
        const realSource = await fs.realpath(source);
        const realRelative = path.relative(realOwnDir, realSource);
        if (realRelative.startsWith('..') || path.isAbsolute(realRelative)) throw new Error('Файл мода не может быть символической ссылкой за пределы папки плагина');
        const result = await this.hub.mods.installPluginMod(instance.id, source, declared.id, pluginId, declared.name);
        if (this.hub.timeline && result.ok) await this.hub.timeline.append(instance.id, 'mod', `Installed ${declared.name} from plugin ${pluginId}`);
        return result;
      }
      if (method === 'install.modrinth') {
        requirePermission('install');
        if (!this.hub.instances || !this.hub.resolver || !this.hub.modrinth) throw new Error('Установка Modrinth недоступна');
        const instance = await this.hub.instances.get(String(args[0] || ''));
        if (!instance) throw new Error('Сборка не найдена');
        const projectId = String(args[1] || '');
        const versionId = args[2] ? String(args[2]) : null;
        let version;
        const project = await this.hub.modrinth.getProject(projectId);
        if (!project || project.project_type !== 'mod') throw new Error('Через этот API можно устанавливать только моды');
        if (versionId) {
          version = await this.hub.modrinth.getVersion(versionId);
          if (version && (
            version.project_id !== projectId
            ||
            !Array.isArray(version.game_versions) || !version.game_versions.includes(instance.mcVersion)
            || !Array.isArray(version.loaders) || !version.loaders.includes(instance.modLoader)
          )) throw new Error('Выбранная версия не подходит для этой сборки');
        } else {
          const versions = await this.hub.modrinth.getProjectVersions(projectId, {
            loader: instance.modLoader,
            mcVersion: instance.mcVersion
          });
          version = versions && versions[0];
        }
        if (!version) throw new Error('Нет совместимой версии для выбранной сборки');
        const result = await this.hub.resolver.resolveAndInstall(instance.id, version.id, new Set(), {
          loader: instance.modLoader,
          mcVersion: instance.mcVersion
        });
        if (this.hub.timeline) await this.hub.timeline.append(instance.id, 'mod', `Installed ${version.name || projectId}`);
        return { ok: true, installed: this.hub.resolver.flatten(result) };
      }
      throw new Error(`Неизвестный метод Plugin API: ${method}`);
    }
  // Extracts a .zip into the plugins folder and returns the manifest, or null
  // when the archive is not a plugin.
  async installFromZip(zipPath, grantedPermissions = []) {
    await this.ensure();
    const zip = new AdmZip(zipPath);
    const entries = zip.getEntries();
    if (!entries.length || entries.length > 500
      || entries.reduce((sum, entry) => sum + Number(entry.header.size || 0), 0) > 50 * 1024 * 1024) {
      return { ok: false, error: 'Архив плагина превышает допустимый размер или число файлов' };
    }
    const manifestEntry = entries.find((e) => /(^|\/)manifest\.json$/i.test(e.entryName) && !e.isDirectory);
    if (!manifestEntry) return { ok: false, error: 'В архиве нет manifest.json' };
    let manifest;
    try {
      manifest = JSON.parse(manifestEntry.getData().toString('utf8'));
    } catch (_) {
      return { ok: false, error: 'manifest.json повреждён' };
    }
    const id = String(manifest.id || '');
    if (!/^[A-Za-z0-9][\w.-]{0,63}$/.test(id) || id === '.' || id === '..') {
      return { ok: false, error: 'В манифесте неверный id плагина' };
    }
    const manifestPath = String(manifestEntry.entryName || '').replace(/\\/g, '/');
    const manifestRoot = path.posix.dirname(manifestPath);
    const rootPrefix = manifestRoot === '.' ? '' : `${manifestRoot}/`;
    const permissions = Array.isArray(manifest.permissions) ? manifest.permissions : [];
    if (permissions.some((permission) => typeof permission !== 'string' || !PLUGIN_PERMISSIONS.has(permission))) {
      return { ok: false, error: 'В манифесте указано неизвестное разрешение' };
    }
    const target = path.join(this.dir(), id);
    const files = [];
    for (const entry of entries) {
      const raw = String(entry.entryName || '').replace(/\\/g, '/');
      if (raw.startsWith('/') || /^[A-Za-z]:/.test(raw)) return { ok: false, error: 'В архиве найден абсолютный путь' };
      const segments = raw.split('/');
      if (segments.includes('..')) return { ok: false, error: 'В архиве найден путь за пределы папки плагина' };
      if (rootPrefix && !raw.startsWith(rootPrefix)) continue;
      const relativeEntry = rootPrefix ? raw.slice(rootPrefix.length) : raw;
      const rel = relativeEntry.split('/').filter(Boolean).join(path.sep);
      if (!rel) continue;
      const dest = path.join(target, rel);
      const relative = path.relative(target, dest);
      if (relative.startsWith('..') || path.isAbsolute(relative)) {
        return { ok: false, error: 'В архиве найден путь за пределы папки плагина' };
      }
      files.push({ entry, dest });
    }
    for (const { entry, dest } of files) {
      if (entry.isDirectory) await fs.ensureDir(dest);
      else {
        await fs.ensureDir(path.dirname(dest));
        await fs.writeFile(dest, entry.getData());
      }
    }
    this.grants.set(id, Array.isArray(manifest.permissions)
      ? manifest.permissions.filter((permission) => Array.isArray(grantedPermissions)
        && grantedPermissions.includes(permission)
        && PLUGIN_PERMISSIONS.has(permission))
      : []);
    await this.saveGrants();
    return { ok: true, id, manifest, dir: target };
  }

  async list() {
    await this.ensure();
    const names = await fs.readdir(this.dir()).catch(() => []);
    const out = [];
    for (const name of names) {
      const dir = path.join(this.dir(), name);
      const st = await fs.stat(dir).catch(() => null);
      if (!st || !st.isDirectory()) continue;
      const manifestPath = path.join(dir, 'manifest.json');
      if (!await fs.pathExists(manifestPath)) continue;
      let manifest = {};
      let error = '';
      try { manifest = await fs.readJson(manifestPath); } catch (err) { error = err.message; }
      out.push({
        id: name,
        name: manifest.name || name,
        version: manifest.version || '',
        description: manifest.description || '',
        author: manifest.author || '',
        api: manifest.api || 0,
        permissions: manifest.permissions || [],
        grantedPermissions: this.grants.get(name) || [],
        uiPages: this.uiPages.has(name) ? this.uiPages.get(name).size : 0,
        settings: manifest.settings || [],
        dir,
        error,
        disabled: this.disabled.has(name),
        active: this.loaded.has(name)
      });
    }
    return out;
  }

  configFile(id) {
    return path.join(this.dir(), id, 'config.json');
  }

  async readConfig(id) {
    const file = this.configFile(id);
    try {
      if (await fs.pathExists(file)) return await fs.readJson(file);
    } catch (_) { /* */ }
    return {};
  }

  async writeConfig(id, data) {
    const file = this.configFile(id);
    await fs.ensureDir(path.dirname(file));
    const next = data && typeof data === 'object' ? data : {};
    await fs.writeJson(file, next, { spaces: 2 });
    this.emit('config', { id, config: next });
    return next;
  }

  async patchConfig(id, key, value) {
    const cur = await this.readConfig(id);
    const parts = String(key || '').split('.').filter(Boolean);
    if (!parts.length) return this.writeConfig(id, value && typeof value === 'object' ? value : cur);
    let node = cur;
    for (let i = 0; i < parts.length - 1; i += 1) {
      if (!node[parts[i]] || typeof node[parts[i]] !== 'object') node[parts[i]] = {};
      node = node[parts[i]];
    }
    node[parts[parts.length - 1]] = value;
    return this.writeConfig(id, cur);
  }

  disabledFile() {
    return path.join(this.dir(), '.disabled.json');
  }

  async loadDisabled() {
    try {
      const file = this.disabledFile();
      if (await fs.pathExists(file)) {
        const list = await fs.readJson(file);
        this.disabled = new Set(Array.isArray(list) ? list : []);
      }
    } catch (_) { this.disabled = new Set(); }
  }

  async saveDisabled() {
    await fs.ensureDir(this.dir());
    await fs.writeJson(this.disabledFile(), [...this.disabled], { spaces: 2 });
  }

  async toggle(id, on) {
    if (on === false || (on === undefined && this.loaded.has(id))) {
      this.disabled.add(id);
      await this.saveDisabled();
      await this.unload(id);
      return { ok: true, active: false };
    }
    this.disabled.delete(id);
    await this.saveDisabled();
    return this.loadOne(id);
  }

  schemaFor(id, manifest) {
    const fields = Array.isArray(manifest && manifest.settings) ? manifest.settings : [];
    this.schemas.set(id, fields);
    return fields;
  }

  // Build the sandboxed API handed to a plugin. Every call is guarded so a
  // misbehaving plugin produces a warning instead of an unhandled rejection.
  async buildApi(id, manifest) {
    const warn = (message) => this.warn(id, message);
    const perms = new Set((manifest.permissions || []).filter((permission) => this.hasPermission(id, permission)));
    const ownDir = path.join(this.dir(), id);
    const inside = (p) => {
      const abs = path.resolve(ownDir, String(p || '.'));
      if (!abs.startsWith(ownDir + path.sep) && abs !== ownDir) throw new Error('Путь вне папки плагина');
      return abs;
    };
    const config = {
      get: async (key, fallback) => {
        const all = await this.readConfig(id);
        if (!key) return all;
        const parts = String(key).split('.');
        let cur = all;
        for (const p of parts) {
          if (cur == null) return fallback;
          cur = cur[p];
        }
        return cur === undefined ? fallback : cur;
      },
      set: (key, value) => this.patchConfig(id, key, value),
      all: () => this.readConfig(id)
    };
    const showToast = (text, kind = 'ok') => {
      const notice = {
        text: String(text || '').slice(0, 500),
        kind: ['ok', 'bad', 'info'].includes(kind) ? kind : 'ok',
        pluginId: id
      };
      this.emit('toast', notice);
      if (typeof this.hub.notify === 'function') this.hub.notify(notice);
    };
    const api = {
      apiVersion: PLUGIN_API_VERSION,
      pluginId: id,
      manifest: JSON.parse(JSON.stringify(manifest)),
      log: (...args) => logger.info(`plugin ${id}`, { args: args.map(String) }),
      warn: (...args) => warn(args.map(String).join(' ')),
      on: (hook, handler) => this.on(id, hook, handler),
      off: (hook, handler) => {
        const handlers = this.hooks.get(hook);
        if (handlers) this.hooks.set(hook, handlers.filter((h) => h.id !== id || (handler && h.handler !== handler)));
      },
      emit: (hook, payload) => this.emit(hook, payload),
      config,
      settings: config,
      storage: {
        read: async (rel) => {
          const dest = inside(rel || 'data.json');
          if (!await fs.pathExists(dest)) return null;
          return fs.readFile(dest, 'utf8');
        },
        write: async (rel, text) => {
          const dest = inside(rel || 'data.json');
          await fs.ensureDir(path.dirname(dest));
          await fs.writeFile(dest, String(text == null ? '' : text), 'utf8');
          return { ok: true };
        },
        json: async (rel) => {
          const dest = inside(rel || 'data.json');
          if (!await fs.pathExists(dest)) return null;
          return fs.readJson(dest);
        },
        writeJson: async (rel, data) => {
          const dest = inside(rel || 'data.json');
          await fs.ensureDir(path.dirname(dest));
          await fs.writeJson(dest, data, { spaces: 2 });
          return { ok: true };
        }
      },
      ui: {
        toast: showToast,
        registerSettings: (fields) => {
          if (Array.isArray(fields)) this.schemas.set(id, fields);
        },
        registerPage: (page) => this.registerUiPage(id, page),
        setTheme: (css) => this.setPluginTheme(id, css),
        clearTheme: () => this.setPluginTheme(id, ''),
        openModal: (modal) => {
          if (!this.hasPermission(id, 'ui')) throw new Error('Плагину не выдано разрешение ui');
          const html = String(modal && modal.html || '');
          const css = String(modal && modal.css || '');
          if (html.length > 128 * 1024 || css.length > 64 * 1024) throw new Error('Размер модального окна плагина превышает лимит');
          if (typeof this.hub.openPluginModal === 'function') {
            this.hub.openPluginModal({ pluginId: id, title: String(modal.title || '').slice(0, 80), html, css });
          }
        },
        addNav: (item) => {
          if (!item || !item.id) return;
          this.registerUiPage(id, {
            id: item.id,
            title: item.label || item.title || item.id,
            icon: item.icon,
            html: item.html || '',
            css: item.css || ''
          });
        }
      },
      toast: (text, kind) => showToast(text, kind),
      instances: {
        list: () => perms.has('instances.read')
          ? (this.hub.instances ? this.hub.instances.list() : Promise.resolve([]))
          : Promise.reject(new Error('Не выдано разрешение instances.read')),
        get: (instId) => perms.has('instances.read')
          ? (this.hub.instances ? this.hub.instances.get(instId) : Promise.resolve(null))
          : Promise.reject(new Error('Не выдано разрешение instances.read'))
      },
      modrinth: perms.has('net') && this.hub.modrinth ? {
        search: (options = {}) => this.hub.modrinth.search({
          ...options,
          limit: Math.min(50, Math.max(1, Number(options.limit) || 20)),
          offset: Math.max(0, Number(options.offset) || 0)
        }),
        project: (id) => this.hub.modrinth.getProject(String(id)),
        versions: (id, options) => this.hub.modrinth.getProjectVersions(String(id), options || {}),
        version: (id) => this.hub.modrinth.getVersion(String(id))
      } : {
        search: async () => ({ ok: false, error: 'Для Modrinth API требуется разрешение net' }),
        project: async () => ({ ok: false, error: 'Для Modrinth API требуется разрешение net' }),
        versions: async () => ({ ok: false, error: 'Для Modrinth API требуется разрешение net' }),
        version: async () => ({ ok: false, error: 'Для Modrinth API требуется разрешение net' })
      },
      launcher: {
        apiVersion: PLUGIN_API_VERSION,
        pluginId: id,
        pluginVersion: String(manifest.version || '')
      },
      fetch: perms.has('net') ? (url, opts) => {
        const axios = require('axios');
        return axios({ url: String(url), method: (opts && opts.method) || 'GET', timeout: 15000, ...(opts || {}) })
          .then((r) => ({ ok: true, status: r.status, data: r.data }))
          .catch((err) => ({ ok: false, error: err.message }));
      } : () => Promise.resolve({ ok: false, error: 'Нет разрешения net' })
    };
    api.events = {
      on: api.on,
      off: api.off,
      emit: api.emit,
      once: (hook, handler) => {
        if (typeof handler !== 'function') return;
        const wrapped = (payload) => {
          api.off(hook, wrapped);
          return handler(payload);
        };
        api.on(hook, wrapped);
      }
    };
    api.permissions = { list: () => [...perms] };
    const targets = {
      log: api.log,
      warn: api.warn,
      toast: api.toast,
      'config.get': config.get,
      'config.set': config.set,
      'config.all': config.all,
      'events.emit': api.emit,
      'instances.list': api.instances.list,
      'instances.get': api.instances.get,
      'modrinth.search': api.modrinth.search,
      'modrinth.project': api.modrinth.project,
      'modrinth.versions': api.modrinth.versions,
      'modrinth.version': api.modrinth.version
    };
    const apiPackStatus = await this.apiPackStatus();
    let aliases = { aliases: {} };
    if (apiPackStatus.error) this.warn(id, `Не удалось прочитать пакет Plugin API: ${apiPackStatus.error}`);
    else aliases = await this.readApiPackFile('api.json', aliases);
    api.extensions = {};
    for (const [name, target] of Object.entries(aliases.aliases || {})) {
      if (/^[a-z][a-zA-Z0-9]{1,31}$/.test(name) && API_ALIAS_TARGETS.has(target) && targets[target]) {
        api.extensions[name] = targets[target];
      }
    }
    return api;
  }

  async loadOne(id) {
    await this.loadGrants();
    if (this.hub.settings && await this.hub.settings.get('ui.pluginsEnabled') === false) {
      return { ok: false, disabled: true, id, error: 'Плагины отключены в настройках лаунчера' };
    }
    if (this.disabled.has(id)) return { ok: false, disabled: true, id };
    const dir = path.join(this.dir(), id);
    const manifestPath = path.join(dir, 'manifest.json');
    if (!await fs.pathExists(manifestPath)) return { ok: false, error: 'Нет манифеста' };
    let manifest;
    try { manifest = await fs.readJson(manifestPath); } catch (err) { return { ok: false, error: err.message }; }
    this.schemaFor(id, manifest);
    if (Number(manifest.api) > PLUGIN_API_VERSION) {
      this.warn(id, `Плагин требует API ${manifest.api}, а лаунчер поддерживает ${PLUGIN_API_VERSION}`);
      return { ok: false, error: 'Слишком новая версия API' };
    }
    if (manifest.main != null && typeof manifest.main !== 'string') return { ok: false, error: 'Неверный путь main-файла' };
    const main = path.resolve(dir, manifest.main || 'index.js');
    const mainRelative = path.relative(dir, main);
    if (mainRelative.startsWith('..') || path.isAbsolute(mainRelative)) {
      return { ok: false, error: 'Путь main-файла выходит за пределы папки плагина' };
    }
    if (!await fs.pathExists(main)) return { ok: false, error: 'Нет main-файла' };
    let code;
    try { code = await fs.readFile(main, 'utf8'); } catch (err) {
      return { ok: false, error: `Не удалось прочитать main-файл: ${err.message}` };
    }
    const api = await this.buildApi(id, manifest);
    const sandbox = {
      module: { exports: {} },
      exports: {},
      console: { log: api.log, warn: api.warn, error: api.warn },
      api,
      setTimeout,
      clearTimeout,
      setInterval,
      clearInterval
    };
    try {
      const script = new vm.Script(code, { filename: main });
      const ctx = vm.createContext(sandbox);
      script.runInContext(ctx, { timeout: 5000 });
      const exported = sandbox.module.exports && Object.keys(sandbox.module.exports).length
        ? sandbox.module.exports
        : sandbox.exports;
      // Both `module.exports = { activate }` and a bare `module.exports = fn`
      // entry point are accepted; anything else is reported instead of
      // silently loading as a no-op.
      if (typeof exported === 'function') {
        await exported(api);
      } else if (exported && typeof exported.activate === 'function') {
        await exported.activate(api);
      } else {
        this.warn(id, 'Плагин не экспортирует activate() — он загружен, но ничего не делает');
      }
      this.loaded.set(id, { manifest, dir, api, exports: exported });
      return { ok: true, id };
    } catch (err) {
      this.warn(id, err.message || String(err));
      return { ok: false, error: err.message || String(err) };
    }
  }

  async loadAll() {
    await this.ensure();
    await this.loadDisabled();
    this.warnings = [];
    if (this.hub.settings && await this.hub.settings.get('ui.pluginsEnabled') === false) {
      for (const id of [...this.loaded.keys()]) {
        // eslint-disable-next-line no-await-in-loop
        await this.unload(id);
      }
      this.hooks.clear();
      this.navItems = [];
      this.uiPages.clear();
      this.uiThemes.clear();
      this.schemas.clear();
      if (typeof this.hub.uiChanged === 'function') this.hub.uiChanged();
      return { loaded: 0, results: [], warnings: this.warnings };
    }
    this.navItems = [];
    this.uiPages.clear();
    this.uiThemes.clear();
    this.schemas.clear();
    const list = await this.list();
    const results = [];
    for (const p of list) {
      // eslint-disable-next-line no-await-in-loop
      results.push(await this.loadOne(p.id));
    }
    return { loaded: this.loaded.size, results, warnings: this.warnings };
  }

  async setEnabled(enabled) {
    if (enabled === false) {
      for (const id of [...this.loaded.keys()]) {
        // eslint-disable-next-line no-await-in-loop
        await this.unload(id);
      }
      this.hooks.clear();
      this.navItems = [];
      this.uiPages.clear();
      this.uiThemes.clear();
      this.schemas.clear();
      if (typeof this.hub.uiChanged === 'function') this.hub.uiChanged();
      return { loaded: 0 };
    }
    return this.loadAll();
  }

  async unload(id) {
    const entry = this.loaded.get(id);
    if (entry && entry.exports && typeof entry.exports.deactivate === 'function') {
      try { await entry.exports.deactivate(entry.api); } catch (err) { this.warn(id, err.message); }
    }
    this.loaded.delete(id);
    this.navItems = this.navItems.filter((n) => n.pluginId !== id);
    this.uiPages.delete(id);
    this.uiThemes.delete(id);
    if (typeof this.hub.uiChanged === 'function') this.hub.uiChanged();
    for (const [hook, handlers] of this.hooks) {
      this.hooks.set(hook, handlers.filter((h) => h.id !== id));
    }
    return { ok: true };
  }

  on(id, hook, handler) {
    if (typeof handler !== 'function') return;
    if (!this.hooks.has(hook)) this.hooks.set(hook, []);
    this.hooks.get(hook).push({ id, handler });
  }

  // Fire a hook. Each handler runs in isolation: a throw is turned into a
  // warning and never breaks the caller or the other plugins.
  emit(hook, payload) {
    const handlers = this.hooks.get(hook) || [];
    const out = [];
    for (const { id, handler } of handlers) {
      try {
        out.push(handler(payload));
      } catch (err) {
        this.warn(id, `hook ${hook}: ${err.message || err}`);
      }
    }
    return out;
  }

  warn(id, message) {
    const w = { id, message: String(message || ''), at: new Date().toISOString() };
    this.warnings.push(w);
    if (this.warnings.length > 200) this.warnings.shift();
    logger.warn(`plugin ${id}`, { message: w.message });
    return w;
  }

  async remove(id) {
    await this.unload(id);
    await fs.remove(path.join(this.dir(), id)).catch(() => {});
    this.grants.delete(id);
    await this.saveGrants();
    return { ok: true };
  }
}

module.exports = PluginForge;
module.exports.PLUGIN_API_VERSION = PLUGIN_API_VERSION;
