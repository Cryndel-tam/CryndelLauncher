const os = require('os');

function suggestMemoryMb() {
  const total = Math.round(os.totalmem() / 1048576);
  const free = Math.round(os.freemem() / 1048576);
  const leave = Math.min(4096, Math.max(1536, Math.round(total * 0.28)));
  const raw = total - leave;
  const rec = Math.min(8192, Math.max(2048, Math.floor(raw / 256) * 256));
  return { totalMb: total, freeMb: free, recommendedMb: rec };
}

module.exports = { suggestMemoryMb };
