const fs = require('fs-extra');
const path = require('path');
const crypto = require('crypto');
const axios = require('axios');
const CryndelPathVault = require('../utils/paths');

function sanitizeName(name) {
  return String(name || 'file').replace(/[\\/:*?"<>|]/g, '_').split('').map((ch) => (ch.charCodeAt(0) < 32 ? '_' : ch)).join('');
}

class StreamHauler {
  constructor() {
    this.listeners = new Set();
    this.controllers = new Set();
    this.cancelled = false;
  }

  onProgress(fn) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  emit(payload) {
    for (const fn of this.listeners) {
      try { fn(payload); } catch (_) { /* ui */ }
    }
  }

  cancelAll() {
    this.cancelled = true;
    for (const c of this.controllers) {
      try { c.abort(); } catch (_) { /* */ }
    }
    this.controllers.clear();
  }

  isCancelled() {
    return this.cancelled;
  }

  reset() {
    this.cancelled = false;
  }

  async fetchToFile(url, destPath, { sha512, onProgress, headers } = {}) {
    if (this.cancelled) throw new Error('Загрузка отменена');
    await fs.ensureDir(path.dirname(destPath));
    const tmp = `${destPath}.part`;
    const hash = crypto.createHash('sha512');
    const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    if (controller) this.controllers.add(controller);
    const res = await axios.get(url, {
      responseType: 'stream',
      timeout: 120000,
      headers: headers || { 'User-Agent': 'CryndelLauncher/1.0.0 (contact@cryndel.ru)' },
      maxRedirects: 5,
      signal: controller ? controller.signal : undefined
    });
    const total = Number(res.headers['content-length'] || 0);
    let loaded = 0;
    await new Promise((resolve, reject) => {
      const out = fs.createWriteStream(tmp);
      let settled = false;
      const fail = (err) => {
        if (settled) return;
        settled = true;
        try { out.destroy(); } catch (_) { /* */ }
        reject(err);
      };
      const ok = () => {
        if (settled) return;
        settled = true;
        resolve();
      };
      res.data.on('data', (chunk) => {
        if (this.cancelled) {
          res.data.destroy();
          fail(new Error('Загрузка отменена'));
          return;
        }
        loaded += chunk.length;
        hash.update(chunk);
        const pct = total ? Math.round((loaded / total) * 100) : 0;
        const ev = { url, destPath, loaded, total, pct };
        this.emit(ev);
        if (onProgress) onProgress(ev);
      });
      res.data.on('error', fail);
      out.on('error', fail);
      out.on('finish', ok);
      res.data.pipe(out);
    });
    if (controller) this.controllers.delete(controller);
    const digest = hash.digest('hex');
    if (sha512 && digest !== sha512 && sha512.length === digest.length) {
      await fs.remove(tmp);
      throw new Error('SHA-512 mismatch after download');
    }
    await fs.move(tmp, destPath, { overwrite: true });
    return { path: destPath, sha512: digest, size: loaded };
  }

  async cacheModJar(url, filename, sha512, onProgress) {
    const safe = sanitizeName(filename);
    const dest = path.join(CryndelPathVault.modCacheDir(), sha512 ? sha512.slice(0, 16) : 'anon', safe);
    if (await fs.pathExists(dest)) {
      if (sha512) {
        const buf = await fs.readFile(dest);
        const got = crypto.createHash('sha512').update(buf).digest('hex');
        if (got === sha512) return { path: dest, sha512, size: buf.length, cached: true };
      } else {
        const st = await fs.stat(dest);
        return { path: dest, sha512: null, size: st.size, cached: true };
      }
    }
    return this.fetchToFile(url, dest, { sha512, onProgress });
  }
}

module.exports = { StreamHauler, sanitizeName };
