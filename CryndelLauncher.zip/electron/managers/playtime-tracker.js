class Hourglass {
  constructor() {
    this.sessions = new Map();
  }

  start(instanceId) {
    this.sessions.set(instanceId, Date.now());
  }

  end(instanceId) {
    const t0 = this.sessions.get(instanceId);
    this.sessions.delete(instanceId);
    if (!t0) return 0;
    return Math.round((Date.now() - t0) / 60000);
  }
}

module.exports = Hourglass;
