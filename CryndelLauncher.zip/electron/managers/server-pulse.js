const net = require('net');

function pingHost(host, port, timeoutMs) {
  const timeout = timeoutMs || 3500;
  return new Promise((resolve) => {
    const start = Date.now();
    let done = false;
    const finish = (online) => {
      if (done) return;
      done = true;
      try { sock.destroy(); } catch (_) { /* */ }
      resolve({ online, ms: online ? Date.now() - start : null, host, port });
    };
    const sock = net.connect({ host, port: Number(port) || 25565 });
    sock.setTimeout(timeout);
    sock.on('connect', () => finish(true));
    sock.on('timeout', () => finish(false));
    sock.on('error', () => finish(false));
  });
}

// --- Minecraft Server List Ping (protocol 1.7+) ---

function writeVarInt(value) {
  const bytes = [];
  let v = value >>> 0;
  do {
    let b = v & 0x7f;
    v >>>= 7;
    if (v !== 0) b |= 0x80;
    bytes.push(b);
  } while (v !== 0);
  return Buffer.from(bytes);
}

function writeString(str) {
  const data = Buffer.from(str, 'utf8');
  return Buffer.concat([writeVarInt(data.length), data]);
}

function readVarInt(buf, offset) {
  let result = 0;
  let shift = 0;
  let pos = offset;
  while (pos < buf.length) {
    const b = buf[pos];
    result |= (b & 0x7f) << shift;
    pos += 1;
    if ((b & 0x80) === 0) return { value: result, size: pos - offset };
    shift += 7;
    if (shift > 35) return null;
  }
  return null;
}

function packet(id, payload) {
  const body = Buffer.concat([writeVarInt(id), payload]);
  return Buffer.concat([writeVarInt(body.length), body]);
}

// MOTD is a chat component: {text} / {extra:[...]} / legacy §-codes.
function flattenMotd(node) {
  if (node == null) return '';
  if (typeof node === 'string') return node;
  if (Array.isArray(node)) return node.map(flattenMotd).join('');
  let out = '';
  if (typeof node.text === 'string') out += node.text;
  if (node.extra) out += flattenMotd(node.extra);
  return out;
}

const MAINTENANCE_RE = /тех\.?\s*работ|техническ|technical\s*works|maintenance|обслужив/i;

function queryServer(host, port, timeoutMs) {
  const timeout = timeoutMs || 4000;
  const targetPort = Number(port) || 25565;
  return new Promise((resolve) => {
    const start = Date.now();
    let settled = false;
    let buffer = Buffer.alloc(0);
    const done = (payload) => {
      if (settled) return;
      settled = true;
      try { sock.destroy(); } catch (_) { /* */ }
      resolve(payload);
    };
    const offline = () => done({ online: false, maintenance: false, host, port: targetPort });

    const sock = net.connect({ host, port: targetPort });
    sock.setTimeout(timeout);
    sock.on('timeout', offline);
    sock.on('error', offline);

    sock.on('connect', () => {
      // Handshake (next state 1 = status) followed by an empty status request.
      const handshake = packet(0x00, Buffer.concat([
        writeVarInt(47),
        writeString(host),
        Buffer.from([(targetPort >> 8) & 0xff, targetPort & 0xff]),
        writeVarInt(1)
      ]));
      sock.write(Buffer.concat([handshake, packet(0x00, Buffer.alloc(0))]));
    });

    sock.on('data', (chunk) => {
      buffer = Buffer.concat([buffer, chunk]);
      const len = readVarInt(buffer, 0);
      if (!len) return;
      const total = len.size + len.value;
      if (buffer.length < total) return;
      const body = buffer.subarray(len.size, total);
      const id = readVarInt(body, 0);
      if (!id || id.value !== 0x00) return offline();
      const strLen = readVarInt(body, id.size);
      if (!strLen) return offline();
      const jsonText = body.subarray(id.size + strLen.size, id.size + strLen.size + strLen.value).toString('utf8');
      let status = null;
      try { status = JSON.parse(jsonText); } catch (_) { status = null; }
      const motd = status ? flattenMotd(status.description) : '';
      const motdPlain = motd.replace(/§./g, '');
      const players = status && status.players ? status.players : null;
      const version = status && status.version ? status.version.name : '';
      done({
        online: true,
        maintenance: MAINTENANCE_RE.test(motdPlain),
        motd,
        ms: Date.now() - start,
        host,
        port: targetPort,
        version: version || '',
        players: players ? { online: players.online || 0, max: players.max || 0 } : null
      });
    });
  });
}

module.exports = { pingHost, queryServer };
