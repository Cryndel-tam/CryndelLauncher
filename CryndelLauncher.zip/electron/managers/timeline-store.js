const vault = require('../storage/json-db');
const CryndelPathVault = require('../utils/paths');

class TraceRibbon {
  file(id) {
    return CryndelPathVault.timelineFile(id);
  }

  async list(instanceId) {
    const doc = await vault.read(this.file(instanceId), { version: 1, events: [] });
    return doc.events || [];
  }

  async append(instanceId, kind, text) {
    return vault.patch(this.file(instanceId), (doc) => {
      if (!doc.events) doc.events = [];
      doc.events.unshift({
        at: new Date().toISOString(),
        kind,
        text
      });
      if (doc.events.length > 200) doc.events.length = 200;
      return doc;
    }, { version: 1, events: [] });
  }
}

module.exports = TraceRibbon;
