const fs = require('fs-extra');
const path = require('path');
const axios = require('axios');
const logger = require('../utils/logger');
const CryndelPathVault = require('../utils/paths');

const UA = { 'User-Agent': 'CryndelLauncher/1.0.0 (contact@cryndel.ru)' };

function pickStable(list) {
  if (!Array.isArray(list) || !list.length) return null;
  const stable = list.find((x) => x.stable);
  return (stable || list[0]).version;
}

class LoomBinder {
  async getJson(url) {
    const { data, status } = await axios.get(url, { timeout: 30000, headers: UA, validateStatus: () => true });
    if (status >= 400) {
      const err = new Error(`HTTP ${status} ${url}`);
      err.status = status;
      throw err;
    }
    return data;
  }

  async latestFabricLoader(mcVersion) {
    if (mcVersion) {
      try {
        const data = await this.getJson(`https://meta.fabricmc.net/v2/versions/loader/${encodeURIComponent(mcVersion)}`);
        const row = (data || []).find((x) => x.loader && x.loader.stable) || (data || [])[0];
        if (row && row.loader && row.loader.version) return row.loader.version;
      } catch (err) {
        logger.warn('fabric loader-for-game failed', { mcVersion, message: err.message });
      }
    }
    const data = await this.getJson('https://meta.fabricmc.net/v2/versions/loader');
    return pickStable(data);
  }

  profileId(mcVersion, loaderVersion) {
    return `fabric-loader-${loaderVersion}-${mcVersion}`;
  }

  async writeProfile(id, data) {
    const vDir = path.join(CryndelPathVault.versionsDir(), id);
    const jsonPath = path.join(vDir, `${id}.json`);
    await fs.ensureDir(vDir);
    await fs.writeJson(jsonPath, data, { spaces: 2 });
    return jsonPath;
  }

  async ensureFabric(mcVersion, loaderVersion, onProgress) {
    const loader = loaderVersion || await this.latestFabricLoader(mcVersion);
    const id = this.profileId(mcVersion, loader);
    const jsonPath = path.join(CryndelPathVault.versionsDir(), id, `${id}.json`);
    if (await fs.pathExists(jsonPath)) return { id, loaderVersion: loader };

    if (onProgress) onProgress({ stage: 'loader', pct: 20, message: `Ставлю Fabric ${loader}…` });

    const urls = [
      `https://meta.fabricmc.net/v2/versions/loader/${encodeURIComponent(mcVersion)}/${encodeURIComponent(loader)}/profile/json`,
      `https://meta.fabricmc.net/v2/versions/loader/${encodeURIComponent(mcVersion)}/${encodeURIComponent(loader)}`
    ];
    let data = null;
    let lastErr = null;
    for (const url of urls) {
      try {
        const raw = await this.getJson(url);
        data = raw && raw.loader && raw.id ? raw : (raw && (raw.id || raw.libraries) ? raw : null);
        if (raw && raw.loader && !raw.id) {
          data = this.buildFabricProfile(mcVersion, loader, raw);
        }
        if (data && (data.id || data.libraries)) break;
      } catch (err) {
        lastErr = err;
        logger.warn('fabric profile try failed', { url, message: err.message });
      }
    }
    if (!data || !(data.id || data.libraries)) {
      throw lastErr || new Error(`Fabric не ставится на Minecraft ${mcVersion}. Выбери другую версию игры или Vanilla.`);
    }
    if (!data.id) data.id = id;
    if (!data.inheritsFrom) data.inheritsFrom = mcVersion;
    await this.writeProfile(id, data);
    logger.info('fabric profile written', { id });
    return { id, loaderVersion: loader, json: data };
  }

  buildFabricProfile(mcVersion, loader, meta) {
    const loaderLib = meta.loader || {};
    const intermediary = meta.intermediary || {};
    const launcherMeta = meta.launcherMeta || {};
    const libraries = [
      ...(launcherMeta.libraries && launcherMeta.libraries.common ? launcherMeta.libraries.common : []),
      ...(launcherMeta.libraries && launcherMeta.libraries.client ? launcherMeta.libraries.client : []),
      loaderLib.maven ? { name: loaderLib.maven, url: 'https://maven.fabricmc.net/' } : null,
      intermediary.maven ? { name: intermediary.maven, url: 'https://maven.fabricmc.net/' } : null
    ].filter(Boolean);
    return {
      id: this.profileId(mcVersion, loader),
      inheritsFrom: mcVersion,
      type: 'release',
      mainClass: (launcherMeta.mainClass && (launcherMeta.mainClass.client || launcherMeta.mainClass)) || 'net.fabricmc.loader.impl.launch.knot.KnotClient',
      arguments: launcherMeta.arguments || { game: [], jvm: [] },
      libraries
    };
  }

  async latestQuiltLoader(mcVersion) {
    if (mcVersion) {
      try {
        const data = await this.getJson(`https://meta.quiltmc.org/v3/versions/loader/${encodeURIComponent(mcVersion)}`);
        if (data && data[0] && data[0].loader && data[0].loader.version) return data[0].loader.version;
        if (data && data[0] && data[0].version) return data[0].version;
      } catch (err) {
        logger.warn('quilt loader-for-game failed', { mcVersion, message: err.message });
      }
    }
    const data = await this.getJson('https://meta.quiltmc.org/v3/versions/loader');
    return data && data[0] && data[0].version;
  }

  async ensureQuilt(mcVersion, loaderVersion, onProgress) {
    const loader = loaderVersion || await this.latestQuiltLoader(mcVersion);
    const id = `quilt-loader-${loader}-${mcVersion}`;
    const jsonPath = path.join(CryndelPathVault.versionsDir(), id, `${id}.json`);
    if (await fs.pathExists(jsonPath)) return { id, loaderVersion: loader };
    if (onProgress) onProgress({ stage: 'loader', pct: 20, message: `Ставлю Quilt ${loader}…` });
    const url = `https://meta.quiltmc.org/v3/versions/loader/${encodeURIComponent(mcVersion)}/${encodeURIComponent(loader)}/profile/json`;
    const data = await this.getJson(url);
    if (!data.id) data.id = id;
    if (!data.inheritsFrom) data.inheritsFrom = mcVersion;
    await this.writeProfile(id, data);
    return { id, loaderVersion: loader, json: data };
  }

  async latestForge(mcVersion) {
    const url = `https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json`;
    try {
      const data = await this.getJson(url);
      const promo = (data && data.promos) || {};
      return promo[`${mcVersion}-recommended`] || promo[`${mcVersion}-latest`] || null;
    } catch (err) {
      logger.warn('forge promo failed', { message: err.message });
      return null;
    }
  }

  async latestNeoForge(mcVersion) {
    try {
      const data = await this.getJson('https://maven.neoforged.net/releases/net/neoforged/neoforge/maven-metadata.xml');
      const text = typeof data === 'string' ? data : String(data);
      const versions = [...text.matchAll(/<version>([^<]+)<\/version>/g)].map((m) => m[1]);
      const minor = String(mcVersion).split('.')[1];
      const hit = versions.reverse().find((v) => v.startsWith(`${minor}.`) || v.startsWith(mcVersion));
      return hit || versions[versions.length - 1] || null;
    } catch (err) {
      logger.warn('neoforge meta failed', { message: err.message });
      return null;
    }
  }

  async ensureForgeFamily(kind, mcVersion, loaderVersion, onProgress) {
    const label = kind === 'neoforge' ? 'NeoForge' : 'Forge';
    if (onProgress) onProgress({ stage: 'loader', pct: 18, message: `${label}: готовлю клиент Minecraft ${mcVersion}` });
    const version = loaderVersion || (kind === 'neoforge' ? await this.latestNeoForge(mcVersion) : await this.latestForge(mcVersion));
    return { id: mcVersion, loaderVersion: version || '', vanillaFallback: true, kind };
  }
}

module.exports = LoomBinder;
