const fs = require('fs-extra');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const AdmZip = require('adm-zip');
const CryndelPathVault = require('../utils/paths');
const logger = require('../utils/logger');

// Folders that make up a "full" pack backup. Everything the player can change
// lives in one of these; caches and downloaded runtimes are intentionally left
// out so a snapshot stays small enough to keep several of them.
const FULL_FOLDERS = [
  'mods',
  'config',
  'resourcepacks',
  'shaderpacks',
  'saves',
  'screenshots',
  'defaultconfigs',
  'kubejs',
  'scripts',
  'cryndel-skins'
];

const FULL_FILES = [
  'options.txt',
  'servers.dat',
  'skin.png',
  'cryndel-notes.txt',
  'cryndel-servers.txt'
];

class VaultSnapshot {
  dir(instanceId) {
    return path.join(CryndelPathVault.backupsDir(), instanceId);
  }

  async addFolderIfExists(zip, gameDir, rel, prefix) {
    const abs = path.join(gameDir, rel);
    if (!(await fs.pathExists(abs))) return false;
    try {
      zip.addLocalFolder(abs, prefix ? `${prefix}/${rel}` : rel);
      return true;
    } catch (err) {
      logger.warn('backup folder skipped', { rel, message: err.message });
      return false;
    }
  }

  async create(instance, label, opts = {}) {
    const id = `b-${uuidv4().replace(/-/g, '').slice(0, 10)}`;
    const dir = this.dir(instance.id);
    await fs.ensureDir(dir);
    const dest = path.join(dir, `${id}.zip`);
    const zip = new AdmZip();
    const mode = opts.full === false ? 'quick' : 'full';
    const included = [];

    if (mode === 'full') {
      for (const rel of FULL_FOLDERS) {
        if (await this.addFolderIfExists(zip, instance.gameDir, rel, '')) included.push(rel);
      }
      for (const rel of FULL_FILES) {
        const abs = path.join(instance.gameDir, rel);
        if (await fs.pathExists(abs)) {
          try {
            zip.addLocalFile(abs, '', rel);
            included.push(rel);
          } catch (_) { /* */ }
        }
      }
    } else {
      if (await this.addFolderIfExists(zip, instance.gameDir, 'mods', '')) included.push('mods');
      if (await this.addFolderIfExists(zip, instance.gameDir, 'config', '')) included.push('config');
    }

    // The lockfile and the instance record travel with every snapshot so a
    // restore also brings back mod metadata and per-pack settings.
    const lock = CryndelPathVault.lockfile(instance.id);
    if (await fs.pathExists(lock)) {
      try { zip.addLocalFile(lock, '', 'lock.json'); included.push('lock.json'); } catch (_) { /* */ }
    }
    try {
      zip.addFile('instance.json', Buffer.from(JSON.stringify(instance, null, 2), 'utf8'));
      included.push('instance.json');
    } catch (_) { /* */ }

    zip.writeZip(dest);
    const meta = {
      id,
      instanceId: instance.id,
      label: label || 'snapshot',
      mode,
      included,
      createdAt: new Date().toISOString(),
      file: dest,
      size: (await fs.stat(dest)).size
    };
    const index = path.join(dir, 'index.json');
    const list = (await fs.pathExists(index)) ? await fs.readJson(index) : [];
    list.push(meta);
    await fs.writeJson(index, list, { spaces: 2 });
    logger.info('backup created', { id, instanceId: instance.id, mode });
    return meta;
  }

  async list(instanceId) {
    const index = path.join(this.dir(instanceId), 'index.json');
    if (!(await fs.pathExists(index))) return [];
    return fs.readJson(index);
  }

  // Snapshots the launcher's own state (settings, users, instance list) so a
  // "back up everything" really does cover everything the player configured.
  async createLauncherConfig(label) {
    const id = `cfg-${uuidv4().replace(/-/g, '').slice(0, 10)}`;
    const dir = path.join(CryndelPathVault.backupsDir(), 'launcher');
    await fs.ensureDir(dir);
    const dest = path.join(dir, `${id}.zip`);
    const zip = new AdmZip();
    const included = [];
    for (const [rel, abs] of [
      ['settings.json', CryndelPathVault.settingsFile()],
      ['users.json', CryndelPathVault.usersFile()],
      ['instances.json', CryndelPathVault.instancesFile()]
    ]) {
      if (await fs.pathExists(abs)) {
        try { zip.addLocalFile(abs, '', rel); included.push(rel); } catch (_) { /* */ }
      }
    }
    zip.writeZip(dest);
    const meta = {
      id,
      instanceId: null,
      label: label || 'launcher',
      mode: 'config',
      included,
      createdAt: new Date().toISOString(),
      file: dest,
      size: (await fs.stat(dest)).size
    };
    const index = path.join(dir, 'index.json');
    const list = (await fs.pathExists(index)) ? await fs.readJson(index) : [];
    list.push(meta);
    await fs.writeJson(index, list, { spaces: 2 });
    return meta;
  }

  async listLauncherConfig() {
    const index = path.join(CryndelPathVault.backupsDir(), 'launcher', 'index.json');
    if (!(await fs.pathExists(index))) return [];
    return fs.readJson(index);
  }

  async restoreLauncherConfig(backupId) {
    const list = await this.listLauncherConfig();
    const item = list.find((b) => b.id === backupId);
    if (!item) throw new Error('Конфиг-бэкап не найден');
    const zip = new AdmZip(item.file);
    const tmp = path.join(CryndelPathVault.dataDir(), 'restore-tmp');
    await fs.ensureDir(tmp);
    zip.extractAllTo(tmp, true);
    const targets = {
      'settings.json': CryndelPathVault.settingsFile(),
      'users.json': CryndelPathVault.usersFile(),
      'instances.json': CryndelPathVault.instancesFile()
    };
    for (const [rel, dest] of Object.entries(targets)) {
      const src = path.join(tmp, rel);
      if (await fs.pathExists(src)) await fs.copy(src, dest, { overwrite: true });
    }
    await fs.remove(tmp);
    return { ok: true };
  }

  async restore(instance, backupId) {
    const list = await this.list(instance.id);
    const item = list.find((b) => b.id === backupId);
    if (!item) throw new Error('Backup not found');
    // Snapshot the current state first so a restore is itself undoable.
    try { await this.create(instance, 'pre-restore', { full: true }); } catch (_) { /* best effort */ }
    const zip = new AdmZip(item.file);
    const mods = path.join(instance.gameDir, 'mods');
    await fs.ensureDir(mods);
    zip.extractAllTo(instance.gameDir, true);
    const extractedLock = path.join(instance.gameDir, 'lock.json');
    if (await fs.pathExists(extractedLock)) {
      await fs.move(extractedLock, CryndelPathVault.lockfile(instance.id), { overwrite: true });
    }
    const extractedInstance = path.join(instance.gameDir, 'instance.json');
    if (await fs.pathExists(extractedInstance)) await fs.remove(extractedInstance);
    return { ok: true };
  }

  async delete(instanceId, backupId) {
    const index = path.join(this.dir(instanceId), 'index.json');
    const list = (await fs.pathExists(index)) ? await fs.readJson(index) : [];
    const target = list.find((b) => b.id === backupId);
    if (target && target.file && await fs.pathExists(target.file)) {
      try { await fs.remove(target.file); } catch (_) { /* */ }
    }
    const next = list.filter((b) => b.id !== backupId);
    await fs.writeJson(index, next, { spaces: 2 });
    return { ok: true };
  }
}

module.exports = VaultSnapshot;
