const { app, ipcMain, dialog, shell } = require('electron');
const path = require('path');

// Plugin surface: list, install (folder or .zip), toggle, remove, and the
// accumulated warnings so the UI can show "plugin X failed" without dying.
function bindPluginIpc(hub) {
  const permissionLabels = {
    ui: 'Добавление собственных страниц и окон',
    'ui.theme': 'Изменение глобального оформления',
    'settings.read': 'Чтение настроек лаунчера',
    'settings.write': 'Изменение настроек лаунчера',
    'instances.read': 'Чтение списка сборок',
    net: 'Доступ к сети и каталогу Modrinth',
    downloads: 'Сохранение загруженных файлов',
    install: 'Установка модов Modrinth и локальных JAR плагина в сборку',
    wallpaper: 'Применение SVG-обоев, включённых в плагин',
    events: 'Совместимость с API событий старых плагинов'
  };
  const installPlugin = async (zipPath) => {
    const inspected = await hub.plugins.inspectPluginZip(zipPath);
    if (!inspected.ok) return inspected;
    const requested = inspected.permissions;
    const description = requested.length
      ? requested.map((permission) => `• ${permissionLabels[permission]}`).join('\n')
      : 'Плагин не запрашивает дополнительных разрешений.';
    const choice = await dialog.showMessageBox(hub.window || undefined, {
      type: 'question',
      title: 'Разрешения плагина',
      message: `Установить «${inspected.name}»?`,
      detail: `${description}\n\nПлагины могут добавлять только UI-модули и выданные здесь возможности. Установка модов дополнительно попросит подтверждение.`,
      buttons: ['Установить и выдать запрошенные разрешения', 'Установить без разрешений', 'Отмена'],
      defaultId: 0,
      cancelId: 2,
      noLink: true
    });
    if (choice.response === 2) return { ok: false, cancelled: true };
    const granted = choice.response === 0 ? requested : [];
    const result = await hub.plugins.installFromZip(zipPath, granted);
    if (result.ok) await hub.plugins.loadOne(result.id);
    return result;
  };
  const managePermissions = async (pluginId) => {
    const item = (await hub.plugins.list()).find((plugin) => plugin.id === pluginId);
    if (!item) return { ok: false, error: 'Плагин не найден' };
    const requested = item.permissions || [];
    const current = new Set(item.grantedPermissions || []);
    const detail = requested.length
      ? requested.map((permission) => `${current.has(permission) ? '✓' : '○'} ${permissionLabels[permission] || permission}`).join('\n')
      : 'Плагин не запросил дополнительных разрешений.';
    const choice = await dialog.showMessageBox(hub.window || undefined, {
      type: 'question',
      title: 'Разрешения плагина',
      message: `Доступы «${item.name}»`,
      detail,
      buttons: ['Выдать все запрошенные', 'Отозвать все', 'Оставить как есть'],
      defaultId: 2,
      cancelId: 2,
      noLink: true
    });
    if (choice.response === 2) return { ok: false, cancelled: true };
    const grants = choice.response === 0 ? requested : [];
    const result = await hub.plugins.setPermissions(pluginId, grants);
    await hub.plugins.unload(pluginId);
    if (grants.length || !item.disabled) await hub.plugins.loadOne(pluginId);
    return result;
  };
  const reloadPlugins = async () => {
    for (const id of [...hub.plugins.loaded.keys()]) {
      // eslint-disable-next-line no-await-in-loop
      await hub.plugins.unload(id);
    }
    hub.plugins.loaded.clear();
    hub.plugins.hooks.clear();
    return hub.plugins.loadAll();
  };
  ipcMain.handle('plugins:list', async () => hub.plugins.list());
  ipcMain.handle('plugins:ui', async () => hub.plugins.getUiContributions());
  ipcMain.handle('plugins:mods', async () => hub.plugins.getPluginMods());
  ipcMain.handle('plugins:call', async (_e, pluginId, method, args) => hub.plugins.callCapability(pluginId, method, args));
  ipcMain.handle('plugins:permissions', async (_e, pluginId) => managePermissions(pluginId));
  ipcMain.handle('plugins:apiPackStatus', async () => hub.plugins.apiPackStatus());
  ipcMain.handle('plugins:apiPackInstall', async () => {
    const picked = await dialog.showOpenDialog(hub.window || undefined, {
      properties: ['openFile'],
      filters: [{ name: 'Cryndel Plugin API', extensions: ['plcryn'] }]
    });
    if (picked.canceled || !picked.filePaths[0]) return { ok: false, cancelled: true };
    const result = await hub.plugins.installApiPackFromZip(picked.filePaths[0]);
    if (result.ok) await reloadPlugins();
    return result;
  });
  ipcMain.handle('plugins:apiPackRollback', async () => {
    const result = await hub.plugins.rollbackApiPack();
    if (result.ok) await reloadPlugins();
    return result;
  });
  ipcMain.handle('plugins:apiPackReset', async () => {
    const result = await hub.plugins.resetApiPack();
    if (result.ok) await reloadPlugins();
    return result;
  });
  ipcMain.handle('plugins:reload', async () => {
    return reloadPlugins();
  });
  ipcMain.handle('plugins:warnings', async () => hub.plugins.warnings);
  ipcMain.handle('plugins:dir', async () => hub.plugins.dir());
  ipcMain.handle('plugins:openDir', async () => {
    const dir = await hub.plugins.ensure();
    const err = await shell.openPath(dir);
    return err ? { ok: false, error: err } : { ok: true, path: dir };
  });
  ipcMain.handle('plugins:install', async () => {
    const picked = await dialog.showOpenDialog(hub.window || undefined, {
      properties: ['openFile'],
      filters: [{ name: 'Плагин Cryndel', extensions: ['zip'] }]
    });
    if (picked.canceled || !picked.filePaths[0]) return { ok: false, cancelled: true };
    return installPlugin(picked.filePaths[0]);
  });
  ipcMain.handle('plugins:installExample', async () => {
    const examples = [
      ['wallpapers-styles', 'Обои и стили'],
      ['plugin-mod-catalog', 'Каталог плагинных модов'],
      ['test-mod-provider', 'Тестовый мод test.jar']
    ];
    const choice = await dialog.showMessageBox(hub.window || undefined, {
      type: 'question',
      title: 'Примеры плагинов',
      message: 'Какой пример установить?',
      buttons: [...examples.map((item) => item[1]), 'Отмена'],
      defaultId: 0,
      cancelId: examples.length,
      noLink: true
    });
    const selected = examples[choice.response];
    if (!selected) return { ok: false, cancelled: true };
    const zip = path.join(app.getAppPath(), 'examples', 'plugins', `${selected[0]}.zip`);
    return installPlugin(zip);
  });
  ipcMain.handle('plugins:installPath', async (_e, zipPath) => installPlugin(zipPath));
  ipcMain.handle('plugins:remove', async (_e, id) => hub.plugins.remove(id));
  ipcMain.handle('plugins:emit', async (_e, hook, payload) => hub.plugins.emit(hook, payload));
  ipcMain.handle('plugins:toggle', async (_e, id, on) => hub.plugins.toggle(id, on));
  ipcMain.handle('plugins:configGet', async (_e, id) => hub.plugins.readConfig(id));
  ipcMain.handle('plugins:configSet', async (_e, id, key, value) => hub.plugins.patchConfig(id, key, value));
  ipcMain.handle('plugins:schema', async (_e, id) => {
    if (id) return hub.plugins.schemas.get(id) || [];
    const out = {};
    for (const [k, v] of hub.plugins.schemas) out[k] = v;
    return out;
  });
  ipcMain.handle('plugins:nav', async () => hub.plugins.navItems);
}

module.exports = bindPluginIpc;
