const { ipcMain, shell, dialog, clipboard } = require('electron');
const fs = require('fs-extra');

const ALLOW = [
  'modrinth.com',
  'cdn.modrinth.com',
  'cryndel.ru',
  'my.cryndel.ru',
  'play.cryndel.ru',
  'www.cryndel.ru',
  'github.com',
  'adoptium.net',
  'minecraft.net',
  'mojang.com'
];

function hostAllowed(url) {
  try {
    const u = new URL(url);
    if (u.protocol !== 'https:' && u.protocol !== 'http:') return false;
    return ALLOW.some((d) => u.hostname === d || u.hostname.endsWith(`.${d}`));
  } catch (_) {
    return false;
  }
}

function bindSystemIpc(hub) {
  ipcMain.handle('system:openExternal', async (_e, url) => {
    if (!hostAllowed(url)) return { ok: false, error: 'URL not allowed' };
    await shell.openExternal(url);
    return { ok: true };
  });
  ipcMain.handle('system:selectDirectory', async () => {
    const r = await dialog.showOpenDialog(hub.window, { properties: ['openDirectory'] });
    return r.canceled ? null : r.filePaths[0];
  });
  // Opens one of the launcher's own folders in the OS file manager (used by the
  // music card and the settings shortcuts). Only paths inside the launcher data
  // directory or the project tree are accepted, so a bad renderer payload can
  // never open an arbitrary location.
  ipcMain.handle('system:openPath', async (_e, rel) => {
    const path = require('path');
    const fsx = require('fs-extra');
    const CryndelPathVault = require('../utils/paths');
    const roots = [
      path.join(__dirname, '..', '..'),
      CryndelPathVault.userRoot(),
      CryndelPathVault.instancesRoot()
    ].map((p) => path.resolve(p));
    const target = path.resolve(path.join(__dirname, '..', '..'), String(rel || ''));
    const allowed = roots.some((r) => target === r || target.startsWith(r + path.sep));
    if (!allowed) return { ok: false, error: 'Путь не разрешён' };
    await fsx.ensureDir(target).catch(() => {});
    const err = await shell.openPath(target);
    return err ? { ok: false, error: err } : { ok: true, path: target };
  });
  ipcMain.handle('system:detectJava', async () => hub.java.detect());
  ipcMain.handle('system:copyToClipboard', async (_e, text) => {
    clipboard.writeText(String(text || ''));
    return { ok: true };
  });
  ipcMain.handle('system:getStorageInfo', async () => {
    const instances = await hub.instances.list();
    return hub.health.storageInfo(instances);
  });
  ipcMain.handle('system:clearCache', async (_e, type) => hub.health.clearCache(type));
  ipcMain.handle('health:getStatus', async (_e, instanceId) => {
    const inst = instanceId ? await hub.instances.get(instanceId) : null;
    return hub.health.getStatus(inst);
  });
  ipcMain.handle('health:analyzeCrash', async (_e, instanceId) => {
    const inst = instanceId ? await hub.instances.get(instanceId) : null;
    return hub.health.analyzeCrash(inst);
  });
  ipcMain.handle('health:fixInstance', async (_e, instanceId, action) => {
    const inst = instanceId ? await hub.instances.get(instanceId) : null;
    return hub.health.fixInstance(inst, action);
  });
  ipcMain.handle('health:autoFix', async (_e, instanceId) => {
    const inst = await hub.instances.get(instanceId);
    if (!inst) throw new Error('Сборка не найдена');
    return hub.health.autoFix(inst, hub);
  });
  ipcMain.handle('health:getTimeline', async (_e, instanceId) => hub.health.getTimeline(instanceId));
  ipcMain.handle('system:gpus', async () => {
    const os = require('os');
    const { execFile } = require('child_process');
    const { promisify } = require('util');
    const execFileAsync = promisify(execFile);
    const out = [{ id: 'auto', name: 'Авто' }];
    try {
      if (os.platform() === 'win32') {
        const { stdout } = await execFileAsync('wmic', ['path', 'win32_VideoController', 'get', 'Name'], { windowsHide: true });
        stdout.split(/\r?\n/).map((s) => s.trim()).filter((s) => s && s !== 'Name').forEach((name, i) => {
          out.push({ id: 'gpu-' + i, name });
        });
      } else {
        const { stdout } = await execFileAsync('sh', ['-c', 'lspci 2>/dev/null | grep -i -E "vga|3d|display" || true']);
        stdout.split(/\n/).map((s) => s.trim()).filter(Boolean).forEach((line, i) => {
          out.push({ id: 'gpu-' + i, name: line.replace(/^.*controller:\s*/i, '') });
        });
      }
    } catch (_) { /* */ }
    return out;
  });
  ipcMain.handle('discord:toggle', async (_e, on) => {
    if (on) {
      const r = await hub.discord.connect();
      return { ok: Boolean(r && r.ok !== false), ready: hub.discord.ready, error: hub.discord.lastError || '', needsAppId: hub.discord.needsAppId };
    }
    await hub.discord.disconnect();
    return { ok: true, ready: false, error: '', needsAppId: hub.discord.needsAppId };
  });
  ipcMain.handle('discord:status', async () => ({
    ready: Boolean(hub.discord && hub.discord.ready),
    error: (hub.discord && hub.discord.lastError) || '',
    clientId: (hub.discord && hub.discord.clientId) || '',
    needsAppId: Boolean(hub.discord && hub.discord.needsAppId)
  }));
  ipcMain.handle('lockfile:load', async (_e, instanceId) => hub.lockfile.load(instanceId));
  ipcMain.handle('lockfile:export', async (_e, instanceId) => hub.instances.exportMrpack(instanceId, hub.window));
  ipcMain.handle('app:getVersion', async () => {
    const pkg = await fs.readJson(require('path').join(__dirname, '..', '..', 'package.json'));
    return pkg.version;
  });

  // Interface scale. Chromium's native zoom is used instead of a CSS `zoom` on
  // the content areas: a zoomed subtree reports its layout rect in zoomed units
  // while hit-testing still applies the zoom again, so every click in a scaled
  // UI landed at the wrong coordinates (the carousel close button, the nav rail
  // and the window buttons all went dead at any scale but 100%). Native zoom
  // keeps geometry and hit-testing in step.
  ipcMain.handle('window:setZoom', async (_e, factor) => {
    const win = hub.panes && hub.panes.win;
    if (!win || win.isDestroyed()) return { ok: false, zoom: 1 };
    const f = Math.max(0.5, Math.min(2, Number(factor) || 1));
    try { win.webContents.setZoomFactor(f); } catch (_) { /* */ }
    try { win.webContents.setVisualZoomLevelLimits(1, 1); } catch (_) { /* */ }
    return { ok: true, zoom: f };
  });
  ipcMain.handle('window:setSize', async (_e, width, height) => {
    const win = hub.panes && hub.panes.win;
    if (!win || win.isDestroyed()) return { ok: false, error: 'Окно лаунчера недоступно' };
    const { screen } = require('electron');
    const area = screen.getDisplayMatching(win.getBounds()).workArea;
    const minWidth = Math.min(760, area.width);
    const minHeight = Math.min(520, area.height);
    const nextWidth = Math.round(Math.max(minWidth, Math.min(area.width, Number(width) || 1024)));
    const nextHeight = Math.round(Math.max(minHeight, Math.min(area.height, Number(height) || 700)));
    if (win.isMaximized()) win.unmaximize();
    win.setSize(nextWidth, nextHeight, true);
    win.center();
    return { ok: true, width: nextWidth, height: nextHeight };
  });

  // Window controls. Each returns the fresh window state so the renderer can
  // repaint its title bar without guessing.
  ipcMain.handle('window:minimize', async () => hub.panes.minimize());
  ipcMain.handle('window:maximize', async () => hub.panes.toggleMaximize());
  ipcMain.handle('window:fullscreen', async () => hub.panes.toggleFullScreen());
  ipcMain.handle('window:close', async () => hub.panes.close());
  ipcMain.handle('window:show', async () => {
    hub.panes.show();
    return hub.panes.state();
  });
  ipcMain.handle('window:state', async () => hub.panes.state());
}

module.exports = { bindSystemIpc, hostAllowed };
