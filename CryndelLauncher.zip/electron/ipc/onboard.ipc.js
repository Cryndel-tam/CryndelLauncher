const { app, ipcMain } = require('electron');
const fs = require('fs-extra');
const path = require('path');
const logger = require('../utils/logger');
const resourcePath = require('../utils/resource-path');

function sendProgress(hub, p) {
  if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('game:progress', p);
}

async function readJsonSafe(file, fallback) {
  try {
    if (await fs.pathExists(file)) return fs.readJson(file);
  } catch (_) { /* */ }
  return fallback;
}

async function installExtraMods(hub, instance, send) {
  const file = resourcePath('extra-mods.json', { app });
  const catalog = await readJsonSafe(file, { mods: [] });
  let n = 0;
  for (const mod of catalog.mods || []) {
    const url = (mod.downloads || [])[0];
    if (!url) continue;
    n += 1;
    send({ stage: 'mods', pct: 70 + Math.min(20, n * 4), message: `Доп. мод: ${mod.name}` });
    try {
      const filename = path.basename(String(url).split('?')[0]) || `${mod.id}.jar`;
      await hub.mods.downloadAndPlace(instance.id, url, filename, mod.id, null, null, {
        versionNumber: '',
        downloadUrl: url
      });
    } catch (err) {
      logger.warn('extra mod failed', { id: mod.id, message: err.message });
    }
  }
}

async function importPackFromCatalog(hub, pack, send) {
  const url = (pack.downloads || [])[0];
  if (!url) return null;
  send({ stage: 'pack', pct: 28, message: `Качаю сборку «${pack.name}»…` });
  const dest = await hub.inbox.downloadUrl(url, path.basename(String(url).split('?')[0]) || `${pack.id}.mrpack`, (p) => {
    send({ stage: 'pack', pct: 28 + Math.round((p.pct || 0) * 0.3), loaded: p.loaded, total: p.total, message: p.filename || pack.name });
  });
  send({ stage: 'pack', pct: 62, message: 'Собираю сборку…' });
  const res = await hub.instances.importPackFile(dest, send, {
    name: pack.name,
    mcVersion: pack.mcVersion || '1.21.11',
    modLoader: pack.modLoader || 'fabric'
  });
  return res.instance || null;
}

function bindOnboardIpc(hub) {
  ipcMain.handle('onboard:comfort', async (_e, nick, opts = {}) => {
    const send = (p) => sendProgress(hub, p);
    send({ stage: 'account', pct: 2, message: 'Создаю профиль…' });
    const user = await hub.auth.createOffline(nick, { onboardingCompleted: true, surveyAnswer: 'cryndel' });

    await hub.settings.set('ui.language', 'ru');
    await hub.settings.set('game.language', 'ru');
    await hub.settings.set('game.toggleSprint', true);

    send({ stage: 'java', pct: 8, message: 'Проверяю Java…' });
    await hub.java.ensure(21, send);

    send({ stage: 'client', pct: 16, message: 'Готовлю Fabric 1.21.11…' });
    let instance = null;
    if (opts.packId) {
      const catalog = await readJsonSafe(resourcePath('comfort-packs.json', { app }), { packs: [] });
      const pack = (catalog.packs || []).find((p) => p.id === opts.packId);
      if (!pack) throw new Error('Выбранная сборка не найдена в каталоге. Обновите лаунчер и попробуйте снова.');
      try {
        instance = await importPackFromCatalog(hub, pack, send);
      } catch (err) {
        logger.warn('comfort pack import failed', { packId: pack.id, message: err.message });
        throw new Error(`Не удалось установить сборку «${pack.name}»: ${err.message}`);
      }
      if (!instance) throw new Error(`Не удалось импортировать сборку «${pack.name}».`);
    }
    if (!instance) {
      send({ stage: 'pack', pct: 22, message: 'Создаю Fabric 1.21.11…' });
      instance = await hub.instances.create({
        name: opts.packName || 'Cryndel Fabric 1.21.11',
        type: 'official',
        sourceBuildId: 'cryndel-fabric-12111',
        group: 'Cryndel',
        mcVersion: '1.21.11',
        modLoader: 'fabric',
        memoryMb: 4096,
        quickPlay: { enabled: true, server: 'cryndel.ru', port: 25565 }
      });
    }
    instance = await hub.instances.update(instance.id, {
      quickPlay: { enabled: true, server: 'cryndel.ru', port: 25565 }
    });

    if (opts.cryem !== false) {
      send({ stage: 'mods', pct: 78, message: 'Cryem от Cryndel Team…' });
      await installExtraMods(hub, instance, send);
    }

    await hub.auth.patchCurrent({ preferences: { selectedInstanceId: instance.id } });
    send({ stage: 'done', pct: 100, message: 'Готово — игру не запускаю' });
    return { ok: true, user, instance };
  });

  ipcMain.handle('java:ensure', async (_e, major) => {
    const send = (p) => sendProgress(hub, p);
    const exe = await hub.java.ensure(major || 21, send);
    return { ok: true, path: exe };
  });
}

module.exports = bindOnboardIpc;
