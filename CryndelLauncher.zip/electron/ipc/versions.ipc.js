const { ipcMain } = require('electron');
const axios = require('axios');

function bindVersionsIpc(hub) {
  ipcMain.handle('versions:manifest', async () => {
    const { data } = await axios.get('https://launchermeta.mojang.com/mc/game/version_manifest_v2.json', {
      timeout: 20000,
      headers: { 'User-Agent': 'CryndelLauncher/1.0.0 (contact@cryndel.ru)' }
    });
    return data;
  });
  ipcMain.handle('versions:ensure', async (_e, mcVersion) => {
    return hub.game.ensureVersion(mcVersion, (p) => {
      if (hub.window) hub.window.webContents.send('game:progress', p);
    });
  });
}

module.exports = bindVersionsIpc;
