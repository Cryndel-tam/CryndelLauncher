const { ipcMain } = require('electron');

function bindGameIpc(hub) {
  ipcMain.handle('game:launch', async (_e, instanceId, extra) => {
    const inst = await hub.instances.get(instanceId);
    if (!inst) throw new Error('Instance not found');
    const user = await hub.auth.getCurrent();
    if (!user) throw new Error('No profile');
    hub.playtime.start(instanceId);
    const send = (p) => {
      if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('game:progress', { instanceId, ...p });
    };
    if (hub.hauler && hub.hauler.reset) hub.hauler.reset();
    send({ stage: 'start', pct: 1, message: 'Старт…' });
    let result;
    try {
      result = await hub.game.launch(inst, user, extra || {});
    } catch (err) {
      hub.game.preparing = false;
      if (hub.hauler && hub.hauler.reset) hub.hauler.reset();
      if (/отмен/i.test(String(err && err.message))) {
        send({ stage: 'cancel', pct: 0, message: 'Отменено' });
        return { ok: false, cancelled: true };
      }
      throw err;
    }
    await hub.instances.update(instanceId, { lastPlayedAt: new Date().toISOString() });
    await hub.auth.bumpLaunch();
    await hub.timeline.append(instanceId, 'launch', 'Launch started');
    const all = await hub.settings.getAll().catch(() => ({}));
    if (all.launcher && all.launcher.discordRpc !== false) {
      try { await hub.discord.setPlaying(inst, user); } catch (_) { /* */ }
    }
    // Sync the launcher window with the running game. Default: drop off the
    // taskbar (minimise + skip-taskbar) so it does not clutter the bar while the
    // player is in Minecraft; the tray option hides it fully, and `closeOnLaunch`
    // really closes it. main.js reveals the window again once the game exits.
    if (hub.window && !hub.window.isDestroyed()) {
      const L = all.launcher || {};
      if (L.closeOnLaunch) {
        hub.panes.close();
      } else if (L.hideToTrayOnLaunch) {
        hub.panes.hide();
      } else if (L.minimizeToTray !== false) {
        hub.panes.hideFromTaskbar();
      }
    }
    return result;
  });
  ipcMain.handle('game:kill', async (_e, instanceId) => hub.game.kill(instanceId));
  ipcMain.handle('game:isRunning', async (_e, instanceId) => hub.game.isRunning(instanceId));
  ipcMain.handle('game:anyRunning', async () => hub.game.anyRunning());
  ipcMain.handle('game:cancel', async () => {
    hub.game.cancelJob();
    if (hub.hauler && hub.hauler.cancelAll) hub.hauler.cancelAll();
    if (hub.java && hub.java._javaAbort) {
      try { hub.java._javaAbort.abort(); } catch (_) { /* */ }
    }
    setTimeout(() => { if (hub.hauler && hub.hauler.reset) hub.hauler.reset(); }, 80);
    if (hub.window && !hub.window.isDestroyed()) {
      hub.window.webContents.send('game:progress', { stage: 'cancel', pct: 0, message: 'Отменено' });
    }
    return { ok: true };
  });
}

module.exports = bindGameIpc;
