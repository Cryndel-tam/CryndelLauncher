const { ipcMain } = require('electron');
const fs = require('fs-extra');
const path = require('path');

// Writes the "extended settings" the build wizard offers: language, servers.dat
// and toggle-key bindings, directly into the instance folder. This runs right
// after create so the very first launch already has them, instead of only
// applying on the next game start.
async function applyExtended(hub, inst) {
  const all = await hub.settings.getAll().catch(() => ({}));
  const gameDir = inst.gameDir;
  await fs.ensureDir(gameDir);
  const optionsFile = path.join(gameDir, 'options.txt');
  let text = '';
  try { if (await fs.pathExists(optionsFile)) text = await fs.readFile(optionsFile, 'utf8'); } catch (_) { text = ''; }
  const patch = (key, value) => {
    const line = `${key}:${value}`;
    if (new RegExp(`^${key}:`, 'm').test(text)) text = text.replace(new RegExp(`^${key}:.*$`, 'm'), line);
    else text = `${text}${text && !text.endsWith('\n') ? '\n' : ''}${line}\n`;
  };
  if (inst.autoLang !== false) {
    // Per-pack language wins over the global one: the wizard asks for it
    // explicitly, so the pack must not silently follow the launcher.
    const lang = inst.language || (all.ui && all.ui.language) || (all.game && all.game.language) || 'ru';
    const code = lang === 'en' || lang === 'en_us' ? 'en_us' : 'ru_ru';
    patch('lang', code);
    patch('forceUnicodeFont', code === 'ru_ru' ? 'true' : 'false');
  }
  if (inst.guiScale) patch('guiScale', String(inst.guiScale));
  if (inst.toggleKeys) {
    patch('key_key.sprint', 'key.keyboard.left.shift');
    patch('toggleSprint', 'true');
    patch('toggleSneak', 'true');
  }
  if (inst.graphics && inst.graphics !== 'default') patch('graphicsMode', inst.graphics);
  await fs.writeFile(optionsFile, text, 'utf8');
  if (inst.addServer !== false) {
    await hub.game.writeServersDat(gameDir, {
      ...inst,
      quickPlay: {
        enabled: Boolean(inst.quickPlay && inst.quickPlay.enabled),
        server: inst.serverHost || (inst.quickPlay && inst.quickPlay.server) || 'cryndel.ru',
        port: Number(inst.serverPort || (inst.quickPlay && inst.quickPlay.port) || 25565)
      }
    });
  }
  return { ok: true };
}

function bindInstancesIpc(hub) {
  ipcMain.handle('instances:list', async () => hub.instances.list());
  ipcMain.handle('instances:get', async (_e, id) => hub.instances.get(id));
  ipcMain.handle('instances:create', async (_e, dto) => {
    const inst = await hub.instances.create(dto || {});
    const user = await hub.auth.getCurrent();
    if (user) await hub.auth.patchCurrent({ preferences: { selectedInstanceId: inst.id } });
    try { await applyExtended(hub, inst); } catch (_) { /* optional */ }
    return inst;
  });
  ipcMain.handle('instances:createFromBuild', async (_e, buildId, name) => {
    const inst = await hub.instances.createFromBuild(buildId, name);
    await hub.auth.patchCurrent({ preferences: { selectedInstanceId: inst.id } });
    try { await applyExtended(hub, inst); } catch (_) { /* optional */ }
    return inst;
  });
  ipcMain.handle('instances:delete', async (_e, id) => hub.instances.delete(id));
  ipcMain.handle('instances:update', async (_e, id, patch) => hub.instances.update(id, patch));
  ipcMain.handle('instances:openFolder', async (_e, id) => hub.instances.openFolder(id));
  ipcMain.handle('instances:exportMrpack', async (_e, id) => hub.instances.exportMrpack(id, hub.window));
  ipcMain.handle('instances:importMrpack', async (_e, meta) => {
    return hub.instances.importMrpack(hub.window, (p) => {
      if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('game:progress', p);
    }, meta || {});
  });
  ipcMain.handle('instances:catalog', async () => hub.instances.loadBuilds());
  ipcMain.handle('instances:select', async (_e, id) => {
    await hub.auth.patchCurrent({ preferences: { selectedInstanceId: id } });
    return { ok: true };
  });
  ipcMain.handle('instances:applyExtended', async (_e, id) => {
    const inst = await hub.instances.get(id);
    if (!inst) throw new Error('Сборка не найдена');
    return applyExtended(hub, inst);
  });
  ipcMain.handle('instances:rename', async (_e, id, name) => {
    return hub.instances.update(id, { name });
  });
  ipcMain.handle('instances:patchSodium', async (_e, id) => {
    const inst = await hub.instances.get(id);
    if (!inst) throw new Error('Сборка не найдена');
    const cfgDir = path.join(inst.gameDir, 'config');
    await fs.ensureDir(cfgDir);
    const file = path.join(cfgDir, 'sodium-options.json');
    const cfg = {
      quality: { weather_quality: 'DEFAULT', leaves_quality: 'DEFAULT', enable_vignette: false },
      performance: { chunk_update_threads: 0, always_defer_chunk_updates: true },
      notifications: { hide_donation_button: true }
    };
    await fs.writeJson(file, cfg, { spaces: 2 });
    return { ok: true };
  });
}

module.exports = bindInstancesIpc;
module.exports.applyExtended = applyExtended;
