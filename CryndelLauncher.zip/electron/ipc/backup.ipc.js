const { ipcMain } = require('electron');

function bindBackupIpc(hub) {
  ipcMain.handle('backup:create', async (_e, instanceId, label) => {
    const inst = await hub.instances.get(instanceId);
    const meta = await hub.backups.create(inst, label);
    await hub.timeline.append(instanceId, 'backup', `Snapshot ${meta.id}`);
    return meta;
  });
  // "Back up everything" — one snapshot per pack, plus the launcher's own
  // settings/users so a restore can bring back the whole profile.
  ipcMain.handle('backup:createAll', async (_e, label) => {
    const instances = await hub.instances.list();
    const out = [];
    for (const inst of instances) {
      try {
        const meta = await hub.backups.create(inst, label || 'full');
        out.push({ instanceId: inst.id, name: inst.name, ...meta });
        await hub.timeline.append(inst.id, 'backup', `Snapshot ${meta.id}`);
      } catch (err) {
        out.push({ instanceId: inst.id, name: inst.name, error: err.message });
      }
    }
    try {
      const cfg = await hub.backups.createLauncherConfig();
      out.push({ instanceId: null, name: 'Лаунчер', ...cfg });
    } catch (_) { /* optional */ }
    return { ok: true, items: out };
  });
  ipcMain.handle('backup:list', async (_e, instanceId) => hub.backups.list(instanceId));
  ipcMain.handle('backup:listLauncher', async () => hub.backups.listLauncherConfig());
  ipcMain.handle('backup:restoreLauncher', async (_e, backupId) => hub.backups.restoreLauncherConfig(backupId));
  ipcMain.handle('backup:restore', async (_e, instanceId, backupId) => {
    const inst = await hub.instances.get(instanceId);
    const r = await hub.backups.restore(inst, backupId);
    await hub.timeline.append(instanceId, 'backup', `Restored ${backupId}`);
    return r;
  });
  ipcMain.handle('backup:delete', async (_e, instanceId, backupId) => hub.backups.delete(instanceId, backupId));
}

module.exports = bindBackupIpc;
