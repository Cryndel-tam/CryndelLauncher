const { ipcMain, dialog } = require('electron');
const { applyExtended } = require('./instances.ipc');

// `.mpcryn` publish / import. Publishing writes into the launcher's Downloads
// folder by default so the result immediately shows up in "Загрузки"; the user
// can still pick another location.
function bindPublishIpc(hub) {
  ipcMain.handle('publish:build', async (_e, instanceId, destPath) => {
    try {
      const inst = await hub.instances.get(instanceId);
      if (!inst) throw new Error('Сборка не найдена');
      let target = destPath;
      if (!target) {
        const picked = await dialog.showSaveDialog(hub.window || undefined, {
          title: 'Опубликовать сборку',
          defaultPath: `${inst.name}.mpcryn`,
          filters: [{ name: 'Сборка Cryndel', extensions: ['mpcryn'] }]
        });
        if (picked.canceled || !picked.filePath) return { ok: false, cancelled: true };
        target = picked.filePath;
      }
      return await hub.publisher.publish(instanceId, target);
    } catch (err) {
      return { ok: false, error: err.message };
    }
  });

  ipcMain.handle('publish:inspect', async (_e, filePath) => {
    try { return { ok: true, manifest: await hub.publisher.inspect(filePath) }; } catch (err) { return { ok: false, error: err.message }; }
  });

  ipcMain.handle('publish:pick', async () => {
    const picked = await dialog.showOpenDialog(hub.window || undefined, {
      properties: ['openFile'],
      filters: [{ name: 'Сборка Cryndel', extensions: ['mpcryn'] }]
    });
    if (picked.canceled || !picked.filePaths[0]) return { ok: false, cancelled: true };
    const filePath = picked.filePaths[0];
    try {
      const manifest = await hub.publisher.inspect(filePath);
      return { ok: true, path: filePath, manifest };
    } catch (err) {
      return { ok: false, error: err.message };
    }
  });

  // Import: the manifest's name is uniquified by the instance manager, and the
  // instance folder is created from that name so pack name == folder name.
  ipcMain.handle('publish:import', async (_e, filePath, name) => {
    try {
      const manifest = await hub.publisher.inspect(filePath);
      const inst = await hub.instances.create({
        name: name || manifest.name || 'Импорт',
        mcVersion: manifest.mcVersion,
        modLoader: manifest.modLoader,
        modLoaderVersion: manifest.loaderVersion,
        memoryMb: manifest.memoryMb,
        language: manifest.language,
        addServer: manifest.addServer,
        serverHost: manifest.serverHost,
        serverPort: manifest.serverPort,
        group: 'Импорт'
      });
      const res = await hub.publisher.extract(filePath, inst, (p) => {
        if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('game:progress', { stage: 'import', ...p });
      });
      try { await applyExtended(hub, await hub.instances.get(inst.id)); } catch (_) { /* optional */ }
      return { ok: true, instance: await hub.instances.get(inst.id), files: res.files };
    } catch (err) {
      return { ok: false, error: err.message };
    }
  });
}

module.exports = bindPublishIpc;
