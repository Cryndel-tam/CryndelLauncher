// Keeps every popup inside the in-app browser instead of spawning a bare
// Electron window (the white "Electron" screen the user kept seeing when a
// download or a `target=_blank` link opened a new window).
//
// The subtle part is ordering: `browser-window-created` is emitted
// synchronously from inside `new BrowserWindow()`, so when the launcher's own
// window is being built, `panes.win` has not been assigned yet. Checking only
// `win === panes.win` therefore failed for the main window, the guard destroyed
// it ~30 ms later, and the app quit right after logging "kernel ready".
// `panes.creating` covers that window; `allowed` remembers the rest.
const POPUP_URL_RE = /^https?:\/\//i;

function installPopupGuard({ app, panes, routeToBrowser }) {
  const allowed = new WeakSet();

  app.on('browser-window-created', (_e, win) => {
    const main = panes && panes.win;
    if (main && win === main) { allowed.add(win); return; }
    if (panes && panes.creating) { allowed.add(win); return; }
    if (allowed.has(win)) return;

    const route = () => {
      let url = '';
      try { url = (win.webContents && win.webContents.getURL()) || ''; } catch (_) { /* */ }
      if (POPUP_URL_RE.test(url)) routeToBrowser(url);
    };

    try {
      win.webContents.setWindowOpenHandler(({ url }) => {
        routeToBrowser(url);
        return { action: 'deny' };
      });
      win.webContents.on('will-navigate', (ev, url) => {
        if (POPUP_URL_RE.test(url)) {
          ev.preventDefault();
          routeToBrowser(url);
        }
      });
      win.webContents.on('did-start-navigation', (_ev, url) => {
        if (POPUP_URL_RE.test(url)) {
          routeToBrowser(url);
          setTimeout(() => { try { win.destroy(); } catch (_) { /* */ } }, 0);
        }
      });
    } catch (_) { /* */ }

    // Give the popup one tick to receive its target URL, then close it. If the
    // URL never arrives (a bare `window.open()`), it is still destroyed so no
    // blank Electron window is ever left on screen.
    setTimeout(() => { route(); try { win.destroy(); } catch (_) { /* */ } }, 30);
  });

  return allowed;
}

module.exports = { installPopupGuard };
