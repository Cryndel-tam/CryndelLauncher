const logger = require('./utils/logger');

class PulseRefresh {
  setup() {
    try {
      const { autoUpdater } = require('electron-updater');
      autoUpdater.autoDownload = false;
      autoUpdater.on('error', (err) => logger.warn('updater', { message: err.message }));
      autoUpdater.checkForUpdates().catch(() => {});
    } catch (err) {
      logger.debug('updater skipped', { message: err.message });
    }
  }
}

module.exports = PulseRefresh;
