import { el } from '../utils.js';
import { api } from '../api.js';

export async function screenshotsWidget(host, limit = 6) {
  const shots = await api.screenshots.list(limit).catch(() => []);
  const grid = el('div', { class: 'grid-cards' });
  for (const s of shots) {
    const c = el('div', { class: 'card' });
    c.appendChild(el('div', { text: s.name }));
    c.appendChild(el('button', { class: 'btn btn-ghost', text: 'Open', onclick: () => api.screenshots.open(s.path) }));
    grid.appendChild(c);
  }
  host.appendChild(grid);
}
