import { el } from '../utils.js';

export function lockfileViewer(lock) {
  const box = el('div', { class: 'card' });
  box.appendChild(el('strong', { text: `lock v${lock.version} · ${lock.loader} ${lock.mcVersion}` }));
  for (const e of lock.entries || []) {
    box.appendChild(el('div', { class: 'mr-meta', text: `${e.filename} ${e.pinned ? '[pin]' : ''}` }));
  }
  return box;
}
