import { el } from '../utils.js';
import { api } from '../api.js';
import { toast } from '../state.js';

export function nickChanger(current) {
  const wrap = el('div', { class: 'row' });
  const input = el('input', { class: 'field', value: current || '' });
  wrap.appendChild(input);
  wrap.appendChild(el('button', { class: 'btn', text: 'Сменить', onclick: async () => {
    try {
      await api.liveNick.change(input.value.trim());
      toast('Ник отправлен');
    } catch (e) {
      toast(e.message, 'bad');
    }
  } }));
  return wrap;
}
