import { store } from './state.js';

export async function loadLocale(lang) {
  const url = `locales/${lang}.json`;
  try {
    const res = await fetch(url);
    store.dict = await res.json();
    store.lang = lang;
    document.documentElement.lang = lang === 'en' ? 'en' : 'ru';
  } catch (_) {
    store.dict = {};
  }
}

export function t(key, fallback) {
  const v = store.dict && store.dict[key];
  return v || fallback || key;
}
