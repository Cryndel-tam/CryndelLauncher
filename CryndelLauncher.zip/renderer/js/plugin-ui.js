import { api } from './api.js';
import { toast } from './state.js';
import { modal } from './ui.js';

function srcdoc(page) {
  const css = String(page.css || '');
  const html = String(page.html || '');
  const theme = getComputedStyle(document.documentElement);
  const vars = {
    text: theme.getPropertyValue('--text').trim() || '#eef2fb',
    muted: theme.getPropertyValue('--muted').trim() || '#a9b3c7',
    accent: theme.getPropertyValue('--accent').trim() || '#91aaff',
    panel: theme.getPropertyValue('--panel-2').trim() || 'rgba(31,38,51,.92)',
    line: theme.getPropertyValue('--line').trim() || 'rgba(220,230,255,.12)'
  };
  return `<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob: https:; media-src data: blob: https:; connect-src 'none'; form-action 'none'; base-uri 'none'"><meta name="viewport" content="width=device-width,initial-scale=1"><style>:root{--text:${vars.text};--muted:${vars.muted};--accent:${vars.accent};--panel:${vars.panel};--line:${vars.line}}html,body{margin:0;min-height:100%;font:14px system-ui,sans-serif;color:var(--text);background:transparent}body{padding:18px;box-sizing:border-box}button,input,select,textarea{font:inherit}button{cursor:pointer}${css}</style><script>
(() => {
  let seq = 0;
  const pending = new Map();
  window.addEventListener('message', (event) => {
    const data = event.data || {};
    if (data.type !== 'cryndel-result' || !pending.has(data.id)) return;
    const task = pending.get(data.id);
    pending.delete(data.id);
    if (data.ok) task.resolve(data.value);
    else task.reject(new Error(data.error || 'Вызов Plugin API не выполнен'));
  });
  const send = (type, value) => parent.postMessage({ type, pluginId: ${JSON.stringify(page.pluginId)}, value }, '*');
  window.cryndel = {
    call(method, ...args) {
      const id = ++seq;
      return new Promise((resolve, reject) => {
        pending.set(id, { resolve, reject });
        parent.postMessage({ type: 'cryndel-call', id, pluginId: ${JSON.stringify(page.pluginId)}, method, args }, '*');
      });
    },
    toast(text, kind = 'ok') { return this.call('ui.toast', text, kind); },
    modal(options) { send('cryndel-modal', options || {}); },
    closeModal() { send('cryndel-close-modal', {}); }
  };
  window.CryndelPlugin = window.cryndel;
})();
</script></head><body>${html}</body></html>`;
}

export function createPluginFrame(page, className = 'plugin-frame') {
  const frame = document.createElement('iframe');
  frame.className = className;
  frame.title = page.title || 'Страница плагина';
  frame.setAttribute('sandbox', 'allow-scripts');
  frame.setAttribute('referrerpolicy', 'no-referrer');
  frame.srcdoc = srcdoc(page);
  return frame;
}

async function invoke(pluginId, method, args) {
  if (['settings.set', 'downloads.save', 'install.modrinth', 'install.localMod', 'wallpaper.set'].includes(method)) {
    const labels = {
      'settings.set': `разрешить плагину изменить настройку «${String(args[0] || '')}»`,
      'downloads.save': `разрешить плагину скачать файл «${String(args[1] || args[0] || '')}»`,
      'install.modrinth': `разрешить плагину установить проект в сборку «${String(args[0] || '')}»`,
      'install.localMod': `установить локальный мод из плагина в сборку «${String(args[0] || '')}»`,
      'wallpaper.set': 'применить файл обоев из папки плагина'
    };
    if (!window.confirm(`Плагин «${pluginId}» просит ${labels[method]}. Продолжить?`)) {
      throw new Error('Действие отменено пользователем');
    }
  }
  return api.plugins.call(pluginId, method, args);
}

export function connectPluginFrame(frame, pluginId, onModal, onClose) {
  const listener = async (event) => {
    if (event.source !== frame.contentWindow) return;
    const data = event.data || {};
    if (data.pluginId !== pluginId) return;
    if (data.type === 'cryndel-modal') {
      if (onModal && data.value && typeof data.value === 'object'
        && String(data.value.html || '').length <= 128 * 1024
        && String(data.value.css || '').length <= 64 * 1024) onModal(data.value);
      return;
    }
    if (data.type === 'cryndel-close-modal') {
      if (onClose) onClose();
      return;
    }
    if (data.type !== 'cryndel-call' || !Number.isInteger(data.id) || typeof data.method !== 'string') return;
    try {
      const value = await invoke(pluginId, data.method, Array.isArray(data.args) ? data.args : []);
      frame.contentWindow.postMessage({ type: 'cryndel-result', id: data.id, ok: true, value }, '*');
    } catch (err) {
      frame.contentWindow.postMessage({
        type: 'cryndel-result',
        id: data.id,
        ok: false,
        error: err.message || String(err)
      }, '*');
      if (err.message !== 'Действие отменено пользователем') toast(err.message || 'Вызов Plugin API не выполнен', 'bad');
    }
  };
  window.addEventListener('message', listener);
  return () => window.removeEventListener('message', listener);
}

export function openPluginModal(pluginId, options = {}) {
  let off = () => {};
  const host = modal({
    title: String(options.title || '').slice(0, 80),
    class: 'plugin-modal',
    onClose: () => off()
  });
  const page = { ...options, pluginId, title: options.title || 'Окно плагина' };
  const frame = createPluginFrame(page, 'plugin-frame plugin-modal-frame');
  host.body.appendChild(frame);
  off = connectPluginFrame(frame, pluginId, (next) => {
    host.close();
    openPluginModal(pluginId, next);
  }, () => host.close());
  const originalClose = host.close;
  host.close = () => { off(); originalClose(); };
  return host;
}
