const listeners = new Map();

export const bus = {
  on(ev, fn) {
    if (!listeners.has(ev)) listeners.set(ev, new Set());
    listeners.get(ev).add(fn);
    return () => listeners.get(ev).delete(fn);
  },
  emit(ev, payload) {
    const set = listeners.get(ev);
    if (!set) return;
    for (const fn of set) fn(payload);
  }
};

export const store = {
  user: null,
  instances: [],
  selectedId: null,
  settings: null,
  route: '/',
  toasts: [],
  lang: 'ru',
  dict: {},
  progress: null,
  busy: false,
  running: false
};

export function toast(text, kind = 'ok') {
  const id = Date.now() + Math.random();
  store.toasts.push({ id, text, kind });
  bus.emit('toast');
  bus.emit('toast:new', { id, text, kind });
  const ui = (store.settings && store.settings.ui) || {};
  const dur = Number(ui.toastDuration);
  const life = dur > 0 ? dur : 4200;
  setTimeout(() => {
    store.toasts = store.toasts.filter((t) => t.id !== id);
    bus.emit('toast');
  }, life);
}

export function t(key) {
  return store.dict[key] || key;
}
