import { api } from '../api.js';
import { store, toast } from '../state.js';
import { el } from '../utils.js';
import { go } from '../router.js';
import { modal, drawSkin3d } from '../ui.js';
import { svg } from '../icons.js';
import { t } from '../i18n.js';
import {
  initSounds, musicTracks, currentTrack, playMusic,
  toggleMusic, nextTrack, prevTrack, onMusicChange, isPlaying
} from '../sound.js';

const SLIDES = [
  {
    id: 'start',
    title: 'Как начать играть',
    text: 'Выбери сборку внизу, нажми ИГРАТЬ. Моды — Скачай с модринта в 1 клик, скачается автоматически и зависимости ).',
    art: 'linear-gradient(rgba(7, 8, 12, .35), rgba(7, 8, 12, .35)), url("https://ms.cryndel.ru/f6.png") center / cover no-repeat'
  },
  {
    id: 'power',
    title: 'Бесконечные возможности!',
    text: 'Ненравица дизайд меняй или создай свой используя CSS : ), Мало функций Плагины исправят это! Все можете найти на сайте : 3',
    art: 'radial-gradient(100% 80% at 10% 80%, #3ee0a2 0%, transparent 45%), linear-gradient(200deg, #123028, #07080c)'
  },
  {
    id: 'fix',
    title: 'Ой что то пошло нетак?',
    text: 'Не переживай починим и скажем в чем проблема в вкладке "Починка" и в один клик все исправим!',
    art: 'radial-gradient(110% 80% at 80% 80%, #ff6b7a 0%, transparent 48%), linear-gradient(200deg, #2a1018, #07080c)'
  }
];

export async function mountHome(root) {
  const selected = store.instances.find((i) => i.id === store.selectedId) || store.instances[0];
  const s = store.settings || {};
  const ui = s.ui || {};

  const wrap = el('div', { class: 'hero' });
  const left = el('div', { class: 'hero-card' });
  wrap.appendChild(left);
  left.appendChild(el('p', { class: 'kicker', text: t('home.kicker', '.') }));
  const greeting = ui.homeGreeting !== false && ui.greetingEnabled !== false && store.user && store.user.nick ? '…' : null;
  const greetEl = greeting ? el('p', { class: 'home-greet', text: greeting }) : null;
  if (greetEl) {
    left.appendChild(greetEl);
    // Greetings come from data/greetings.json (per-nick buckets, time-of-day
    // fallback). Loaded async so the home screen paints immediately.
    api.greeting.pick(store.user.nick).then((r) => {
      if (r && r.ok && r.text) greetEl.textContent = r.text;
      else greetEl.textContent = t('home.hello', 'Привет, ') + store.user.nick + '!';
    }).catch(() => { greetEl.textContent = t('home.hello', 'Привет, ') + store.user.nick + '!'; });
  }
  left.appendChild(el('h2', { class: 'home-title', text: selected ? selected.name : 'Cryndel' }));
  if (!selected) {
    left.appendChild(el('p', { class: 'home-sub', text: t('home.empty', 'Создай сборку — дальше одна кнопка.') }));
  }

  const meta = el('div', { class: 'home-meta' });
  const pulse = el('span', { class: 'server-pulse' });
  pulse.appendChild(el('i', { class: 'status-dot' }));
  pulse.appendChild(document.createTextNode(' cryndel.ru…'));
  meta.appendChild(pulse);
  left.appendChild(meta);

  // Server status is read once per visit to the home screen — never on a timer.
  loadServerStatus(pulse);

  const stats = el('div', { class: 'stat-grid' });
  if (ui.statCards !== false) {
    const playMin = store.user && store.user.stats ? store.user.stats.playtime || 0 : 0;
    const launches = store.user && store.user.stats ? store.user.stats.launches || 0 : 0;
    stats.appendChild(statBox(fmtMin(playMin), 'В игре', 'playtime'));
    left.appendChild(stats);
  }

  const pluginActions = ui.homeActions === false
    ? []
    : (store.pluginUi && store.pluginUi.pages || []).filter((page) => page.homeButton);
  if (pluginActions.length) {
    const actions = el('div', { class: 'row', style: 'margin-top:14px;flex-wrap:wrap' });
    for (const page of pluginActions) {
      actions.appendChild(el('button', {
        class: 'btn btn-sky',
        type: 'button',
        text: page.title || 'Открыть плагин',
        onclick: () => go(`#/plugin/${encodeURIComponent(page.pluginId)}/${encodeURIComponent(page.id)}`)
      }));
    }
    left.appendChild(actions);
  }


  const right = el('div', { class: 'home-side' });
  if (ui.showSkin3d && store.user && store.user.skin && store.user.skin.path) {
    const card = el('div', { class: 'skin-stage' });
    const canvas = document.createElement('canvas');
    canvas.className = 'skin-3d';
    canvas.width = 240;
    canvas.height = 380;
    card.appendChild(canvas);
    card.appendChild(el('p', { class: 'hint', style: 'margin-top:8px', text: store.user.nick }));
    right.appendChild(card);
    api.skins.preview(store.user.skin.path).then((u) => {
      if (!u) return;
      drawSkin3d(canvas, u, { spin: ui.skinSpin !== false });
    }).catch(() => {});
  } else if (ui.hideCarousel !== true) {
    right.appendChild(makeCarousel());
  }
  wrap.appendChild(right);

  // Music card lives on the home screen only, so the rest of the launcher stays
  // clean. It is skipped entirely when the playlist is empty.
  if (ui.showMusicCard !== false) {
    const card = await makeMusicCard();
    if (card) left.appendChild(card);
  }
  root.appendChild(wrap);
}

// Small "now playing" card: play/pause, previous/next, a volume slider and the
// track name. Re-renders itself whenever the track changes.
async function makeMusicCard() {
  if (!musicTracks().length) {
    try { await initSounds(); } catch (_) { /* */ }
  }
  if (!musicTracks().length) return null;
  const s = (store.settings && store.settings.ui) || {};
  const card = el('div', { class: 'music-card' });
  const kicker = el('p', { class: 'kicker', text: t('music.kicker', 'МУЗЫКА') });
  card.appendChild(kicker);
  const title = el('div', { class: 'music-title' });
  const row = el('div', { class: 'row music-row' });
  const prev = el('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Предыдущий трек' });
  prev.innerHTML = svg('prev');
  const play = el('button', { class: 'icon-btn music-play', type: 'button', 'aria-label': 'Играть' });
  const next = el('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Следующий трек' });
  next.innerHTML = svg('next');
  const openBtn = el('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Открыть папку музыки' });
  openBtn.innerHTML = svg('folder');
  const vol = el('input', {
    class: 'music-vol', type: 'range', min: '0', max: '100',
    value: String(Math.round((typeof s.musicVolume === 'number' ? s.musicVolume : 0.5) * 100))
  });
  row.appendChild(prev);
  row.appendChild(play);
  row.appendChild(next);
  row.appendChild(openBtn);
  row.appendChild(vol);
  card.appendChild(title);
  card.appendChild(row);

  function paint() {
    const tr = currentTrack();
    title.textContent = tr ? tr.name : t('music.empty', 'Нет треков в muzick/fon');
    play.innerHTML = svg(isPlaying() ? 'pause' : 'play');
    play.setAttribute('aria-label', isPlaying() ? 'Пауза' : 'Играть');
  }

  prev.addEventListener('click', () => { prevTrack(); paint(); });
  next.addEventListener('click', () => { nextTrack(); paint(); });
  play.addEventListener('click', () => { toggleMusic(); paint(); });
  openBtn.addEventListener('click', () => {
    if (api.system && api.system.openPath) api.system.openPath('muzick/fon');
  });
  vol.addEventListener('input', async () => {
    const v = Number(vol.value) / 100;
    await api.settings.set('ui.musicVolume', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.musicVolume = v;
    playMusic({});
  });

  onMusicChange(paint);
  paint();
  return card;
}

async function applyBackgroundNow() {
  if (window.__cryndelApplyUi) {
    await window.__cryndelApplyUi();
    return;
  }
  window.location.reload();
}

// Kept as a plain action on the home row: the floating corner button that used
// to live here looked like clutter and got in the way of the hero text.
function openWallpaperPicker() {
  const m = modal({ kicker: 'ОБОИ', title: 'Новый фон' });
  m.body.appendChild(el('p', { class: 'hint', text: 'Фон применяется сразу и сохраняется между запусками.' }));
  const row = el('div', { class: 'row', style: 'margin-top:12px' });
  row.appendChild(el('button', { class: 'btn btn-sky', text: 'Выбрать файл', onclick: async () => {
    const r = await api.theme.pickBackground();
    if (r && r.ok) {
      await applyBackgroundNow();
      toast('Обои применены');
      m.close();
    }
  } }));
  row.appendChild(el('button', { class: 'btn', text: 'Сбросить', onclick: async () => {
    await api.settings.set('ui.backgroundFile', '');
    await api.settings.set('ui.backgroundKind', 'video');
    await applyBackgroundNow();
    toast('Фон сброшен');
    m.close();
  } }));
  m.body.appendChild(row);
}

// One-shot status read: online players, ping, and the maintenance flag that
// comes from the MOTD. Called on every entry to the home screen, never on a
// background timer, so it never hammers the server.
export async function loadServerStatus(pulse) {
  try {
    const p = await api.server.query('cryndel.ru', 25565);
    pulse.replaceChildren();
    if (p && p.maintenance) {
      pulse.classList.add('maintenance');
      pulse.appendChild(el('i', { class: 'status-dot warn' }));
      pulse.appendChild(document.createTextNode(' cryndel.ru — ' + t('home.maintenance', 'Технические работы')));
      return;
    }
    if (p && p.online) {
      pulse.classList.add('on');
      pulse.appendChild(el('i', { class: 'status-dot on' }));
      const bits = ['cryndel.ru'];
      if (p.players) bits.push(t('home.players', 'Игроков') + ': ' + p.players.online + '/' + p.players.max);
      if (p.ms != null) bits.push(t('home.ping', 'Пинг') + ': ' + p.ms + ' мс');
      pulse.appendChild(document.createTextNode(' ' + bits.join(' · ')));
      return;
    }
    pulse.appendChild(el('i', { class: 'status-dot' }));
    pulse.appendChild(document.createTextNode(' ' + t('home.offline', 'Сервер молчит')));
  } catch (_) {
    pulse.replaceChildren();
    pulse.appendChild(el('i', { class: 'status-dot' }));
    pulse.appendChild(document.createTextNode(' ' + t('home.pingfail', 'Пинг недоступен')));
  }
}

function statBox(value, label, variant) {
  const n = el('div', { class: 'stat' + (variant ? ' stat-' + variant : '') });
  n.appendChild(el('b', { text: String(value) }));
  n.appendChild(el('span', { text: label }));
  return n;
}

function fmtMin(m) {
  const n = Number(m) || 0;
  if (n < 60) return n + ' м';
  return Math.floor(n / 60) + ' ч';
}

function makeCarousel() {
  const box = el('div', { class: 'home-carousel' });
  let i = 0;
  const slides = SLIDES.map((s) => {
    const n = el('div', { class: 'home-slide' });
    const art = el('div', { class: 'slide-art' });
    art.style.background = s.art;
    n.appendChild(art);
    const copy = el('div', { class: 'slide-copy' });
    copy.appendChild(el('h3', { text: s.title }));
    copy.appendChild(el('p', { class: 'hint', text: s.text }));
    n.appendChild(copy);
    box.appendChild(n);
    return n;
  });
  const nav = el('div', { class: 'caro-nav' });
  const dots = SLIDES.map((_, idx) => {
    const d = el('button', { class: 'caro-dot', type: 'button', onclick: () => show(idx) });
    nav.appendChild(d);
    return d;
  });
  let tmr = 0;
  function stop() {
    if (tmr) { clearInterval(tmr); tmr = 0; }
  }
  // Build the close button by hand instead of through iconBtn: the slides are
  // absolutely positioned and used to sit on top of it, so a click landed on the
  // slide and the carousel never closed. Explicit z-index plus stopped
  // propagation on click/pointerdown/mousedown makes the button reliable.
  const close = el('button', { class: 'icon-btn caro-close', type: 'button', 'aria-label': 'Закрыть' });
  close.innerHTML = svg('x');
  const dismiss = (ev) => {
    if (ev) {
      ev.stopPropagation();
      if (ev.preventDefault) ev.preventDefault();
    }
    stop();
    if (box.parentNode) box.remove();
    if (api.settings && api.settings.set) api.settings.set('ui.hideCarousel', true).catch(() => {});
  };
  close.addEventListener('click', dismiss);
  close.addEventListener('pointerdown', (ev) => ev.stopPropagation());
  close.addEventListener('mousedown', (ev) => ev.stopPropagation());
  nav.appendChild(close);
  box.appendChild(nav);

  function show(n) {
    i = (n + slides.length) % slides.length;
    slides.forEach((sl, k) => sl.classList.toggle('on', k === i));
    dots.forEach((d, k) => d.classList.toggle('on', k === i));
  }
  show(0);
  const secs = Math.max(3, Number((store.settings && store.settings.ui && store.settings.ui.carouselSeconds) || 10));
  tmr = setInterval(() => show(i + 1), secs * 1000);
  // Stop the timer the moment the node leaves the DOM, so it cannot keep
  // ticking (or fight a re-render) after the user closes it.
  const obs = new MutationObserver(() => {
    if (!document.body.contains(box)) { stop(); obs.disconnect(); }
  });
  obs.observe(document.body, { childList: true, subtree: true });
  return box;
}

function labelLoader(v) {
  const m = { vanilla: 'Vanilla', fabric: 'Fabric', forge: 'Forge', neoforge: 'NeoForge', quilt: 'Quilt' };
  return m[(v || '').toLowerCase()] || v || 'Vanilla';
}
