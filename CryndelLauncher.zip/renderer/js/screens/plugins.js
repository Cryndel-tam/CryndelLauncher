import { api } from '../api.js';
import { store, toast } from '../state.js';
import { el } from '../utils.js';
import { chk, field, customSelect, iconBtn } from '../ui.js';

export async function mountPlugins(root) {
  const wrap = el('div', { class: 'plugins-pane' });
  const head = el('div', { class: 'page-head' });
  const titles = el('div');
  titles.appendChild(el('p', { class: 'kicker', text: 'ПЛАГИНЫ' }));
  titles.appendChild(el('h2', { class: 'h2', text: 'Расширения лаунчера' }));
  head.appendChild(titles);
  const tools = el('div', { class: 'row' });
  tools.appendChild(el('button', { class: 'btn btn-sky', text: 'Установить .zip', onclick: async () => {
    const r = await api.plugins.install();
    if (r && r.ok) { toast('Плагин установлен'); await paint(); }
    else if (r && !r.cancelled) toast(r.error || 'Не удалось', 'bad');
  } }));
  tools.appendChild(el('button', { class: 'btn', text: 'Примеры плагинов', onclick: async () => {
    try {
      const r = await api.plugins.installExample();
      if (r && r.ok) { toast('Плагин установлен'); await paint(); }
      else if (r && !r.cancelled) toast(r.error || 'Не удалось установить пример', 'bad');
    } catch (err) {
      toast(err.message || 'Не удалось установить пример', 'bad');
    }
  } }));
  tools.appendChild(el('button', { class: 'btn', text: 'Обновить API .PLcryn', onclick: async () => {
    try {
      const r = await api.plugins.apiPackInstall();
      if (r && r.ok) {
        toast('API обновлено: ' + r.version);
        await paint();
      } else if (r && !r.cancelled) toast(r.error || 'Не удалось установить API', 'bad');
    } catch (err) {
      toast('Не удалось обновить API: ' + err.message, 'bad');
    }
  } }));
  tools.appendChild(el('button', { class: 'btn', text: 'Папка', onclick: () => api.plugins.openDir() }));
  tools.appendChild(el('button', { class: 'btn', text: 'Перезагрузить', onclick: async () => {
    await api.plugins.reload();
    toast('Плагины перезагружены');
    await paint();
  } }));
  head.appendChild(tools);
  wrap.appendChild(head);

  const s = store.settings || {};
  wrap.appendChild(chk('Включить плагины', !s.ui || s.ui.pluginsEnabled !== false, async (v) => {
    await api.settings.set('ui.pluginsEnabled', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.pluginsEnabled = v;
    toast(v ? 'Плагины включены' : 'Плагины выключены');
  }));
  wrap.appendChild(el('p', {
    class: 'hint',
    text: 'Скачивовайте плагины и обновление API Из официальных и доверенных источников! Мы ненесем ответсвенности за проблемы из за Неоф.. плагинов!'
  }));
  const apiPack = await api.plugins.apiPackStatus();
  const apiPackBox = el('section', { class: 'plugin-api-pack card' });
  apiPackBox.appendChild(el('strong', { text: 'API плагинов: ' + apiPack.version }));
  if (apiPack.error) apiPackBox.appendChild(el('p', { class: 'hint', style: 'color:var(--bad)', text: 'Пакет API повреждён: ' + apiPack.error }));
  apiPackBox.appendChild(el('p', {
    class: 'hint',
    text: 'Обновление .PLcryn Скачивовайте доверенных источноков таких как my.cryndel.ru/Cplugins, И берите себя! Если истрестно как это работает глянте в гит хаб : )'
  }));
  const apiPackActions = el('div', { class: 'row' });
  if (apiPack.previousVersion) {
    apiPackActions.appendChild(el('button', { class: 'btn btn-sm', text: 'Откатить на ' + apiPack.previousVersion, onclick: async () => {
      const result = await api.plugins.apiPackRollback();
      if (result && result.ok) { toast('Предыдущий API восстановлен'); await paint(); }
      else toast((result && result.error) || 'Откат не выполнен', 'bad');
    } }));
  }
  apiPackActions.appendChild(el('button', { class: 'btn btn-sm', text: apiPack.resetUsed ? 'Сбросить до встроенного API' : 'Сбросить API', onclick: async () => {
    const result = await api.plugins.apiPackReset();
    if (result && result.ok) { toast(result.restoredPrevious ? 'Восстановлен предыдущий API; повторный сброс вернёт встроенный API' : 'Используется встроенный API'); await paint(); }
    else toast((result && result.error) || 'Сброс не выполнен', 'bad');
  } }));
  apiPackBox.appendChild(apiPackActions);
  wrap.appendChild(apiPackBox);

  const warn = el('p', { class: 'hint plugin-warn', text: '' });
  const list = el('div', { class: 'plugin-list' });
  wrap.appendChild(warn);
  wrap.appendChild(list);

  async function paint() {
    list.replaceChildren();
    const items = await api.plugins.list().catch(() => []);
    const schemas = await api.plugins.schema().catch(() => ({}));
    if (!items.length) {
      const empty = el('div', { class: 'empty' });
      empty.appendChild(el('h3', { text: 'Плагинов нет' }));
      empty.appendChild(el('p', { text: ' Хи хи хи все можно создать с плагинами новые функции приколы антивирус))) и тд.. ' }));
      list.appendChild(empty);
    }
    for (const p of items) {
      const card = el('div', { class: 'plugin-card' });
      const headRow = el('div', { class: 'plugin-head' });
      const title = el('div');
      title.appendChild(el('strong', { text: p.name || p.id }));
      title.appendChild(el('p', { class: 'hint', text: [p.version && 'v' + p.version, p.author, p.api && 'API ' + p.api].filter(Boolean).join(' · ') }));
      if (p.permissions && p.permissions.length) {
        title.appendChild(el('p', {
          class: 'hint',
          text: `Разрешения: ${(p.grantedPermissions || []).join(', ') || 'не выданы'}`
        }));
      }
      headRow.appendChild(title);
      headRow.appendChild(el('span', {
        class: 'badge ' + (p.error ? 'bad' : p.active ? 'ok' : ''),
        text: p.error ? 'ошибка' : p.active ? 'активен' : (p.disabled ? 'выключен' : 'не загружен')
      }));
      card.appendChild(headRow);
      if (p.description) card.appendChild(el('p', { class: 'hint', text: p.description }));
      if (p.error) card.appendChild(el('p', { class: 'hint', style: 'color:var(--bad)', text: p.error }));

      const row = el('div', { class: 'row' });
      row.appendChild(el('button', {
        class: 'btn btn-sm' + (p.active ? '' : ' btn-sky'),
        text: p.active ? 'Выключить' : 'Включить',
        onclick: async () => {
          const r = await api.plugins.toggle(p.id, !p.active);
          if (r && r.ok === false && r.error) toast(r.error, 'bad');
          await paint();
        }
      }));
      row.appendChild(iconBtn('folder', 'Папка плагина', () => api.plugins.openDir()));
      row.appendChild(el('button', { class: 'btn btn-sm', text: 'Разрешения', onclick: async () => {
        const result = await api.plugins.managePermissions(p.id);
        if (result && result.ok) {
          toast('Разрешения плагина обновлены');
          await paint();
        } else if (result && !result.cancelled) toast(result.error || 'Не удалось изменить разрешения', 'bad');
      } }));
      row.appendChild(iconBtn('trash', 'Удалить плагин', async () => {
        await api.plugins.remove(p.id);
        toast('Плагин удалён');
        await paint();
      }, 'btn-danger'));
      card.appendChild(row);

      const fields = (schemas && (schemas[p.id] || schemas)) || [];
      const schema = Array.isArray(fields) ? fields : (Array.isArray(p.settings) ? p.settings : []);
      const conf = await api.plugins.configGet(p.id).catch(() => ({}));
      const settingsToggle = el('button', {
        class: 'btn btn-sm',
        type: 'button',
        text: 'Настройки плагина'
      });
      const settingsPanel = el('div', { class: 'plugin-settings', style: 'display:none' });
      settingsToggle.addEventListener('click', () => {
        const visible = settingsPanel.style.display !== 'none';
        settingsPanel.style.display = visible ? 'none' : '';
        settingsToggle.textContent = visible ? 'Настройки плагина' : 'Скрыть настройки';
      });
      card.appendChild(settingsToggle);
      if (schema.length) {
        settingsPanel.appendChild(el('p', { class: 'kicker', text: 'НАСТРОЙКИ ПЛАГИНА' }));
        for (const f of schema) {
          settingsPanel.appendChild(await drawField(p.id, f, conf));
        }
      } else {
        const extra = el('details', { class: 'plugin-raw' });
        extra.appendChild(el('summary', { text: 'Свой JSON-конфиг' }));
        const area = el('textarea', { class: 'field css-editor', spellcheck: 'false' });
        area.value = JSON.stringify(conf || {}, null, 2);
        extra.appendChild(area);
        extra.appendChild(el('button', { class: 'btn btn-sm', style: 'margin-top:8px', text: 'Сохранить', onclick: async () => {
          try {
            const parsed = JSON.parse(area.value || '{}');
            await api.plugins.configSet(p.id, '', parsed);
            toast('Конфиг сохранён');
          } catch (e) { toast('JSON сломан: ' + e.message, 'bad'); }
        } }));
        settingsPanel.appendChild(extra);
      }
      card.appendChild(settingsPanel);
      list.appendChild(card);
    }
    const warns = await api.plugins.warnings().catch(() => []);
    warn.textContent = warns.length ? 'Предупреждения: ' + warns.map((w) => (w.id || '') + (w.message ? ' — ' + w.message : '')).join('; ') : '';
  }

  await paint();
  root.replaceChildren(wrap);
}

async function drawField(pluginId, f, conf) {
  const key = f.key || f.id || f.name;
  const label = f.label || f.title || key;
  const type = f.type || 'text';
  let value = conf;
  if (key) {
    for (const part of String(key).split('.')) {
      value = value && value[part];
    }
  }
  if (value === undefined) value = f.default;
  const save = async (v) => {
    await api.plugins.configSet(pluginId, key, v);
    toast('Сохранено');
  };
  if (type === 'bool' || type === 'toggle' || type === 'checkbox') {
    return chk(label, Boolean(value), (v) => save(v));
  }
  if (type === 'select' && Array.isArray(f.options)) {
    const opts = f.options.map((o) => (typeof o === 'string' ? { value: o, label: o } : { value: o.value, label: o.label || o.value }));
    return field(label, customSelect(opts, value, (v) => save(v)));
  }
  if (type === 'number' || type === 'range') {
    const input = el('input', {
      class: 'field', type: type === 'range' ? 'range' : 'number',
      min: String(f.min != null ? f.min : 0),
      max: String(f.max != null ? f.max : 100),
      value: String(value != null ? value : 0)
    });
    input.addEventListener('change', () => save(Number(input.value)));
    return field(label, input);
  }
  const input = el('input', { class: 'field', value: value == null ? '' : String(value), placeholder: f.placeholder || '' });
  input.addEventListener('change', () => save(input.value));
  return field(label, input);
}
