import { api } from '../api.js';
import { el } from '../utils.js';
import { createPluginFrame, connectPluginFrame, openPluginModal } from '../plugin-ui.js';

export async function mountPluginPage(root, params = {}) {
  const contributions = await api.plugins.ui();
  const page = contributions.pages.find((item) => item.pluginId === params.pluginId && item.id === params.pageId);
  if (!page) {
    root.appendChild(el('div', { class: 'empty', text: 'Страница плагина не найдена. Возможно, расширение выключено.' }));
    return;
  }
  root.classList.add('plugin-page-stage');
  const frame = createPluginFrame(page);
  root.appendChild(frame);
  root._off = connectPluginFrame(frame, page.pluginId, (options) => openPluginModal(page.pluginId, options));
}
