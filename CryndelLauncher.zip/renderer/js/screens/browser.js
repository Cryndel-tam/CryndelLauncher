import { el } from '../utils.js';
import { store, bus, toast } from '../state.js';
import { api } from '../api.js';
import { iconBtn, modal, field, tip } from '../ui.js';
import { svg } from '../icons.js';

export async function mountBrowser(root) {
  const stage = document.getElementById('stage');
  if (stage) stage.classList.add('padless');
  const s = store.settings || {};
  const br = s.browser || {};
  const zoom = Number(br.zoom || 100) / 100;

  const wrap = el('div', { class: 'browser-shell' });
  const bar = el('div', { class: 'browser-bar' });
  const tabs = el('div', { class: 'browser-tabs' });
  bar.appendChild(tabs);
  bar.appendChild(iconBtn('plus', 'Новая вкладка Google', () => addTab('https://www.google.com', 'Google')));
  bar.appendChild(iconBtn('gear', 'Настройки браузера', () => openSettings()));
  wrap.appendChild(bar);

  const frames = el('div', { class: 'browser-frames' });
  wrap.appendChild(frames);
  root.appendChild(wrap);

  const state = { tabs: [], active: 0 };

  function paintTabs() {
    tabs.replaceChildren();
    state.tabs.forEach((t, i) => {
      const b = el('button', {
        class: 'browser-tab' + (i === state.active ? ' on' : ''),
        onclick: () => {
          if (t.stale) reload(t);
          state.active = i;
          show();
        }
      });
      const lab = el('span', { text: '·' });
      b.appendChild(lab);
      tip(b, t.title || t.url);
      const x = el('span', { class: 'browser-x' });
      x.innerHTML = svg('x');
      x.addEventListener('click', (ev) => { ev.stopPropagation(); closeTab(i); });
      b.appendChild(x);
      tabs.appendChild(b);
    });
  }

  function show() {
    paintTabs();
    [...frames.children].forEach((n, i) => { n.style.display = i === state.active ? 'flex' : 'none'; });
  }

  function makeFrame(url) {
    if (window.__CRYNDEL_PREVIEW) {
      const iframe = document.createElement('iframe');
      iframe.src = url;
      iframe.className = 'webframe';
      iframe.setAttribute('title', 'browser');
      iframe.style.transform = 'scale(' + zoom + ')';
      iframe.style.width = (100 / zoom) + '%';
      iframe.style.height = (100 / zoom) + '%';
      iframe.style.transformOrigin = '0 0';
      iframe.style.border = '0';
      return iframe;
    }
    const frame = document.createElement('webview');
    // `partition` is only honoured before the first navigation, so it must be
    // set before `src`. With the old order the webview silently fell back to the
    // default session, so logins and cookies were lost between launches.
    frame.setAttribute('partition', 'persist:cryndel');
    frame.setAttribute('allowpopups', '');
    frame.setAttribute('src', url);
    frame.className = 'webframe';
    frame.style.transform = 'scale(' + zoom + ')';
    frame.style.width = (100 / zoom) + '%';
    frame.style.height = (100 / zoom) + '%';
    return frame;
  }

  function addTab(url, title) {
    const frame = makeFrame(url);
    const item = { url, title: title || 'Вкладка', frame, last: Date.now(), stale: false };
    frame.addEventListener('page-title-updated', (e) => {
      item.title = e.title || title;
      paintTabs();
    });
    frame.addEventListener('did-navigate', (e) => {
      item.url = e.url || url;
      item.last = Date.now();
    });
    frames.appendChild(frame);
    state.tabs.push(item);
    state.active = state.tabs.length - 1;
    show();
  }

  function reload(t) {
    t.stale = false;
    t.last = Date.now();
    if (t.frame) t.frame.setAttribute('src', t.url);
  }

  function closeTab(i) {
    const t = state.tabs[i];
    if (t && t.frame) t.frame.remove();
    state.tabs.splice(i, 1);
    if (!state.tabs.length) addTab('https://www.google.com', 'Google');
    else {
      state.active = Math.max(0, Math.min(state.active, state.tabs.length - 1));
      show();
    }
  }

  tabs.addEventListener('wheel', (e) => {
    if (!state.tabs.length) return;
    e.preventDefault();
    const d = e.deltaY > 0 ? 1 : -1;
    state.active = (state.active + d + state.tabs.length) % state.tabs.length;
    show();
  }, { passive: false });

  setInterval(() => {
    const now = Date.now();
    state.tabs.forEach((t) => {
      if (now - t.last > 10 * 60 * 1000 && !t.stale) {
        t.stale = true;
        try { t.frame.setAttribute('src', 'about:blank'); } catch (_) { /* */ }
      }
    });
  }, 30000);

  function openGo() {
    const m = modal({ kicker: 'ССЫЛКА', title: 'Перейти' });
    const input = el('input', { class: 'field', placeholder: 'https://…' });
    m.body.appendChild(input);
    m.body.appendChild(el('button', { class: 'btn btn-sky', style: 'margin-top:10px', text: 'Перейти', onclick: () => {
      let u = input.value.trim();
      if (!u) return;
      if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
      addTab(u, 'Вкладка');
      m.close();
    } }));
    input.focus();
  }

  function openSettings() {
    const m = modal({ kicker: 'СЕТЬ', title: 'Настройки браузера' });
    const z = el('input', { class: 'field', type: 'number', min: '50', max: '150', value: String(br.zoom || 100) });
    m.body.appendChild(field('Масштаб страницы, %', z));
    z.addEventListener('change', async () => {
      await api.settings.set('browser.zoom', Number(z.value) || 100);
      toast('Масштаб сохранится для следующих вкладок');
    });
    m.body.appendChild(el('p', { class: 'hint', text: 'Пароли и сессии сайтов хранятся в отдельном профиле persist:cryndel и не сбрасываются.' }));
    m.body.appendChild(el('p', { class: 'hint', text: 'Файлы из сети сохраняются в загрузки лаунчера.' }));
  }

  const off = bus.on('browser-tab', (url) => {
    if (typeof url === 'string' && url) addTab(url, 'Вкладка');
    else openGo();
  });
  root._offBrowser = off;
  // A URL can be queued by the main process (target=_blank, window.open) before
  // this screen mounts. Drain it here so the in-app browser opens every time.
  if (store.pendingBrowserUrl) {
    const u = store.pendingBrowserUrl;
    store.pendingBrowserUrl = null;
    addTab(u, 'Вкладка');
  } else {
    addTab('https://www.google.com', 'Google');
  }
}
