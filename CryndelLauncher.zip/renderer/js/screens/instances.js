import { api } from '../api.js';
import { store, toast } from '../state.js';
import { el } from '../utils.js';
import { go } from '../router.js';
import { iconBtn, modal, field, chk, customSelect } from '../ui.js';

export async function mountInstances(root) {
  store.instances = await api.instances.list();
  const wrap = el('div');
  const head = el('div', { class: 'page-head' });
  const titles = el('div');
  titles.appendChild(el('p', { class: 'kicker', text: 'СБОРКИ' }));
  titles.appendChild(el('h2', { class: 'h2', text: 'Твои миры и модпаки' }));
  head.appendChild(titles);
  const tools = el('div', { class: 'row' });
  tools.appendChild(iconBtn('plus', 'Новая сборка', () => go('#/build-wizard')));
  tools.appendChild(iconBtn('folder', 'Импорт', async () => {
    let r = await api.instances.importMrpack();
    if (r && r.needsMeta && window.__cryndelAskImport) {
      const meta = await window.__cryndelAskImport(r);
      if (!meta) return;
      r = await api.inbox.importMrpackPath(r.file, meta);
    }
    if (r && r.ok) { toast('Импорт ок'); await mountInstances(root); }
  }));
  tools.appendChild(el('button', { class: 'btn', text: 'Версии Minecraft', onclick: () => openVersions() }));
  tools.appendChild(iconBtn('export', 'Опубликовать .mpcryn', () => openPublish()));
  tools.appendChild(iconBtn('install', 'Импорт .mpcryn (Publsborka)', () => openPublishImport()));
  head.appendChild(tools);
  wrap.appendChild(head);

  const catalog = await api.instances.catalog().catch(() => ({ builds: [] }));
  if (catalog && catalog.builds && catalog.builds.length && !store.instances.length) {
    wrap.appendChild(el('p', { class: 'hint', style: 'margin:-8px 0 16px', text: 'Готовые официальные паки Cryndel — одна кнопка.' }));
    const rec = el('div', { class: 'grid-cards', style: 'margin-bottom:22px' });
    for (const b of catalog.builds) {
      const c = el('div', { class: 'card inst-card' });
      c.appendChild(el('span', { class: 'badge gold', text: 'Официально' }));
      c.appendChild(el('strong', { text: b.name }));
      c.appendChild(el('p', { class: 'hint', text: b.description || (b.mcVersion + ' · ' + b.modLoader) }));
      c.appendChild(el('button', { class: 'btn btn-sky', text: 'Создать из пака', onclick: async () => {
        try {
          const inst = await api.instances.createFromBuild(b.id, b.name);
          store.selectedId = inst.id;
          if (window.__cryndelRefresh) await window.__cryndelRefresh();
          toast('Сборка «' + inst.name + '» готова');
          go('#/instance/' + inst.id);
        } catch (e) { toast(e.message || 'Не вышло', 'bad'); }
      } }));
      rec.appendChild(c);
    }
    wrap.appendChild(rec);
  }

  const grid = el('div', { class: 'grid-cards' });
  const groups = {};
  for (const i of store.instances) {
    const g = i.group || 'Default';
    if (!groups[g]) groups[g] = [];
    groups[g].push(i);
  }
  for (const [g, items] of Object.entries(groups)) {
    grid.appendChild(el('div', { class: 'kicker', text: g, style: 'grid-column:1/-1;margin-top:8px' }));
    for (const inst of items) {
      const c = el('div', { class: 'card inst-card' + (inst.id === store.selectedId ? ' selected' : '') });
      const top = el('div', { class: 'top' });
      top.appendChild(el('strong', { text: inst.name }));
      if (inst.id === store.selectedId) top.appendChild(el('span', { class: 'badge ok', text: 'Выбрана' }));
      c.appendChild(top);
      c.appendChild(el('div', { class: 'mr-meta', text: inst.mcVersion + ' · ' + labelLoader(inst.modLoader) + ' · ' + (inst.memoryMb || 4096) + ' МБ' }));
      if (inst.lastPlayedAt) c.appendChild(el('div', { class: 'hint', text: 'Играли: ' + String(inst.lastPlayedAt).replace('T', ' ').slice(0, 16) }));
      const row = el('div', { class: 'row', style: 'margin-top:auto' });
      row.appendChild(iconBtn('play', 'Выбрать и открыть', () => {
        store.selectedId = inst.id;
        api.instances.select(inst.id).catch(() => {});
        go('#/instance/' + inst.id);
      }));
      row.appendChild(iconBtn('edit', 'Изменить', () => editInst(inst, root)));
      row.appendChild(iconBtn('folder', 'Папка', () => api.instances.openFolder(inst.id)));
      row.appendChild(iconBtn('trash', 'Удалить', async () => {
        const m = modal({ kicker: 'СБОРКА', title: 'Удалить «' + inst.name + '»?' });
        m.body.appendChild(el('p', { class: 'hint', text: 'Сборка пропадёт из списка. Файлы на диске лаунчер не трогает без подтверждения в папке.' }));
        m.body.appendChild(el('button', { class: 'btn btn-danger', style: 'margin-top:12px', text: 'Удалить', onclick: async () => {
          m.close();
          await api.instances.delete(inst.id);
          if (store.selectedId === inst.id) store.selectedId = null;
          if (window.__cryndelRefresh) await window.__cryndelRefresh();
          await mountInstances(root);
        } }));
      }, 'btn-danger'));
      c.appendChild(row);
      c.addEventListener('dblclick', async () => {
        store.selectedId = inst.id;
        await api.instances.select(inst.id).catch(() => {});
        go('#/instance/' + inst.id);
      });
      grid.appendChild(c);
    }
  }
  if (!store.instances.length) {
    const empty = el('div', { class: 'empty' });
    empty.appendChild(el('h3', { text: 'Пока пусто' }));
    empty.appendChild(el('p', { text: 'Собери Fabric под Cryndel или импортируй .mrpack.' }));
    empty.appendChild(el('button', { class: 'btn btn-sky', text: 'Создать сборку', onclick: () => go('#/build-wizard') }));
    grid.appendChild(empty);
  }
  wrap.appendChild(grid);
  root.replaceChildren(wrap);
}

function labelLoader(v) {
  const m = { vanilla: 'Vanilla', fabric: 'Fabric', forge: 'Forge', neoforge: 'NeoForge', quilt: 'Quilt' };
  return m[(v || '').toLowerCase()] || v || 'Vanilla';
}

// Publsborka: export the selected instance to a .mpcryn container. The file
// lands in the launcher Downloads folder by default.
async function openPublish() {
  const inst = store.instances.find((i) => i.id === store.selectedId) || store.instances[0];
  if (!inst) { toast('Сначала создай сборку', 'bad'); return; }
  const m = modal({ kicker: 'PUBLSBORKA', title: 'Опубликовать «' + inst.name + '»' });
  m.body.appendChild(el('p', { class: 'hint', text: 'Сборка упакуется в один файл .mpcryn: моды, конфиги, миры, настройки. Его можно передать другому игроку и импортировать обратно.' }));
  const row = el('div', { class: 'row', style: 'margin-top:12px' });
  row.appendChild(el('button', { class: 'btn btn-sky', text: 'Опубликовать', onclick: async () => {
    const r = await api.publish.build(inst.id);
    if (r && r.ok) { toast('Готово: ' + r.path); m.close(); }
    else if (r && !r.cancelled) toast(r.error || 'Не удалось', 'bad');
  } }));
  row.appendChild(el('button', { class: 'btn btn-ghost', text: 'Отмена', onclick: () => m.close() }));
  m.body.appendChild(row);
}

// Publsborka import: pick a .mpcryn, show its manifest, then create the pack.
async function openPublishImport() {
  const picked = await api.publish.pick();
  if (!picked || !picked.ok) {
    if (picked && !picked.cancelled) toast(picked.error || 'Не удалось прочитать файл', 'bad');
    return;
  }
  const man = picked.manifest || {};
  const m = modal({ kicker: 'IMPORT', title: 'Импорт сборки' });
  m.body.appendChild(el('p', { class: 'hint', text: [man.name, man.mcVersion, labelLoader(man.modLoader)].filter(Boolean).join(' · ') }));
  const name = el('input', { class: 'field', value: man.name || 'Импорт', placeholder: 'Название сборки' });
  m.body.appendChild(field('Название', name));
  m.body.appendChild(el('button', { class: 'btn btn-sky', style: 'margin-top:12px;width:100%', text: 'Импортировать', onclick: async () => {
    m.close();
    const r = await api.publish.import(picked.path, name.value.trim());
    if (r && r.ok) {
      store.selectedId = r.instance.id;
      if (window.__cryndelRefresh) await window.__cryndelRefresh();
      toast('Импортировано: ' + r.instance.name);
      go('#/instance/' + r.instance.id);
    } else {
      toast((r && r.error) || 'Не удалось импортировать', 'bad');
    }
  } }));
}

function editInst(inst, root) {
  const m = modal({ kicker: 'СБОРКА', title: 'Изменить' });
  const name = el('input', { class: 'field', value: inst.name });
  const ver = el('input', { class: 'field', value: inst.mcVersion });
  const loader = el('select', { class: 'field' });
  for (const [id, t] of [['vanilla', 'Vanilla'], ['fabric', 'Fabric'], ['forge', 'Forge'], ['neoforge', 'NeoForge'], ['quilt', 'Quilt']]) {
    loader.appendChild(el('option', { value: id, text: t }));
  }
  loader.value = inst.modLoader || 'fabric';
  const mem = el('input', { class: 'field', type: 'number', min: '2048', step: '256', value: String(inst.memoryMb || 4096) });
  m.body.appendChild(field('Название', name));
  m.body.appendChild(field('Версия', ver));
  m.body.appendChild(field('Загрузчик', loader));
  m.body.appendChild(field('RAM, МБ', mem));
  m.body.appendChild(el('button', { class: 'btn btn-sky', text: 'Сохранить', onclick: async () => {
    await api.instances.update(inst.id, {
      name: name.value.trim(),
      mcVersion: ver.value.trim(),
      modLoader: loader.value,
      memoryMb: Number(mem.value) || inst.memoryMb
    });
    toast('Сохранено');
    m.close();
    if (window.__cryndelRefresh) await window.__cryndelRefresh();
    if (/^\/instance\//.test(store.route || '')) await mountInstance(root, { id: inst.id });
    else await mountInstances(root);
  } }));
}

async function openVersions() {
  const m = modal({ kicker: 'MINECRAFT', title: 'Версии', class: 'ver-modal' });
  let manifest = { versions: [] };
  try { manifest = await api.versions.manifest(); } catch (e) {
    m.body.appendChild(el('p', { text: e.message }));
    return;
  }
  // One tidy filter row: search, release type and loader, all the same height.
  const filters = el('div', { class: 'ver-filters' });
  const search = el('input', { class: 'field', placeholder: 'Поиск версии, напр. 1.21' });
  const kind = customSelect([
    { value: 'release', label: 'Release' },
    { value: 'snapshot', label: 'Snapshot' },
    { value: 'old_beta', label: 'Beta' },
    { value: 'old_alpha', label: 'Alpha' }
  ], 'release', () => render());
  const loader = customSelect([
    { value: 'vanilla', label: 'Vanilla' },
    { value: 'fabric', label: 'Fabric' },
    { value: 'neoforge', label: 'NeoForge' },
    { value: 'forge', label: 'Forge' },
    { value: 'quilt', label: 'Quilt' }
  ], 'fabric', () => render());
  filters.appendChild(search);
  filters.appendChild(kind);
  filters.appendChild(loader);
  m.body.appendChild(filters);
  const count = el('p', { class: 'hint', style: 'margin:4px 0 10px' });
  m.body.appendChild(count);
  const list = el('div', { class: 'ver-list' });
  m.body.appendChild(list);

  function render() {
    list.replaceChildren();
    const q = search.value.trim().toLowerCase();
    const items = (manifest.versions || [])
      .filter((v) => v.type === kind.value)
      .filter((v) => !q || String(v.id).toLowerCase().includes(q))
      .slice(0, 60);
    count.textContent = items.length ? `Найдено: ${items.length}` : 'Ничего не найдено';
    for (const v of items) {
      const c = el('div', { class: 'ver-card' });
      const info = el('div', { class: 'ver-info' });
      info.appendChild(el('strong', { text: v.id }));
      info.appendChild(el('span', { class: 'hint', text: v.type + ' · ' + String(v.releaseTime || '').slice(0, 10) }));
      c.appendChild(info);
      c.appendChild(el('button', { class: 'btn btn-sky ver-create', text: 'Создать', onclick: async () => {
        const loaderLabel = (loader.querySelector('.cselect-btn span') || {}).textContent || 'Fabric';
        const inst = await api.instances.create({
          name: loaderLabel + ' ' + v.id,
          mcVersion: v.id,
          modLoader: loader.value,
          group: 'Custom'
        });
        store.selectedId = inst.id;
        toast('Сборка ' + inst.name + ' создана');
        m.close();
        if (window.__cryndelRefresh) await window.__cryndelRefresh();
        go('#/instances');
      } }));
      list.appendChild(c);
    }
  }
  search.addEventListener('input', render);
  render();
}

export async function mountInstance(root, params) {
  const inst = await api.instances.get(params.id);
  if (!inst) {
    root.appendChild(el('div', { class: 'empty' }));
    root.firstChild.appendChild(el('h3', { text: 'Сборка не найдена' }));
    root.firstChild.appendChild(el('button', { class: 'btn', text: 'К списку', onclick: () => go('#/instances') }));
    return;
  }
  store.selectedId = inst.id;
  try { await api.instances.select(inst.id); } catch (_) { /* */ }
  const wrap = el('div');
  wrap.appendChild(el('p', { class: 'kicker', text: inst.group || 'INSTANCE' }));
  const title = el('div', { class: 'row' });
  title.appendChild(el('h2', { class: 'h2', text: inst.name }));
  title.appendChild(iconBtn('play', 'Играть', async () => {
    try { await api.game.launch(inst.id); toast('Запускаю…'); }
    catch (e) { toast(e.message, 'bad'); }
  }));
  title.appendChild(iconBtn('edit', 'Изменить', () => editInst(inst, root)));
  wrap.appendChild(title);
  wrap.appendChild(el('p', { class: 'hint', style: 'margin:-8px 0 14px', text: inst.mcVersion + ' · ' + labelLoader(inst.modLoader) + ' · ' + (inst.memoryMb || 4096) + ' МБ' }));

  const tabs = el('div', { class: 'tabs' });
  tabs.appendChild(el('button', { class: 'on', text: 'Обзор' }));
  tabs.appendChild(el('button', { text: 'Моды', onclick: () => go('#/mods') }));
  tabs.appendChild(el('button', { text: 'Починка', onclick: () => go('#/health') }));
  wrap.appendChild(tabs);

  const qp = el('div', { class: 'card' });
  qp.appendChild(el('strong', { text: 'Quick Play' }));
  qp.appendChild(el('p', { class: 'hint', text: 'Сразу зайти на сервер при запуске.' }));
  const srv = el('input', { class: 'field', value: (inst.quickPlay && inst.quickPlay.server) || 'cryndel.ru' });
  qp.appendChild(chk('Сразу на сервер', inst.quickPlay && inst.quickPlay.enabled, async (v) => {
    await api.instances.update(inst.id, { quickPlay: { enabled: v, server: srv.value, port: 25565 } });
    toast('Quick Play обновлён');
  }));
  qp.appendChild(field('Адрес', srv));
  srv.addEventListener('change', async () => {
    await api.instances.update(inst.id, { quickPlay: { enabled: inst.quickPlay && inst.quickPlay.enabled, server: srv.value.trim(), port: 25565 } });
  });
  wrap.appendChild(qp);

  wrap.appendChild(el('h3', { text: 'Заметки', style: 'margin:16px 0 8px' }));
  const notes = el('textarea', { class: 'field', style: 'min-height:90px' });
  notes.value = await api.notes.load(inst.id).catch(() => '');
  wrap.appendChild(notes);
  wrap.appendChild(el('button', { class: 'btn', style: 'margin-top:8px', text: 'Сохранить заметку', onclick: async () => {
    await api.notes.save(inst.id, notes.value);
    toast('Заметка сохранена');
  } }));

  try {
    const lock = await api.lockfile.load(inst.id);
    if (lock && lock.entries) {
      wrap.appendChild(el('h3', { text: 'Lockfile', style: 'margin:16px 0 8px' }));
      const box = el('div', { class: 'card' });
      box.appendChild(el('strong', { text: 'lock v' + (lock.version || 1) + ' · ' + (lock.loader || '') + ' ' + (lock.mcVersion || '') }));
      const n = (lock.entries || []).length;
      box.appendChild(el('p', { class: 'hint', text: n ? n + ' записей' : 'Пока пусто — моды появятся после установки.' }));
      wrap.appendChild(box);
    }
  } catch (_) { /* */ }

  root.replaceChildren(wrap);
}
