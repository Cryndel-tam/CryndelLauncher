import { api } from '../api.js';
import { store, toast } from '../state.js';
import { el } from '../utils.js';
import { go } from '../router.js';
import { iconBtn } from '../ui.js';
import { sanitizeIconSvg } from '../icons.js';

export async function mountPluginMods(root) {
  const shell = el('div', { class: 'plugins-pane' });
  const head = el('div', { class: 'page-head' });
  const title = el('div');
  title.appendChild(el('p', { class: 'kicker', text: 'ПЛАГИНЫ · КАТАЛОГ' }));
  title.appendChild(el('h2', { class: 'h2', text: 'Моды от плагинов' }));
  head.appendChild(title);
  head.appendChild(iconBtn('mods', 'К установленным модам', () => go('#/mods')));
  shell.appendChild(head);
  shell.appendChild(el('p', {
    class: 'hint',
    text: 'Каталог показывает только моды, объявленные установленными и включёнными плагинами. Для установки выбери сборку; плагин должен иметь разрешение «Установка модов».'
  }));
  const list = el('div', { class: 'plugin-list' });
  shell.appendChild(list);
  root.replaceChildren(shell);

  const mods = await api.plugins.modsCatalog();
  if (!Array.isArray(mods) || !mods.length) {
    const empty = el('div', { class: 'empty' });
    empty.appendChild(el('h3', { text: 'Пока нет доступных плагинных модов' }));
    empty.appendChild(el('p', { text: 'Установи пример «Каталог плагинных модов» и плагин, который публикует тестовый JAR.' }));
    list.appendChild(empty);
    return;
  }
  const instance = store.instances.find((item) => item.id === store.selectedId);
  for (const item of mods) {
    const loader = String((instance && instance.modLoader) || '').toLowerCase();
    const compatible = !instance
      || ((!item.loaders || !item.loaders.length || item.loaders.includes(loader))
        && (!item.gameVersions || !item.gameVersions.length || item.gameVersions.includes('*') || item.gameVersions.includes(instance.mcVersion)));
    const card = el('section', { class: 'plugin-card' });
    const row = el('div', { class: 'plugin-head' });
    const info = el('div');
    info.appendChild(el('strong', { text: item.name || item.id }));
    info.appendChild(el('p', {
      class: 'hint',
      text: [item.version && `v${item.version}`, `от ${item.pluginId}`].filter(Boolean).join(' · ')
    }));
    row.appendChild(info);
    if (item.iconSvg) {
      try {
        const icon = sanitizeIconSvg(item.iconSvg);
        const iconHost = el('span', { class: 'plugin-mod-icon' });
        iconHost.innerHTML = `<svg viewBox="${icon.viewBox}" aria-hidden="true">${icon.body}</svg>`;
        row.appendChild(iconHost);
      } catch (_) { /* Invalid plugin icons fall back to the text-only card. */ }
    }
    card.appendChild(row);
    if (item.description) card.appendChild(el('p', { class: 'hint', text: item.description }));
    if (item.loaders && item.loaders.length) {
      card.appendChild(el('p', { class: 'hint', text: `Загрузчики: ${item.loaders.join(', ')}${item.gameVersions && item.gameVersions.length ? ` · Minecraft: ${item.gameVersions.join(', ')}` : ''}` }));
    }
    card.appendChild(el('button', {
      class: 'btn btn-sky',
      type: 'button',
      text: !store.selectedId ? 'Сначала выбери сборку' : compatible ? 'Установить в выбранную сборку' : 'Несовместимо с выбранной сборкой',
      disabled: !store.selectedId || !compatible,
      onclick: async () => {
        if (!window.confirm(`Установить «${item.name || item.id}» в выбранную сборку? Файл поступает из плагина «${item.pluginId}».`)) return;
        try {
          const result = await api.plugins.call(item.pluginId, 'install.localMod', [store.selectedId, item.id]);
          if (!result || result.ok === false) throw new Error((result && result.error) || 'Установка не выполнена');
          toast(result.warning ? `Установлено с предупреждением: ${result.warning}` : `Установлен ${result.name || item.name}`);
        } catch (err) {
          toast(err.message || 'Не удалось установить мод', 'bad');
        }
      }
    }));
    list.appendChild(card);
  }
}
