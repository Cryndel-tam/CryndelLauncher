import { toast } from '../state.js';
import { go } from '../router.js';

// The standalone "Versions" screen folded into Instances: a version is only
// meaningful together with a pack, so this route just forwards there.
export async function mountVersions() {
  go('#/instances');
  toast('Версии теперь внутри Сборок');
}
