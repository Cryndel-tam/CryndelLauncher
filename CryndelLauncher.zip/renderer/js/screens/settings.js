import { api } from '../api.js';
import { store, toast } from '../state.js';
import { el } from '../utils.js';
import { chk, field, customSelect, paintSkinFace, drawSkinFront, iconBtn } from '../ui.js';
import { sanitizeIconSvg, setIconOverrides, svg } from '../icons.js';
import { loadLocale } from '../i18n.js';
import { sound, setMusicVolume, playMusic, pauseMusic, nextTrack } from '../sound.js';

// Re-read the user's custom CSS and swap it into the live <style> node so
// changes are visible immediately, without reloading the window.
async function applyCustomCssLive() {
  const node = document.getElementById('userTheme');
  if (!node) return;
  try {
    node.textContent = (await api.theme.read()) || '';
  } catch (_) {
    node.textContent = '';
  }
}

const THEMES = [
  ['dark', 'Ночь', '#141923', '#91aaff', '#26334c'],
  ['light', 'День', '#f3f5fa', '#3b5bfd', '#dce3ff'],
  ['furry', 'Фурри', '#36241b', '#ffad68', '#70472e'],
  ['girly', 'Роза', '#45253a', '#ff8fc1', '#75405b'],
  ['professional', 'Сталь', '#27313d', '#e2bb54', '#465567'],
  ['glass', 'Лёд', '#102c3b', '#70e9dc', '#1e5360'],
  ['ember', 'Эмбер', '#3b211a', '#ff8158', '#713d2c'],
  ['forest', 'Лес', '#173226', '#53dca7', '#285541'],
  ['ocean', 'Океан', '#102b43', '#41c8db', '#17516c'],
  ['lavender', 'Лаванда', '#f1edff', '#704bd1', '#d9ceff'],
  ['mint', 'Мята', '#e9f7ed', '#247657', '#b4e3c5'],
  ['sunset', 'Закат', '#382331', '#ff9b62', '#744049'],
  ['sakura', 'Сакура', '#fff1f6', '#c94679', '#ffd1df'],
  ['sand', 'Песок', '#f5eddd', '#846238', '#dfc99f']
];

const SECTIONS = [
  ['theme', 'Тема'],
  ['icons', 'Иконки'],
  ['css', 'Свой CSS'],
  ['home', 'Главная и фон'],
  ['performance', 'Производительность'],
  ['sound', 'Звук'],
  ['music', 'Музыка'],
  ['game', 'Память и картинка'],
  ['java', 'Java и рендер'],
  ['java2', 'Java на диске'],
  ['launcher', 'Лаунчер'],
  ['greet', 'Приветствие']
];

export async function mountSettings(root) {
  const s = await api.settings.getAll();
  store.settings = s;
  const ram = await api.ram.suggest().catch(() => ({ recommendedMb: 4096, totalMb: 0, freeMb: 0 }));
  const shell = el('div', { class: 'settings-shell' });
  const rail = el('nav', { class: 'settings-rail' });
  rail.appendChild(el('p', { class: 'kicker', text: 'РАЗДЕЛЫ' }));
  for (const [id, title] of SECTIONS) {
    rail.appendChild(el('button', {
      class: 'settings-jump',
      type: 'button',
      text: title,
      onclick: () => {
        const n = document.getElementById('set-' + id);
        if (n) n.scrollIntoView({ behavior: 'smooth', block: 'start' });
        rail.querySelectorAll('.settings-jump').forEach((b) => b.classList.remove('on'));
        rail.querySelector(`[data-id="${id}"]`) && rail.querySelector(`[data-id="${id}"]`).classList.add('on');
      }
    }));
    rail.lastChild.setAttribute('data-id', id);
  }
  const wrap = el('div', { class: 'settings-pane' });
  wrap.appendChild(el('p', { class: 'kicker', text: 'НАСТРОЙКИ' }));
  wrap.appendChild(el('h2', { class: 'h2', text: 'Лаунчер под себя' }));

  function block(title, id) {
    const h = el('h3', { class: 'settings-sec', text: title });
    if (id) h.id = 'set-' + id;
    wrap.appendChild(h);
  }

  block('Тема', 'theme');
  let colorInput = null;
  const grid = el('div', { class: 'theme-grid', style: 'margin-bottom:14px' });
  for (const [id, title, bg, accent, mid] of THEMES) {
    const b = el('button', { class: 'theme-swatch theme-' + id + (((s.ui && s.ui.theme) || 'dark') === id ? ' on' : ''), onclick: async () => {
      await api.settings.set('ui.theme', id);
      await api.settings.set('ui.accent', '');
      const root = document.documentElement;
      root.style.removeProperty('--accent');
      root.style.removeProperty('--accent-2');
      root.style.removeProperty('--play');
      root.style.removeProperty('--play-2');
      if (colorInput) colorInput.value = accent;
      root.setAttribute('data-theme', id);
      store.settings.ui = store.settings.ui || {};
      store.settings.ui.theme = id;
      store.settings.ui.accent = '';
      if (window.__cryndelApplyUi) window.__cryndelApplyUi();
      grid.querySelectorAll('.theme-swatch').forEach((n) => n.classList.remove('on'));
      b.classList.add('on');
      toast('Тема: ' + title);
    } });
    const prev = el('div', { class: 'preview' });
    prev.style.background = 'linear-gradient(135deg, ' + bg + ' 0%, ' + (mid || bg) + ' 48%, ' + accent + ' 100%)';
    b.appendChild(prev);
    b.appendChild(el('strong', { text: title, style: 'display:block' }));
    b.appendChild(el('span', { class: 'hint', text: id, style: 'font-size:10px' }));
    grid.appendChild(b);
  }
  wrap.appendChild(grid);

  const themeAccent = (THEMES.find(([id]) => id === ((s.ui && s.ui.theme) || 'dark')) || THEMES[0])[3];
  const accent = el('input', { type: 'color', value: (s.ui && s.ui.accent) || themeAccent });
  colorInput = accent;
  accent.addEventListener('change', async () => {
    await api.settings.set('ui.accent', accent.value);
    document.documentElement.style.setProperty('--accent', accent.value);
  });
  wrap.appendChild(field('Цвет интерфейса (перекрывает тему)', accent));

  const radius = el('input', { class: 'field', type: 'range', min: '4', max: '28', value: String((s.ui && s.ui.radius) || 16) });
  radius.addEventListener('input', async () => {
    document.documentElement.style.setProperty('--radius', radius.value + 'px');
    await api.settings.set('ui.radius', Number(radius.value));
  });
  wrap.appendChild(field('Скругление рамок', radius));

  const nav = customSelect([
    { value: 'left', label: 'Слева' },
    { value: 'right', label: 'Справа' },
    { value: 'top', label: 'Сверху' },
    { value: 'bottom', label: 'Снизу' }
  ], (s.ui && s.ui.navPos) || 'left', async (v) => {
    await api.settings.set('ui.navPos', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.navPos = v;
    if (window.__cryndelApplyUi) window.__cryndelApplyUi();
  });
  wrap.appendChild(field('Где навигация', nav));

  wrap.appendChild(field('Шрифт главной', customSelect([
    { value: 'default', label: 'Обычный' },
    { value: 'minecraft', label: 'акура' },
    { value: 'title', label: 'Динамо' },
    { value: 'classic', label: 'Классический' }
  ], (s.ui && s.ui.homeFont) || 'default', async (v) => {
    await api.settings.set('ui.homeFont', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.homeFont = v;
    if (window.__cryndelApplyUi) window.__cryndelApplyUi();
  })));

  block('Иконки', 'icons');
  wrap.appendChild(el('p', {
    class: 'hint',
    text: 'Выбери значок для настроек, удаления, Modrinth, модов и плагинов. Можно импортировать свой SVG-файл: он будет проверен и сохранён только для этого действия.'
  }));
  const iconOptions = {
    gear: { label: 'Настройки', choices: ['gear', 'sliders', 'pal', 'ver'] },
    trash: { label: 'Удаление', choices: ['trash', 'x', 'off', 'folder'] },
    mr: { label: 'Modrinth', choices: ['mr', 'grid', 'search', 'net'] },
    mods: { label: 'Моды', choices: ['mods', 'puzzle', 'plug', 'file'] },
    plug: { label: 'Плагины', choices: ['puzzle', 'plug', 'page', 'inst'] }
  };
  const iconLabels = {
    gear: 'Шестерёнка',
    sliders: 'Ползунки',
    pal: 'Палитра',
    ver: 'Список',
    trash: 'Корзина',
    x: 'Крестик',
    off: 'Отключение',
    folder: 'Папка',
    mr: 'Знак Modrinth',
    grid: 'Сетка',
    search: 'Поиск',
    net: 'Глобус',
    mods: 'Пазл',
    puzzle: 'Пазл',
    plug: 'Штекер',
    file: 'Файл',
    page: 'Страница',
    inst: 'Плитки'
  };
  const iconState = { ...((s.ui && s.ui.iconOverrides) || {}) };
  const saveIconSettings = async (next) => {
    await api.settings.set('ui.iconOverrides', next);
    for (const key of Object.keys(iconState)) delete iconState[key];
    Object.assign(iconState, next);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.iconOverrides = { ...iconState };
    setIconOverrides(iconState);
  };
  const iconGrid = el('div', { class: 'icon-settings-grid' });
  for (const [key, config] of Object.entries(iconOptions)) {
    const card = el('div', { class: 'icon-setting-card' });
    const heading = el('div', { class: 'icon-setting-heading' });
    const preview = el('span', { class: 'icon-setting-preview' });
    preview.innerHTML = svg(key);
    heading.appendChild(preview);
    heading.appendChild(el('strong', { text: config.label }));
    card.appendChild(heading);
    const current = iconState[key];
    const options = [{ value: '', label: 'Стандартный' }, ...config.choices.map((choice) => ({
      value: choice,
      label: iconLabels[choice] || choice
    }))];
    if (current && typeof current === 'object') options.push({ value: '__custom', label: 'Мой SVG' });
    const picker = customSelect(options, typeof current === 'string' ? current : (current ? '__custom' : ''), async (value) => {
      if (value === '__custom') return;
      const next = { ...iconState };
      if (value) next[key] = value;
      else delete next[key];
      try {
        await saveIconSettings(next);
        toast(`${config.label}: ${value ? (iconLabels[value] || 'свой SVG') : 'стандартная иконка'}`);
      } catch (err) {
        const previous = iconState[key];
        const previousValue = typeof previous === 'string' ? previous : (previous ? '__custom' : '');
        picker.value = previousValue;
        const label = options.find((option) => option.value === previousValue);
        const pickerLabel = picker.querySelector('.cselect-btn span');
        if (pickerLabel && label) pickerLabel.textContent = label.label;
        toast(err.message || 'Не удалось сохранить иконку', 'bad');
      }
    });
    card.appendChild(field('Вариант', picker));
    const actions = el('div', { class: 'row icon-setting-actions' });
    const file = el('input', { type: 'file', accept: '.svg,image/svg+xml', class: 'icon-file-input' });
    const importButton = el('button', {
      class: 'btn btn-sm',
      type: 'button',
      text: 'Загрузить SVG',
      onclick: () => file.click()
    });
    file.addEventListener('change', async () => {
      try {
        const selected = file.files && file.files[0];
        if (!selected) return;
        if (selected.size > 24 * 1024) throw new Error('Размер SVG не должен превышать 24 КБ');
        const next = { ...iconState, [key]: sanitizeIconSvg(await selected.text()) };
        await saveIconSettings(next);
        if (!options.some((option) => option.value === '__custom')) options.push({ value: '__custom', label: 'Мой SVG' });
        picker.value = '__custom';
        const pickerLabel = picker.querySelector('.cselect-btn span');
        if (pickerLabel) pickerLabel.textContent = 'Мой SVG';
        toast(`SVG для «${config.label}» сохранён`);
      } catch (err) {
        toast(err.message || 'Не удалось загрузить SVG', 'bad');
      } finally {
        file.value = '';
      }
    });
    actions.appendChild(importButton);
    actions.appendChild(file);
    actions.appendChild(el('button', {
      class: 'btn btn-sm btn-ghost',
      type: 'button',
      text: 'Сбросить',
      onclick: async () => {
        const next = { ...iconState };
        delete next[key];
        try {
          await saveIconSettings(next);
          picker.value = '';
          const pickerLabel = picker.querySelector('.cselect-btn span');
          if (pickerLabel) pickerLabel.textContent = 'Стандартный';
          toast(`Стандартная иконка «${config.label}» восстановлена`);
        } catch (err) {
          toast(err.message || 'Не удалось сбросить иконку', 'bad');
        }
      }
    }));
    card.appendChild(actions);
    iconGrid.appendChild(card);
  }
  wrap.appendChild(iconGrid);

  const lang = el('select', { class: 'field' });
  lang.appendChild(el('option', { value: 'ru', text: 'Русский' }));
  lang.appendChild(el('option', { value: 'en', text: 'English' }));
  lang.value = (s.ui && s.ui.language) || 'ru';
  lang.addEventListener('change', async () => {
    await api.settings.set('ui.language', lang.value);
    await api.settings.set('game.language', lang.value);
    await loadLocale(lang.value);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.language = lang.value;
    if (window.__cryndelRefresh) await window.__cryndelRefresh();
    toast(lang.value === 'en' ? 'Language saved' : 'Язык сохранён');
  });
  wrap.appendChild(field('Язык лаунчера и Minecraft', lang));

  block('Свой CSS', 'css');
  wrap.appendChild(el('p', { class: 'hint', text: 'Здесь можно переопределить любые стили лаунчера. Пиши обычный CSS — он применяется сразу и хранится между запусками.' }));
  const cssArea = el('textarea', {
    class: 'field css-editor',
    spellcheck: 'false',
    style: 'min-height:150px;font-family:var(--mono);font-size:12.5px;line-height:1.5',
    placeholder: ':root { --accent: #7c9cff; }\n.foot { backdrop-filter: blur(24px); }'
  });
  cssArea.value = await api.theme.read().catch(() => '');
  wrap.appendChild(cssArea);
  const cssRow = el('div', { class: 'row', style: 'margin-top:8px' });
  cssRow.appendChild(el('button', { class: 'btn btn-sky', text: 'Применить CSS', onclick: async () => {
    try {
      await api.theme.write(cssArea.value);
      await applyCustomCssLive();
      toast('CSS применён');
    } catch (e) { toast(e.message || 'CSS отклонён', 'bad'); }
  } }));
  cssRow.appendChild(el('button', { class: 'btn', text: 'Из файла…', onclick: async () => {
    const r = await api.theme.import();
    if (r && r.ok) {
      cssArea.value = await api.theme.read().catch(() => '');
      await applyCustomCssLive();
      toast('CSS загружен');
    } else if (r && r.error) {
      toast(r.error, 'bad');
    }
  } }));
  cssRow.appendChild(el('button', { class: 'btn btn-danger', text: 'Очистить', onclick: async () => {
    await api.theme.clear();
    cssArea.value = '';
    await applyCustomCssLive();
    toast('Свой CSS удалён');
  } }));
  wrap.appendChild(cssRow);

  block('Главная и фон', 'home');
  wrap.appendChild(chk('Видео-обои зациклить', !s.ui || s.ui.bgLoop !== false, async (v) => {
    await api.settings.set('ui.bgLoop', v);
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));
  wrap.appendChild(chk('Всегда показывать анимацию первого открытия', Boolean(s.ui && s.ui.alwaysSplash), async (v) => {
    await api.settings.set('ui.alwaysSplash', v);
  }));
  const animDur = el('input', { class: 'field', type: 'range', min: '100', max: '300', step: '20', value: String((s.ui && s.ui.animationDuration) || 140) });
  const animDurLab = el('span', { class: 'hint', text: ((s.ui && s.ui.animationDuration) || 140) + ' мс' });
  animDur.addEventListener('input', () => {
    animDurLab.textContent = animDur.value + ' мс';
    document.documentElement.style.setProperty('--anim-dur', animDur.value + 'ms');
  });
  animDur.addEventListener('change', async () => {
    await api.settings.set('ui.animationDuration', Number(animDur.value));
  });
  wrap.appendChild(field('Длительность появления страниц', animDur));
  wrap.appendChild(animDurLab);

  const splashDur = el('input', { class: 'field', type: 'number', min: '0', max: '30000', step: '500', value: String((s.ui && s.ui.splashDuration) || 0) });
  splashDur.addEventListener('change', async () => {
    await api.settings.set('ui.splashDuration', Number(splashDur.value) || 0);
  });
  wrap.appendChild(field('Длительность заставки, мс (0 — как в видео)', splashDur));

  const caroSec = el('input', { class: 'field', type: 'range', min: '3', max: '30', value: String((s.ui && s.ui.carouselSeconds) || 10) });
  const caroSecLab = el('span', { class: 'hint', text: ((s.ui && s.ui.carouselSeconds) || 10) + ' сек' });
  caroSec.addEventListener('input', () => { caroSecLab.textContent = caroSec.value + ' сек'; });
  caroSec.addEventListener('change', async () => {
    await api.settings.set('ui.carouselSeconds', Number(caroSec.value) || 10);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.carouselSeconds = Number(caroSec.value) || 10;
  });
  wrap.appendChild(field('Смена слайда обучения', caroSec));
  wrap.appendChild(caroSecLab);

  wrap.appendChild(chk('Показывать статистику на главной', !s.ui || s.ui.statCards !== false, async (v) => {
    await api.settings.set('ui.statCards', v);
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));
  wrap.appendChild(chk('Показывать кнопки действий на главной', !s.ui || s.ui.homeActions !== false, async (v) => {
    await api.settings.set('ui.homeActions', v);
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));
  wrap.appendChild(chk('Компактный интерфейс', Boolean(s.ui && s.ui.compact), async (v) => {
    await api.settings.set('ui.compact', v);
    document.documentElement.setAttribute('data-compact', v ? 'on' : 'off');
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.compact = v;
  }));
  wrap.appendChild(chk('Плавное свечение акцента', !s.ui || s.ui.accentGlow !== false, async (v) => {
    await api.settings.set('ui.accentGlow', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.accentGlow = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));
  wrap.appendChild(chk('Приветствие по нику на главной', !s.ui || s.ui.homeGreeting !== false, async (v) => {
    await api.settings.set('ui.homeGreeting', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.homeGreeting = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));

  const scale = el('input', { class: 'field', type: 'range', min: '80', max: '130', step: '5', value: String((s.ui && s.ui.uiScale) || 100) });
  const scaleLab = el('span', { class: 'hint', text: ((s.ui && s.ui.uiScale) || 100) + '%' });
  scale.addEventListener('input', () => {
    scaleLab.textContent = scale.value + '%';
    const factor = Number(scale.value) / 100;
    document.documentElement.style.setProperty('--ui-scale', String(factor));
    if (api.window && api.window.setZoom) api.window.setZoom(factor).catch(() => {});
  });
  scale.addEventListener('change', async () => {
    await api.settings.set('ui.uiScale', Number(scale.value) || 100);
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  });
  wrap.appendChild(field('Масштаб интерфейса', scale));
  wrap.appendChild(scaleLab);

  const sideW = el('input', { class: 'field', type: 'range', min: '64', max: '132', step: '4', value: String((s.ui && s.ui.navWidth) || 92) });
  const sideWLab = el('span', { class: 'hint', text: ((s.ui && s.ui.navWidth) || 92) + ' px' });
  sideW.addEventListener('input', () => {
    sideWLab.textContent = sideW.value + ' px';
    // Write the *user* width, not the resolved --nav: --nav is capped by the
    // responsive breakpoints, so an inline --nav would fight the media queries.
    document.documentElement.style.setProperty('--nav-user', sideW.value + 'px');
  });
  sideW.addEventListener('change', async () => {
    await api.settings.set('ui.navWidth', Number(sideW.value) || 92);
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  });
  wrap.appendChild(field('Ширина панели навигации', sideW));
  wrap.appendChild(sideWLab);

  const radiusTop = el('input', { class: 'field', type: 'range', min: '0', max: '30', value: String((s.ui && s.ui.cardRadius) || 18) });
  const radiusTopLab = el('span', { class: 'hint', text: ((s.ui && s.ui.cardRadius) || 18) + ' px' });
  radiusTop.addEventListener('input', () => {
    radiusTopLab.textContent = radiusTop.value + ' px';
    document.documentElement.style.setProperty('--card-radius', radiusTop.value + 'px');
  });
  radiusTop.addEventListener('change', async () => {
    await api.settings.set('ui.cardRadius', Number(radiusTop.value) || 18);
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  });
  wrap.appendChild(field('Скругление карточек', radiusTop));
  wrap.appendChild(radiusTopLab);

  // Opacity + blur are applied straight to the root variables so the whole
  // window restyles on the spot, with the value persisted for next launch.
  const opac = el('input', { class: 'field', type: 'range', min: '30', max: '100', step: '5', value: String((s.ui && s.ui.panelOpacity) || 100) });
  const opacLab = el('span', { class: 'hint', text: ((s.ui && s.ui.panelOpacity) || 100) + '%' });
  opac.addEventListener('input', () => {
    opacLab.textContent = opac.value + '%';
    document.documentElement.style.setProperty('--panel-pct', opac.value + '%');
  });
  opac.addEventListener('change', async () => {
    await api.settings.set('ui.panelOpacity', Number(opac.value));
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  });
  wrap.appendChild(field('Прозрачность панелей', opac));
  wrap.appendChild(opacLab);

  const blurRange = el('input', { class: 'field', type: 'range', min: '0', max: '40', step: '2', value: String((s.ui && s.ui.glassBlur) || 0) });
  const blurLab = el('span', { class: 'hint', text: ((s.ui && s.ui.glassBlur) || 0) ? ((s.ui && s.ui.glassBlur) || 0) + ' px' : 'как в теме' });
  blurRange.addEventListener('input', () => {
    const v = Number(blurRange.value);
    blurLab.textContent = v ? v + ' px' : 'как в теме';
    if (v > 0) document.documentElement.style.setProperty('--glass-blur', v + 'px');
    else document.documentElement.style.removeProperty('--glass-blur');
  });
  blurRange.addEventListener('change', async () => {
    await api.settings.set('ui.glassBlur', Number(blurRange.value) || 0);
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  });
  wrap.appendChild(field('Размытие стекла', blurRange));
  wrap.appendChild(blurLab);

  const navIcon = el('input', { class: 'field', type: 'range', min: '14', max: '28', step: '1', value: String((s.ui && s.ui.navIconSize) || 18) });
  const navIconLab = el('span', { class: 'hint', text: ((s.ui && s.ui.navIconSize) || 18) + ' px' });
  navIcon.addEventListener('input', () => {
    navIconLab.textContent = navIcon.value + ' px';
    document.documentElement.style.setProperty('--nav-icon', navIcon.value + 'px');
  });
  navIcon.addEventListener('change', async () => {
    await api.settings.set('ui.navIconSize', Number(navIcon.value) || 18);
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  });
  wrap.appendChild(field('Размер иконок навигации', navIcon));
  wrap.appendChild(navIconLab);

  wrap.appendChild(field('Позиция уведомлений', customSelect([
    { value: 'bottom', label: 'Снизу справа' },
    { value: 'top', label: 'Сверху справа' }
  ], (s.ui && s.ui.toastPos) || 'bottom', async (v) => {
    await api.settings.set('ui.toastPos', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.toastPos = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  })));

  const toastLife = el('input', { class: 'field', type: 'range', min: '1200', max: '12000', step: '200', value: String((s.ui && s.ui.toastDuration) || 4200) });
  const toastLifeLab = el('span', { class: 'hint', text: (((s.ui && s.ui.toastDuration) || 4200) / 1000).toFixed(1) + ' сек' });
  toastLife.addEventListener('input', () => { toastLifeLab.textContent = (Number(toastLife.value) / 1000).toFixed(1) + ' сек'; });
  toastLife.addEventListener('change', async () => {
    await api.settings.set('ui.toastDuration', Number(toastLife.value) || 4200);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.toastDuration = Number(toastLife.value) || 4200;
  });
  wrap.appendChild(field('Сколько висят уведомления', toastLife));
  wrap.appendChild(toastLifeLab);

  wrap.appendChild(field('Угол панели загрузок и уведомлений', customSelect([
    { value: 'right', label: 'Снизу справа' },
    { value: 'left', label: 'Снизу слева' }
  ], (s.ui && s.ui.dockPos) || 'right', async (v) => {
    await api.settings.set('ui.dockPos', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.dockPos = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  })));

  const bgBlur = el('input', { class: 'field', type: 'range', min: '0', max: '24', step: '1', value: String((s.ui && s.ui.bgBlur) || 0) });
  const bgBlurLab = el('span', { class: 'hint', text: ((s.ui && s.ui.bgBlur) || 0) + ' px' });
  bgBlur.addEventListener('input', () => {
    bgBlurLab.textContent = bgBlur.value + ' px';
    document.documentElement.style.setProperty('--bg-blur', bgBlur.value + 'px');
  });
  bgBlur.addEventListener('change', async () => {
    await api.settings.set('ui.bgBlur', Number(bgBlur.value) || 0);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.bgBlur = Number(bgBlur.value) || 0;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  });
  wrap.appendChild(field('Размытие обоев', bgBlur));
  wrap.appendChild(bgBlurLab);

  wrap.appendChild(chk('Подписи под иконками навигации', !s.ui || s.ui.navLabels !== false, async (v) => {
    await api.settings.set('ui.navLabels', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.navLabels = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));

  wrap.appendChild(chk('Подъём карточек при наведении', !s.ui || s.ui.hoverLift !== false, async (v) => {
    await api.settings.set('ui.hoverLift', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.hoverLift = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));

  wrap.appendChild(chk('Строка состояния (пинг и онлайн)', !s.ui || s.ui.showStatusBar !== false, async (v) => {
    await api.settings.set('ui.showStatusBar', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.showStatusBar = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));

  wrap.appendChild(field('Плотность интерфейса', customSelect([
    { value: 'cozy', label: 'Просторно' },
    { value: 'normal', label: 'Обычно' },
    { value: 'dense', label: 'Плотно' }
  ], (s.ui && s.ui.density) || 'normal', async (v) => {
    await api.settings.set('ui.density', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.density = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  })));

  wrap.appendChild(field('Позиция панели действий', customSelect([
    { value: 'auto', label: 'Как в теме' },
    { value: 'top', label: 'Сверху' },
    { value: 'bottom', label: 'Снизу' }
  ], (s.ui && s.ui.toolsPos) || 'auto', async (v) => {
    await api.settings.set('ui.toolsPos', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.toolsPos = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  })));

  block('Производительность', 'performance');
  wrap.appendChild(el('p', {
    class: 'hint',
    text: 'Отключай эффекты по одному: выбранные значения сохраняются, а внешний вид можно вернуть в любой момент.'
  }));
  wrap.appendChild(chk('Лёгкая анимация открытия страниц', !s.ui || s.ui.animations !== false, async (v) => {
    await api.settings.set('ui.animations', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.animations = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }, 'Короткое появление всего экрана через opacity, без анимации каждого элемента. Включено по умолчанию.'));
  wrap.appendChild(chk('Лёгкие реакции кнопок и карточек', !s.ui || s.ui.animationInteractions !== false, async (v) => {
    await api.settings.set('ui.animationInteractions', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.animationInteractions = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }, 'Короткие переходы цвета и небольшие реакции на наведение.'));
  wrap.appendChild(chk('Плавное появление уведомлений', !s.ui || s.ui.animationNotifications !== false, async (v) => {
    await api.settings.set('ui.animationNotifications', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.animationNotifications = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));
  wrap.appendChild(chk('Анимированные SVG-иконки', !s.ui || s.ui.iconAnimations !== false, async (v) => {
    await api.settings.set('ui.iconAnimations', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.iconAnimations = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }, 'Короткая реакция иконок при наведении. Не запускает постоянную анимацию и отключается вместе с reduced motion.'));
  wrap.appendChild(chk('Движение декоративного фона и курсора заставки', Boolean(s.ui && s.ui.animationBackground), async (v) => {
    await api.settings.set('ui.animationBackground', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.animationBackground = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }, 'Включает медленное движение фоновых свечений и мигающий курсор заставки.'));
  wrap.appendChild(chk('Видео на фоне', !s.ui || s.ui.backgroundVideo !== false, async (v) => {
    await api.settings.set('ui.backgroundVideo', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.backgroundVideo = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi({ background: true });
  }, 'При выключении вместо видео используется статичный фон, если он доступен.'));
  wrap.appendChild(chk('Движущиеся фоновые свечения', !s.ui || s.ui.ambientEffects !== false, async (v) => {
    await api.settings.set('ui.ambientEffects', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.ambientEffects = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));
  wrap.appendChild(chk('Размытие и тени стеклянных панелей', !s.ui || s.ui.blurEffects !== false, async (v) => {
    await api.settings.set('ui.blurEffects', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.blurEffects = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }, 'Отключает размытие панелей и обоев, не сбрасывая выбранную силу размытия.'));
  let particleCount;
  wrap.appendChild(chk('Частицы на фоне', Boolean(s.ui && s.ui.particles), async (v) => {
    await api.settings.set('ui.particles', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.particles = v;
    particleCount.disabled = !v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi({ particles: true });
  }));
  particleCount = el('input', {
    class: 'field',
    type: 'range',
    min: '8',
    max: '60',
    step: '4',
    value: String((s.ui && s.ui.particleCount) || 28),
    disabled: !(s.ui && s.ui.particles)
  });
  const particleCountLab = el('span', {
    class: 'hint',
    text: String((s.ui && s.ui.particleCount) || 28)
  });
  particleCount.addEventListener('input', () => {
    particleCountLab.textContent = particleCount.value;
  });
  particleCount.addEventListener('change', async () => {
    const count = Number(particleCount.value);
    await api.settings.set('ui.particleCount', count);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.particleCount = count;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi({ particles: true });
  });
  wrap.appendChild(field('Количество частиц', particleCount));
  wrap.appendChild(particleCountLab);

  block('Звук', 'sound');
  wrap.appendChild(chk('Звуки интерфейса и заставки', !s.ui || s.ui.sounds !== false, async (v) => {
    await api.settings.set('ui.sounds', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.sounds = v;
    if (v) sound.ok();
  }));
  const vol = el('input', { class: 'field', type: 'range', min: '0', max: '100', value: String(Math.round(((s.ui && s.ui.soundVolume != null ? s.ui.soundVolume : 0.6)) * 100)) });
  const volLab = el('span', { class: 'hint', text: Math.round(((s.ui && s.ui.soundVolume != null ? s.ui.soundVolume : 0.6)) * 100) + '%' });
  vol.addEventListener('input', () => {
    volLab.textContent = vol.value + '%';
    document.documentElement.style.setProperty('--sound-volume', String(Number(vol.value) / 100));
  });
  vol.addEventListener('change', async () => {
    await api.settings.set('ui.soundVolume', Number(vol.value) / 100);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.soundVolume = Number(vol.value) / 100;
    sound.ok();
  });
  wrap.appendChild(field('Громкость звуков', vol));
  wrap.appendChild(volLab);

  wrap.appendChild(chk('Клики со звуком', !s.ui || s.ui.clickSounds !== false, async (v) => {
    await api.settings.set('ui.clickSounds', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.clickSounds = v;
  }));
  wrap.appendChild(chk('Звук при наборе текста', !s.ui || s.ui.typingSounds !== false, async (v) => {
    await api.settings.set('ui.typingSounds', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.typingSounds = v;
  }));

  // ---- Custom sounds ------------------------------------------------------
  // Every event gets its own volume, mute switch and file picker. Files live in
  // `muzick`; the picker copies nothing, it just remembers the path, so the
  // player can keep their own library where it already is.
  const SOUND_ROWS = [
    ['klick', 'Клик мыши'],
    ['knopka', 'Нажатие кнопки'],
    ['sew', 'Выбор в списке'],
    ['posluzunok', 'Движение ползунка'],
    ['zvukprinapisanii', 'Набор текста'],
    ['interfeyse', 'Открытие окна'],
    ['ura', 'Успех / готово'],
    ['eror', 'Ошибка'],
    ['warn', 'Предупреждение'],
    ['zastavka', 'Заставка / запуск']
  ];
  let soundFiles = await api.sounds.payload().catch(() => ({ sounds: {}, music: [] }));
  const soundList = el('div', { class: 'sound-list' });
  for (const [event, label] of SOUND_ROWS) {
    const row = el('div', { class: 'sound-row' });
    const name = el('div', { class: 'sound-name' });
    name.appendChild(el('strong', { text: label }));
    const state = el('span', { class: 'hint', text: (s.ui && s.ui.soundFiles && s.ui.soundFiles[event]) ? 'свой файл' : 'встроенный' });
    name.appendChild(state);
    row.appendChild(name);

    const own = el('input', {
      class: 'sound-vol', type: 'range', min: '0', max: '100',
      value: String(Math.round((((s.ui && s.ui.soundVolumes) || {})[event] != null ? s.ui.soundVolumes[event] : 1) * 100))
    });
    own.addEventListener('input', async () => {
      const v = Number(own.value) / 100;
      await api.settings.set(`ui.soundVolumes.${event}`, v);
      store.settings.ui = store.settings.ui || {};
      store.settings.ui.soundVolumes = store.settings.ui.soundVolumes || {};
      store.settings.ui.soundVolumes[event] = v;
    });
    row.appendChild(own);

    const muted = el('input', { type: 'checkbox' });
    muted.checked = Boolean(s.ui && s.ui.soundMuted && s.ui.soundMuted[event]);
    muted.addEventListener('change', async () => {
      await api.settings.set(`ui.soundMuted.${event}`, muted.checked);
      store.settings.ui = store.settings.ui || {};
      store.settings.ui.soundMuted = store.settings.ui.soundMuted || {};
      store.settings.ui.soundMuted[event] = muted.checked;
    });
    muted.setAttribute('aria-label', 'Выключить этот звук');
    row.appendChild(muted);

    row.appendChild(iconBtn('play', 'Послушать', () => sound.play(event)));
    row.appendChild(iconBtn('folder', 'Свой файл', async () => {
      const r = await api.sounds.pick(event);
      if (r && r.ok) {
        soundFiles = await api.sounds.payload().catch(() => soundFiles);
        state.textContent = 'свой файл';
        toast('Звук обновлён');
        sound.play(event);
      }
    }));
    row.appendChild(iconBtn('refresh', 'Вернуть встроенный', async () => {
      await api.sounds.clear(event);
      soundFiles = await api.sounds.payload().catch(() => soundFiles);
      state.textContent = 'встроенный';
      toast('Вернул встроенный звук');
    }));
    soundList.appendChild(row);
  }
  wrap.appendChild(soundList);
  const soundRow = el('div', { class: 'row', style: 'margin-top:8px' });
  soundRow.appendChild(el('button', { class: 'btn', text: 'Открыть папку muzick', onclick: () => api.system.openPath('muzick') }));
  soundRow.appendChild(el('button', { class: 'btn btn-ghost', text: 'Восстановить все звуки', onclick: async () => {
    await api.sounds.reset();
    await api.sounds.regenerate();
    soundFiles = await api.sounds.payload().catch(() => soundFiles);
    toast('Звуки сброшены');
  } }));
  wrap.appendChild(soundRow);

  block('Музыка (папка muzick/fon)', 'music');
  const musicTracks = (soundFiles && soundFiles.music) || [];
  wrap.appendChild(el('p', {
    class: 'hint',
    text: musicTracks.length
      ? `Найдено треков: ${musicTracks.length}. Играют в лаунчере фоном, настройки ниже.`
      : 'Нажми «Открыть папку» и положи туда mp3/ogg/wav — треки появятся здесь.'
  }));
  const musicVol = el('input', { class: 'field', type: 'range', min: '0', max: '100', value: String(Math.round(((s.ui && s.ui.musicVolume != null ? s.ui.musicVolume : 0.5)) * 100)) });
  const musicVolLab = el('span', { class: 'hint', text: Math.round(((s.ui && s.ui.musicVolume != null ? s.ui.musicVolume : 0.5)) * 100) + '%' });
  musicVol.addEventListener('input', () => {
    musicVolLab.textContent = musicVol.value + '%';
    setMusicVolume(Number(musicVol.value) / 100);
  });
  musicVol.addEventListener('change', async () => {
    await api.settings.set('ui.musicVolume', Number(musicVol.value) / 100);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.musicVolume = Number(musicVol.value) / 100;
  });
  wrap.appendChild(field('Громкость музыки', musicVol));
  wrap.appendChild(musicVolLab);
  wrap.appendChild(field('Режим музыки', customSelect([
    { value: 'playlist', label: 'Плейлист по кругу' },
    { value: 'single', label: 'Один трек повторять' },
    { value: 'once', label: 'Проиграть один раз' },
    { value: 'off', label: 'Выключена' }
  ], (s.ui && s.ui.musicMode) || 'playlist', async (v) => {
    await api.settings.set('ui.musicMode', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.musicMode = v;
    playMusic({ restart: true });
  })));
  wrap.appendChild(chk('Запускать музыку автоматически', Boolean(s.ui && s.ui.musicAutoplay), async (v) => {
    await api.settings.set('ui.musicAutoplay', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.musicAutoplay = v;
    if (v) playMusic({});
  }));
  wrap.appendChild(chk('Показывать карточку музыки на главной', !s.ui || s.ui.showMusicCard !== false, async (v) => {
    await api.settings.set('ui.showMusicCard', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.showMusicCard = v;
    if (window.__cryndelApplyUi) window.__cryndelApplyUi();
  }));
  const musicRow = el('div', { class: 'row', style: 'margin-top:8px' });
  musicRow.appendChild(el('button', { class: 'btn', text: 'Открыть папку', onclick: () => api.sounds.openMusicFolder() }));
  wrap.appendChild(musicRow);

  wrap.appendChild(chk('Карусель обучения на главной', !s.ui || s.ui.hideCarousel !== true, async (v) => {
    await api.settings.set('ui.hideCarousel', !v);
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));
  wrap.appendChild(chk('Виджеты на главной ', Boolean(s.ui && s.ui.showWidgets), async (v) => {
    await api.settings.set('ui.showWidgets', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.showWidgets = v;
    if (window.__cryndelApplyUi) window.__cryndelApplyUi();
  }));

  const dim = el('input', { class: 'field', type: 'range', min: '20', max: '90', value: String(Math.round(((s.ui && s.ui.bgDim) || 0.55) * 100)) });
  dim.addEventListener('input', async () => {
    const v = Number(dim.value) / 100;
    document.documentElement.style.setProperty('--bg-dim', String(v));
    await api.settings.set('ui.bgDim', v);
  });
  wrap.appendChild(field('Затемнение фона', dim));

  const bgRow = el('div', { class: 'row', style: 'margin:8px 0 12px' });
  bgRow.appendChild(el('button', { class: 'btn btn-sky', text: 'Загрузить фон', onclick: async () => {
    const r = await api.theme.pickBackground();
    if (r && r.ok) {
      // Apply immediately — the wallpaper used to only show up after a restart.
      if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
      toast('Фон применён');
    }
  } }));
  bgRow.appendChild(el('button', { class: 'btn btn-ghost', text: 'Сбросить фон', onclick: async () => {
    await api.settings.set('ui.backgroundFile', '');
    await api.settings.set('ui.backgroundKind', 'video');
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
    toast('Фон сброшен');
  } }));
  bgRow.appendChild(el('button', { class: 'btn', text: 'Видео заставки', onclick: async () => {
    const r = await api.theme.pickSplash();
    if (r && r.ok) toast('Заставка сохранена');
  } }));
  wrap.appendChild(bgRow);

  const furRow = el('div', { class: 'row', style: 'margin-bottom:12px' });
  furRow.appendChild(el('button', { class: 'btn', text: 'Картинка фурри', onclick: async () => {
    const r = await api.theme.pickFurryImage();
    if (r && r.ok) toast('Картинка сохранена');
  } }));
  furRow.appendChild(el('button', { class: 'btn', text: '3 своих звука', onclick: async () => {
    const r = await api.theme.pickFurrySounds();
    if (r && r.ok) toast('Звуки сохранены');
  } }));
  wrap.appendChild(furRow);

  block('Память и картинка', 'game');
  const mode = el('select', { class: 'field' });
  mode.appendChild(el('option', { value: 'auto', text: 'Автоматически под систему' }));
  mode.appendChild(el('option', { value: 'manual', text: 'Задать вручную' }));
  mode.value = (s.game && s.game.memoryMode) || 'auto';
  const mem = el('input', { class: 'field', type: 'range', min: '2048', max: String(Math.max(4096, ram.totalMb - 1024 || 8192)), step: '256', value: String((s.game && s.game.defaultMemoryMb) || ram.recommendedMb) });
  const memLab = el('p', { class: 'hint', text: mem.value + ' МБ  ·  в ПК ' + ram.totalMb + ' МБ' });
  mem.addEventListener('input', () => { memLab.textContent = mem.value + ' МБ'; });
  async function saveRam() {
    await api.settings.set('game.memoryMode', mode.value);
    await api.settings.set('game.defaultMemoryMb', Number(mem.value));
    if (store.selectedId) await api.instances.update(store.selectedId, { memoryMb: Number(mem.value), memoryMode: mode.value });
    toast('RAM сохранена');
  }
  mode.addEventListener('change', saveRam);
  mem.addEventListener('change', saveRam);
  wrap.appendChild(field('Оперативка для игры', mode));
  wrap.appendChild(mem);
  wrap.appendChild(memLab);

  const w = el('input', { class: 'field', type: 'number', value: String((s.game && s.game.defaultResolution && s.game.defaultResolution.width) || 1280) });
  const h = el('input', { class: 'field', type: 'number', value: String((s.game && s.game.defaultResolution && s.game.defaultResolution.height) || 720) });
  const resRow = el('div', { class: 'row' });
  resRow.appendChild(w); resRow.appendChild(h);
  wrap.appendChild(field('Разрешение окна', resRow));
  w.addEventListener('change', () => api.settings.set('game.defaultResolution', { width: Number(w.value) || 1280, height: Number(h.value) || 720 }));
  h.addEventListener('change', () => api.settings.set('game.defaultResolution', { width: Number(w.value) || 1280, height: Number(h.value) || 720 }));

  wrap.appendChild(chk('Полный экран', s.game && s.game.defaultFullscreen, (v) => api.settings.set('game.defaultFullscreen', v)));
  block('Java и рендер', 'java');
  const javaCmd = el('input', { class: 'field', placeholder: 'Полный путь java.exe', value: (s.game && s.game.javaCommand) || '' });
  javaCmd.addEventListener('change', () => api.settings.set('game.javaCommand', javaCmd.value.trim()));
  wrap.appendChild(field('Своя команда Java', javaCmd));
  const jvm = el('input', { class: 'field', placeholder: '-XX:+UseG1GC', value: (s.game && s.game.customJvmArgs) || '' });
  jvm.addEventListener('change', () => api.settings.set('game.customJvmArgs', jvm.value.trim()));
  wrap.appendChild(field('Доп. аргументы JVM', jvm));

  const gpu = el('select', { class: 'field' });
  gpu.appendChild(el('option', { value: 'auto', text: 'Авто' }));
  const gpus = await api.system.gpus().catch(() => []);
  for (const g of gpus) gpu.appendChild(el('option', { value: g.id, text: g.name }));
  gpu.value = (s.game && s.game.gpu) || 'auto';
  gpu.addEventListener('change', () => api.settings.set('game.gpu', gpu.value));
  wrap.appendChild(field('Видеокарта', gpu));

  const render = customSelect([
    { value: 'default', label: 'По умолчанию' },
    { value: 'fabulous', label: 'Fabulous' },
    { value: 'fancy', label: 'Fancy' },
    { value: 'fast', label: 'Fast' }
  ], (s.game && s.game.graphics) || 'default', (v) => api.settings.set('game.graphics', v));
  wrap.appendChild(field('Рендер игры', render));

  const capeRow = el('div', { class: 'row', style: 'margin-top:12px' });
  const capePrev = el('img', {
    class: 'skin-prev',
    alt: 'Предпросмотр локального плаща',
    title: 'Локальный плащ для выбранной сборки'
  });
  const capeStatus = el('span', {
    class: 'hint',
    text: (s.game && s.game.capeFile) ? 'Плащ выбран' : 'Плащ не выбран'
  });
  capeRow.appendChild(capePrev);
  capeRow.appendChild(capeStatus);
  capeRow.appendChild(el('button', {
    class: 'btn',
    type: 'button',
    text: 'Выбрать плащ PNG',
    onclick: async () => {
      const result = await api.skins.importCape();
      if (result && result.ok) {
        capeStatus.textContent = 'Плащ выбран';
        const preview = await api.skins.capePreview();
        if (preview) capePrev.src = preview;
        store.settings.game = store.settings.game || {};
        store.settings.game.capeFile = result.path;
        store.settings.game.capeEnabled = true;
        toast('Плащ установлен');
      }
    }
  }));
  capeRow.appendChild(el('button', {
    class: 'btn btn-ghost',
    type: 'button',
    text: 'Убрать плащ',
    onclick: async () => {
      await api.skins.clearCape();
      capePrev.removeAttribute('src');
      capeStatus.textContent = 'Плащ не выбран';
      store.settings.game = store.settings.game || {};
      store.settings.game.capeFile = '';
      store.settings.game.capeEnabled = false;
      toast('Плащ убран');
    }
  }));
  wrap.appendChild(field('Локальный плащ (PNG)', capeRow));
  api.skins.capePreview().then((url) => {
    if (url) capePrev.src = url;
  }).catch((err) => console.error('Не удалось загрузить предпросмотр плаща:', err));

  block('Java на диске', 'java2');

  const javaBox = el('div', { class: 'card', style: 'margin:12px 0' });
  const javas = await api.system.detectJava().catch(() => []);
  if (!javas.length) javaBox.appendChild(el('p', { class: 'hint', text: 'Java не найдена — лаунчер скачает сам.' }));
  for (const j of javas) javaBox.appendChild(el('div', { text: j.path + ' (' + (j.version || '?') + ')', class: 'hint' }));
  javaBox.appendChild(el('button', { class: 'btn btn-sky', style: 'margin-top:10px', text: 'Скачать Java 21', onclick: async () => {
    try { toast('Качаю Java 21…'); await api.java.ensure(21); toast('Java готова'); }
    catch (e) { toast(e.message || 'Не удалось скачать Java', 'bad'); }
  } }));
  wrap.appendChild(javaBox);

  block('Лаунчер', 'launcher');
  wrap.appendChild(el('p', {
    class: 'hint',
    text: 'Начальный размер окна стал компактнее. Измени ширину и высоту и нажми «Применить»; выбор сохранится для следующего запуска.'
  }));
  const windowWidth = el('input', {
    class: 'field', type: 'range', min: '760', max: '1600', step: '20',
    value: String((s.ui && s.ui.windowWidth) || 1024)
  });
  const windowWidthLabel = el('span', {
    class: 'hint',
    text: `${(s.ui && s.ui.windowWidth) || 1024} px`
  });
  windowWidth.addEventListener('input', () => {
    windowWidthLabel.textContent = `${windowWidth.value} px`;
  });
  wrap.appendChild(field('Ширина окна лаунчера', windowWidth));
  wrap.appendChild(windowWidthLabel);
  const windowHeight = el('input', {
    class: 'field', type: 'range', min: '520', max: '1000', step: '20',
    value: String((s.ui && s.ui.windowHeight) || 700)
  });
  const windowHeightLabel = el('span', {
    class: 'hint',
    text: `${(s.ui && s.ui.windowHeight) || 700} px`
  });
  windowHeight.addEventListener('input', () => {
    windowHeightLabel.textContent = `${windowHeight.value} px`;
  });
  wrap.appendChild(field('Высота окна лаунчера', windowHeight));
  wrap.appendChild(windowHeightLabel);
  wrap.appendChild(el('button', {
    class: 'btn btn-sky',
    type: 'button',
    text: 'Применить размер окна',
    onclick: async () => {
      try {
        const width = Number(windowWidth.value);
        const height = Number(windowHeight.value);
        const result = await api.window.setSize(width, height);
        if (!result || result.ok === false) throw new Error((result && result.error) || 'Не удалось изменить размер');
        await api.settings.set('ui.windowWidth', result.width);
        await api.settings.set('ui.windowHeight', result.height);
        store.settings.ui.windowWidth = result.width;
        store.settings.ui.windowHeight = result.height;
        windowWidth.value = String(result.width);
        windowHeight.value = String(result.height);
        windowWidthLabel.textContent = `${result.width} px`;
        windowHeightLabel.textContent = `${result.height} px`;
        toast('Размер окна применён и сохранён');
      } catch (err) {
        toast(err.message || 'Не удалось изменить размер окна', 'bad');
      }
    }
  }));
  wrap.appendChild(chk('Discord RPC', !s.launcher || s.launcher.discordRpc !== false, async (v) => {
    await api.settings.set('launcher.discordRpc', v);
    try {
      const r = await api.discord.toggle(v);
      if (v && r && r.needsAppId) {
        toast('Discord RPC не настроен в этой сборке лаунчера', 'bad');
      } else if (v && r && r.ready === false) {
        toast('Discord не отвечает ', 'bad');
      } else if (v && r && r.ready) {
        toast('Discord подключён', 'ok');
      }
    } catch (_) { /* */ }
  }));
  const discordState = el('p', { class: 'hint', text: 'Проверяю Discord…' });
  function paintDiscord(r) {
    if (!r) { discordState.textContent = ''; return; }
    if (r.ready) { discordState.textContent = 'Discord подключён'; return; }
    if (r.needsAppId) {
      discordState.textContent = 'Discord RPC не настроен в этой сборке лаунчера';
      return;
    }
    discordState.textContent = 'Discord не подключён' + (r.error ? ' · ' + r.error : '');
  }
  api.discord.status().then(paintDiscord).catch(() => { discordState.textContent = ''; });
  wrap.appendChild(discordState);
  wrap.appendChild(chk('Сворачивать в трей при запуске игры', s.launcher && s.launcher.minimizeToTray !== false, (v) => api.settings.set('launcher.minimizeToTray', v)));
  wrap.appendChild(chk('Закрывать лаунчер при запуске игры', s.launcher && s.launcher.closeOnLaunch, (v) => api.settings.set('launcher.closeOnLaunch', v)));
  wrap.appendChild(chk('Возвращать лаунчер после закрытия игры', !s.launcher || s.launcher.showOnGameExit !== false, (v) => api.settings.set('launcher.showOnGameExit', v)));


  block('Приветствие', 'greet');
  wrap.appendChild(chk('Показывать приветствие на главной', !s.ui || s.ui.greetingEnabled !== false, async (v) => {
    await api.settings.set('ui.greetingEnabled', v);
    store.settings.ui.greetingEnabled = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));
  

  const more = el('div', { class: 'row', style: 'margin-top:18px' });
  more.appendChild(el('button', { class: 'btn btn-sky', text: 'Плагины', onclick: () => { location.hash = '#/plugins'; } }));
  more.appendChild(el('button', { class: 'btn', text: 'О лаунчере', onclick: () => { location.hash = '#/about'; } }));
  more.appendChild(el('button', { class: 'btn', text: 'Пройти обучение заново', onclick: async () => {
    if (window.__cryndelRedoOnboarding) {
      await window.__cryndelRedoOnboarding();
      toast('Обучение запущено');
    }
  } }));
  more.appendChild(el('button', { class: 'btn btn-danger', text: 'Сброс настроек', onclick: async () => {
    store.settings = await api.settings.reset();
    if (window.__cryndelApplyUi) window.__cryndelApplyUi();
    toast('Сброшено');
  } }));
  wrap.appendChild(more);
  shell.appendChild(rail);
  shell.appendChild(wrap);
  root.appendChild(shell);
}
