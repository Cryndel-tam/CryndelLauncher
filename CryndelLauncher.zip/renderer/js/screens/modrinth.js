import { api } from '../api.js';
import { store, toast } from '../state.js';
import { el, fmtNum, debounce } from '../utils.js';
import { mdToHtml } from '../md.js';
import { go } from '../router.js';
import { iconBtn, closeBtn, customSelect } from '../ui.js';
import { svg as svgRaw } from '../icons.js';

const TYPES = [
  ['mod', 'Моды'],
  ['modpack', 'Сборки'],
  ['resourcepack', 'Ресурспаки'],
  ['shader', 'Шейдеры'],
  ['datapack', 'Датапаки']
];
const LOADERS = [
  ['', 'Любой загрузчик'],
  ['fabric', 'Fabric'],
  ['forge', 'Forge'],
  ['neoforge', 'NeoForge'],
  ['quilt', 'Quilt']
];
const SORTS = [
  ['relevance', 'По запросу'],
  ['downloads', 'По загрузкам'],
  ['follows', 'По подпискам'],
  ['newest', 'Новые'],
  ['updated', 'Обновлённые']
];

function mrOpt() {
  const s = (store.settings && store.settings.modrinth) || {};
  return {
    limit: Number(s.listLimit) || 20,
    fullscreen: s.fullscreen !== false,
    svgOnly: s.svgOnly !== false
  };
}

export async function mountModrinth(root) {
  const inst = store.instances.find((i) => i.id === store.selectedId) || {};
  const opt = mrOpt();
  const state = {
    query: '',
    type: 'mod',
    loader: inst.modLoader || 'fabric',
    mcVersion: inst.mcVersion || '1.21.11',
    index: 'downloads',
    offset: 0,
    limit: opt.limit,
    total: 0,
    hits: []
  };

  const shell = el('div', { class: 'mr-shell' });
  const head = el('div', { class: 'row', style: 'justify-content:space-between;align-items:flex-start' });
  const titles = el('div');
  titles.appendChild(el('p', { class: 'kicker', text: 'МОДРИНТ' }));
  titles.appendChild(el('h2', { class: 'h2', text: 'Моды, сборки и шейдеры' }));
  head.appendChild(titles);
  const headTools = el('div', { class: 'row' });
  headTools.appendChild(iconBtn('puzzle', 'Каталог модов плагинов', () => go('#/plugin-mods')));
  headTools.appendChild(iconBtn('gear', 'Настройки Модринта', () => go('#/modrinth/settings')));
  head.appendChild(headTools);
  shell.appendChild(head);
  shell.appendChild(el('p', { class: 'hint', style: 'margin:-8px 0 16px', text: inst.name
    ? 'Фильтры под «' + inst.name + '»: ' + inst.mcVersion + ' · ' + inst.modLoader
    : 'Сначала выбери сборку — установка пойдёт в неё.' }));

  // Everything lives on one line: search takes the free space, the styled
  // pickers sit next to it. No more scattered, uneven native selects.
  const filters = el('div', { class: 'mr-filters' });
  const q = el('input', { class: 'field mr-search', placeholder: 'Поиск: моды, шейдеры, сборки…', value: state.query || '' });
  const type = customSelect(TYPES.map(([value, label]) => ({ value, label })), state.type, (v) => {
    state.type = v;
    refresh();
  });
  const loader = customSelect(LOADERS.map(([value, label]) => ({ value, label })), state.loader, (v) => {
    state.loader = v;
    refresh();
  });
  const sort = customSelect(SORTS.map(([value, label]) => ({ value, label })), state.index, (v) => {
    state.index = v;
    refresh();
  });
  const ver = el('input', { class: 'field mr-ver', placeholder: 'Версия', value: state.mcVersion });
  filters.appendChild(q);
  filters.appendChild(type);
  filters.appendChild(loader);
  filters.appendChild(ver);
  filters.appendChild(sort);
  shell.appendChild(filters);

  const list = el('div', { class: 'mr-list' });
  const pager = el('div', { class: 'pager' });
  shell.appendChild(list);
  shell.appendChild(pager);

  root.appendChild(shell);

  async function run() {
    list.replaceChildren(el('div', { class: 'hint', text: 'Ищу на Modrinth…' }));
    try {
      const data = await api.modrinth.search({
        query: state.query,
        type: state.type,
        loader: state.loader || undefined,
        mcVersion: state.mcVersion || undefined,
        limit: state.limit,
        offset: state.offset,
        index: state.index
      });
      state.hits = data.hits || [];
      state.total = data.total_hits || 0;
      renderHits();
    } catch (e) {
      list.replaceChildren(el('div', { class: 'card', text: e.message || 'Modrinth недоступен' }));
    }
  }

  function actionBtn(kind, title, fn) {
    if (opt.svgOnly) return iconBtn(kind, title, fn);
    return el('button', { class: 'btn ' + (kind === 'install' ? 'btn-sky' : 'btn-ghost'), text: title, onclick: fn });
  }

  function renderHits() {
    list.replaceChildren();
    if (!state.hits.length) {
      const empty = el('div', { class: 'empty' });
      empty.appendChild(el('h3', { text: 'Ничего не найдено' }));
      empty.appendChild(el('p', { text: 'Смени запрос или загрузчик. Sodium, Lithium, Iris — хорошее начало.' }));
      list.appendChild(empty);
      return;
    }
    const frag = document.createDocumentFragment();
    for (const hit of state.hits) {
      const card = el('div', { class: 'card mr-row' });
      const icon = el('img', { alt: '', class: 'mr-icon' });
      if (hit.icon_url) icon.setAttribute('src', hit.icon_url);
      const mid = el('div', { class: 'mr-mid' });
      mid.appendChild(el('strong', { text: hit.title || hit.slug }));
      mid.appendChild(el('div', { class: 'mr-meta', text: (hit.author || 'автор') + ' · ' + fmtNum(hit.downloads) + ' загрузок' }));
      mid.appendChild(el('p', { class: 'mr-desc', text: hit.description || '' }));
      const right = el('div', { class: 'mr-actions' });
      right.appendChild(actionBtn('install', state.type === 'modpack' ? 'Как сборку' : 'Установить', () => install(hit)));
      right.appendChild(actionBtn('page', 'Страница', () => showDetail(hit)));
      card.appendChild(icon);
      card.appendChild(mid);
      card.appendChild(right);
      frag.appendChild(card);
    }
    list.appendChild(frag);
    const page = Math.floor(state.offset / state.limit) + 1;
    const pages = Math.max(1, Math.ceil(state.total / state.limit));
    pager.replaceChildren();
    pager.appendChild(el('button', { class: 'btn', text: 'Назад', onclick: () => { state.offset = Math.max(0, state.offset - state.limit); run(); } }));
    pager.appendChild(el('span', { text: 'Страница ' + page + ' из ' + pages }));
    pager.appendChild(el('button', { class: 'btn', text: 'Вперёд', onclick: () => { if (state.offset + state.limit < state.total) { state.offset += state.limit; run(); } } }));
  }

  async function install(hit) {
    if (state.type === 'modpack') {
      try {
        const versions = await api.modrinth.getVersions(hit.project_id || hit.slug, {
          loader: state.loader || undefined,
          mcVersion: state.mcVersion || undefined
        });
        const v = (versions || [])[0];
        const file = v && ((v.files || []).find((f) => f.primary) || (v.files || [])[0]);
        if (!file || !file.url) throw new Error('Нет файла сборки');
        toast('Качаю модпак…');
        const saved = await api.inbox.downloadUrl(file.url, file.filename || (hit.slug + '.mrpack'));
        const res = window.__cryndelImportPack
          ? await window.__cryndelImportPack(saved.path)
          : await api.inbox.importMrpackPath(saved.path);
        if (res && res.instance) {
          store.selectedId = res.instance.id;
          if (window.__cryndelRefresh) await window.__cryndelRefresh();
          toast('Сборка создана: ' + res.instance.name);
          go('#/');
        }
      } catch (e) {
        toast(e.message || 'Не удалось импортировать сборку', 'bad');
      }
      return;
    }
    if (!store.selectedId) { toast('Сначала выбери сборку', 'bad'); return; }
    try {
      const res = await api.modrinth.install(store.selectedId, hit.project_id || hit.slug);
      toast('Установлено файлов: ' + ((res.installed || []).length));
    } catch (e) {
      toast(e.message || 'Ошибка установки', 'bad');
    }
  }

  async function showDetail(hit) {
    try {
      const slug = hit.project_id || hit.slug;
      const [p, versions] = await Promise.all([
        api.modrinth.getProject(slug),
        api.modrinth.getVersions(slug, {
          loader: state.loader || undefined,
          mcVersion: state.mcVersion || undefined
        }).catch(() => [])
      ]);
      const full = opt.fullscreen;
      const veil = el('div', { class: 'modal-veil' + (full ? ' full' : '') });
      const modal = el('div', { class: 'modal mr-page' + (full ? ' mr-full' : '') });
      const bar = el('div', { class: 'modal-head' });
      bar.appendChild(el('p', { class: 'kicker', text: 'МОДРИНТ' }));
      bar.appendChild(el('div', { class: 'grow' }));
      if (!full) bar.appendChild(iconBtn('full', 'На всю страницу', () => {
        veil.remove();
        const prev = opt.fullscreen;
        store.settings.modrinth = store.settings.modrinth || {};
        store.settings.modrinth.fullscreen = true;
        showDetail(hit).finally(() => { store.settings.modrinth.fullscreen = prev; });
      }));
      bar.appendChild(closeBtn(() => veil.remove()));
      modal.appendChild(bar);

      // The scrollable area and the action bar are separate boxes: the download
      // buttons used to be laid out inside the flowing content, which made them
      // drift and overlap as the description grew.
      const scroll = el('div', { class: 'mr-scroll' });
      modal.appendChild(scroll);

      const head = el('div', { class: 'mr-page-head' });
      const icon = el('img', { class: 'mr-icon lg', alt: '' });
      if (p.icon_url) icon.setAttribute('src', p.icon_url);
      const titles = el('div', { class: 'mr-head-text' });
      titles.appendChild(el('h3', { text: p.title || hit.title }));
      titles.appendChild(el('p', { class: 'mr-meta', text: fmtNum(p.downloads) + ' загрузок · ' + fmtNum(p.followers) + ' подписок' }));
      if (p.categories && p.categories.length) {
        const cats = el('div', { class: 'mr-cats' });
        for (const c of p.categories.slice(0, 6)) cats.appendChild(el('span', { class: 'badge', text: c }));
        titles.appendChild(cats);
      }
      titles.appendChild(el('p', { class: 'hint', text: p.description || '' }));
      head.appendChild(icon);
      head.appendChild(titles);
      scroll.appendChild(head);

      const gallery = el('div', { class: 'mr-gallery' });
      for (const g of (p.gallery || []).slice(0, 8)) {
        const im = el('img', { alt: g.title || '' });
        im.setAttribute('src', g.url);
        gallery.appendChild(im);
      }
      if ((p.gallery || []).length) scroll.appendChild(gallery);

      if (versions && versions.length) {
        const tog = el('button', { class: 'btn btn-ghost mr-ver-toggle', type: 'button' });
        tog.innerHTML = svgRaw('chev') + '<span>Версии (' + versions.length + ')</span>';
        const vl = el('div', { class: 'mr-ver-list' });
        for (const v of versions.slice(0, 40)) {
          const row = el('div', { class: 'mr-ver' });
          const info = el('div', { class: 'mr-ver-info' });
          info.appendChild(el('strong', { text: v.version_number || v.name }));
          info.appendChild(el('span', { class: 'hint', text: (v.game_versions || []).slice(0, 4).join(', ') }));
          row.appendChild(info);
          row.appendChild(el('button', { class: 'btn btn-sky', text: 'Установить', onclick: async () => {
            if (!store.selectedId) { toast('Сначала выбери сборку', 'bad'); return; }
            try {
              await api.modrinth.installVersion(store.selectedId, v.id);
              toast('Версия ' + (v.version_number || '') + ' установлена');
              veil.remove();
            } catch (e) { toast(e.message, 'bad'); }
          } }));
          vl.appendChild(row);
        }
        let open = false;
        tog.addEventListener('click', () => {
          open = !open;
          vl.classList.toggle('open', open);
          tog.classList.toggle('open', open);
        });
        scroll.appendChild(tog);
        scroll.appendChild(vl);
      }

      const body = el('div', { class: 'md-body' });
      body.innerHTML = mdToHtml(p.body || '');
      scroll.appendChild(body);

      // Action bar pinned to the bottom: one clear primary button, no drift.
      const foot = el('div', { class: 'mr-foot' });
      const already = store.selectedId
        ? await api.mods.hasMod(store.selectedId, slug, '').catch(() => false)
        : false;
      const instName = (store.instances.find((i) => i.id === store.selectedId) || {}).name || '';
      if (already) foot.appendChild(el('span', { class: 'badge ok', text: 'Уже в сборке' }));
      foot.appendChild(el('div', { class: 'grow' }));
      if (instName) foot.appendChild(el('span', { class: 'hint mr-foot-hint', text: 'Куда: ' + instName }));
      const primary = el('button', {
        class: 'btn btn-sky',
        text: already ? 'Переустановить' : (state.type === 'modpack' ? 'Как сборку' : 'Установить'),
        onclick: async () => { await install(hit); veil.remove(); }
      });
      foot.appendChild(primary);
      modal.appendChild(foot);

      veil.appendChild(modal);
      veil.addEventListener('click', (ev) => { if (ev.target === veil) veil.remove(); });
      document.body.appendChild(veil);
    } catch (e) {
      toast(e.message, 'bad');
    }
  }

  const refresh = debounce(() => {
    state.query = q.value.trim();
    state.mcVersion = ver.value.trim();
    state.offset = 0;
    run();
  }, 320);
  q.addEventListener('input', refresh);
  ver.addEventListener('change', refresh);
  await run();
}
