import { api } from '../api.js';
import { el } from '../utils.js';
import { go } from '../router.js';

export async function mountAbout(root) {
  const v = await api.app.getVersion().catch(() => '1.0.0');
  const wrap = el('div');
  wrap.appendChild(el('p', { class: 'kicker', text: 'CRYNDEL' }));
  wrap.appendChild(el('h2', { class: 'h2', text: 'О лаунчере' }));
  const card = el('div', { class: 'card' });
  card.appendChild(el('strong', { text: 'Cryndel Launcher v' + v, style: 'display:block;font-size:18px' }));
  card.appendChild(el('p', { class: 'hint', style: 'margin-top:8px', text: 'Лаунчер создан командой Cryndel teamОфлайн-профиль, Modrinth, изолированные сборки и Quick Play на cryndel.ru. MIT.' }));
  wrap.appendChild(card);
  const row = el('div', { class: 'row', style: 'margin-top:14px' });
  row.appendChild(el('button', { class: 'btn btn-sky', text: 'Кабинет', onclick: () => go('#/mycryndel') }));
  row.appendChild(el('button', { class: 'btn', text: 'Настройки', onclick: () => go('#/settings') }));
  wrap.appendChild(row);
  wrap.appendChild(el('p', { class: 'mr-meta', style: 'margin-top:12px', text: 'contact@cryndel.ru' }));
  root.appendChild(wrap);
}
