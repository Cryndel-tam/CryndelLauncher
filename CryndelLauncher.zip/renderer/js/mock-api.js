const wait = (ms) => new Promise((r) => setTimeout(r, ms));

function load(key, fallback) {
  try {
    const raw = localStorage.getItem('cryndel-mock-' + key);
    if (raw) return JSON.parse(raw);
  } catch (_) { /* */ }
  return fallback;
}

function save(key, value) {
  localStorage.setItem('cryndel-mock-' + key, JSON.stringify(value));
  return value;
}

const listeners = new Map();
function on(channel, cb) {
  if (!listeners.has(channel)) listeners.set(channel, new Set());
  listeners.get(channel).add(cb);
  return () => listeners.get(channel).delete(cb);
}
function emit(channel, payload) {
  const set = listeners.get(channel);
  if (!set) return;
  for (const fn of set) fn(payload);
}

function defaultSettings() {
  return {
    version: 3,
    ui: {
      language: 'ru',
      theme: 'dark',
      animations: true,
      animationInteractions: true,
      animationNotifications: true,
      animationBackground: false,
      animationDuration: 140,
      iconAnimations: true,
      iconOverrides: {},
      backgroundKind: 'video',
      backgroundFile: '',
      navPos: 'left',
      windowWidth: 1024,
      windowHeight: 700,
      accent: '#7c9cff',
      radius: 16,
      homeFont: 'default',
      bgLoop: true,
      bgDim: 0.55,
      bgVeil: 1,
      alwaysSplash: false,
      showSkin3d: false,
      particles: true,
      furryWidget: true,
      furryScale: 1,
      furryImage: '',
      furrySounds: [],
      splashFile: '',
      shotsWidget: true,
      hideCarousel: false,
      splash: true
    },
    game: {
      defaultMemoryMb: 4096,
      memoryMode: 'auto',
      javaCommand: '',
      customJvmArgs: '',
      defaultResolution: { width: 1280, height: 720 },
      defaultFullscreen: false,
      language: 'ru',
      toggleSprint: true,
      gpu: 'auto',
      graphics: 'default'
    },
    launcher: {
      closeOnLaunch: false,
      minimizeToTray: true,
      discordRpc: true
    },
    modrinth: { listLimit: 20, fullscreen: true, svgOnly: true },
    browser: { zoom: 100 },
    cabinet: { zoom: 100, keepAlive: true }
  };
}

function plant(obj, key, value) {
  const parts = String(key).split('.');
  let cur = obj;
  for (let i = 0; i < parts.length - 1; i += 1) {
    const p = parts[i];
    if (!cur[p] || typeof cur[p] !== 'object') cur[p] = {};
    cur = cur[p];
  }
  cur[parts[parts.length - 1]] = value;
  return obj;
}

const SAMPLE_MODS = [
  { project_id: 'AANobbMI', slug: 'sodium', title: 'Sodium', author: 'jellysquid3', downloads: 48200000, description: 'Современный рендер. Игра летает даже на слабом ПК.', icon_url: '', categories: ['optimization'] },
  { project_id: 'P7dR8mSH', slug: 'fabric-api', title: 'Fabric API', author: 'modmuss50', downloads: 91000000, description: 'Обязательная библиотека для почти всех Fabric-модов.', icon_url: '', categories: ['library'] },
  { project_id: 'gvQqBUqZ', slug: 'lithium', title: 'Lithium', author: 'jellysquid3', downloads: 31000000, description: 'Оптимизация игровой логики без смены геймплея.', icon_url: '', categories: ['optimization'] },
  { project_id: 'uXXgFVpS', slug: 'iris', title: 'Iris Shaders', author: 'IMS', downloads: 24000000, description: 'Шейдеры на Fabric. Совместим с Sodium.', icon_url: '', categories: ['decoration'] },
  { project_id: '9eGKb6K1', slug: 'simple-voice-chat', title: 'Simple Voice Chat', author: 'henkelmax', downloads: 18000000, description: 'Голосовой чат рядом с игроками. Нужен на Cryndel.', icon_url: '', categories: ['utility'] },
  { project_id: '1bokaNcj', slug: 'xaeros-minimap', title: "Xaero's Minimap", author: 'xaero', downloads: 42000000, description: 'Миникарта с точками, пещерами и смертей.', icon_url: '', categories: ['utility'] },
  { project_id: 'NcUtCpym', slug: 'xaeros-world-map', title: "Xaero's World Map", author: 'xaero', downloads: 38000000, description: 'Большая карта мира, открывается на M.', icon_url: '', categories: ['utility'] },
  { project_id: 'pZ2wrerK', slug: 'emotecraft', title: 'Emotecraft', author: 'KosmX', downloads: 9000000, description: 'Эмоции, танцы и свои анимации.', icon_url: '', categories: ['social'] },
  { project_id: 'fadeless', slug: 'fadeless', title: 'Fadeless', author: 'imb11', downloads: 1200000, description: 'Убирает затемнение при смене ресурспака.', icon_url: '', categories: ['utility'] },
  { project_id: 'litematica', slug: 'litematica', title: 'Litematica', author: 'maruohon', downloads: 15000000, description: 'Схемы построек и голографический принтер.', icon_url: '', categories: ['utility'] }
];

function ensureSeed() {
  if (!load('inited', false)) {
    save('settings', defaultSettings());
    save('user', null);
    save('instances', []);
    save('mods', {});
    save('inbox', []);
    save('notes', {});
    save('inited', true);
  }
}

export function installMockApi() {
  if (window.cryndel) return false;
  ensureSeed();
  let running = false;
  let launching = false;

  window.__CRYNDEL_PREVIEW = true;
  window.cryndel = {
    auth: {
      createOffline: async (nick, extra) => {
        const user = {
          id: 'u-preview',
          nick,
          offlineUuid: '00000000-0000-3000-8000-000000000001',
          onboardingCompleted: true,
          surveyAnswer: extra && extra.surveyAnswer,
          stats: { playtime: 0, launches: 0, lastPlayedAt: null, totalSessions: 0, longestSession: 0 },
          skin: { type: 'default', model: 'classic' },
          preferences: { selectedInstanceId: null }
        };
        save('user', user);
        return { ok: true, user };
      },
      getCurrent: async () => load('user', null),
      logout: async () => { save('user', null); return { ok: true }; },
      rename: async (nick) => {
        const user = load('user', null);
        if (!user) throw new Error('Нет профиля');
        user.nick = nick;
        save('user', user);
        return user;
      },
      patchCurrent: async (patch) => {
        const user = load('user', null);
        if (!user) return null;
        Object.assign(user, patch || {});
        save('user', user);
        return user;
      }
    },
    instances: {
      list: async () => load('instances', []),
      get: async (id) => load('instances', []).find((i) => i.id === id) || null,
      create: async (dto) => {
        const list = load('instances', []);
        const inst = {
          id: 'i-' + Math.random().toString(16).slice(2, 10),
          name: (dto && dto.name) || 'Новая сборка',
          mcVersion: (dto && dto.mcVersion) || '1.21.11',
          modLoader: (dto && dto.modLoader) || 'fabric',
          memoryMb: (dto && dto.memoryMb) || 4096,
          memoryMode: (dto && dto.memoryMode) || 'auto',
          group: (dto && dto.group) || 'Мои',
          lastPlayedAt: null,
          createdAt: new Date().toISOString(),
          quickPlay: dto && dto.quickPlay ? dto.quickPlay : { enabled: true, server: 'cryndel.ru', port: 25565 },
          extras: (dto && dto.extras) || {},
          addServer: dto && dto.addServer !== false
        };
        list.push(inst);
        save('instances', list);
        const user = load('user', null);
        if (user) {
          user.preferences = user.preferences || {};
          user.preferences.selectedInstanceId = inst.id;
          save('user', user);
        }
        return inst;
      },
      createFromBuild: async (buildId, name) => window.cryndel.instances.create({ name: name || buildId, group: 'Cryndel' }),
      delete: async (id) => {
        save('instances', load('instances', []).filter((i) => i.id !== id));
        const mods = load('mods', {});
        delete mods[id];
        save('mods', mods);
        return { ok: true };
      },
      update: async (id, patch) => {
        const list = load('instances', []);
        const i = list.find((x) => x.id === id);
        if (!i) throw new Error('Сборка не найдена');
        Object.assign(i, patch);
        save('instances', list);
        return i;
      },
      openFolder: async () => ({ ok: true }),
      exportMrpack: async () => ({ ok: true }),
      importMrpack: async () => ({ ok: true, needsMeta: false }),
      catalog: async () => ({
        builds: [
          { id: 'cryndel-default', name: 'Cryndel Default', description: 'Официальная сборка cryndel.ru', mcVersion: '1.21.11', modLoader: 'fabric' },
          { id: 'cryndel-lite', name: 'Cryndel Lite', description: 'Лёгкая сборка для слабых ПК', mcVersion: '1.21.11', modLoader: 'fabric' }
        ]
      }),
      select: async (id) => {
        const user = load('user', null);
        if (user) {
          user.preferences = user.preferences || {};
          user.preferences.selectedInstanceId = id;
          save('user', user);
        }
        return { ok: true };
      },
      patchSodium: async () => ({ ok: true })
    },
    versions: {
      manifest: async () => ({
        latest: { release: '1.21.11', snapshot: '25w04a' },
        versions: [
          { id: '1.21.11', type: 'release' },
          { id: '1.21.10', type: 'release' },
          { id: '1.21.8', type: 'release' },
          { id: '1.21.4', type: 'release' },
          { id: '1.21.1', type: 'release' },
          { id: '1.20.6', type: 'release' },
          { id: '1.20.1', type: 'release' },
          { id: '25w04a', type: 'snapshot' }
        ]
      }),
      ensure: async () => ({ ok: true })
    },
    modrinth: {
      search: async (params) => {
        await wait(180);
        const q = String((params && params.query) || '').toLowerCase();
        let hits = SAMPLE_MODS.filter((m) => !q || m.title.toLowerCase().includes(q) || m.slug.includes(q));
        if (params && params.type && params.type !== 'mod') hits = hits.slice(0, 3);
        return { hits, total_hits: hits.length };
      },
      getProject: async (id) => {
        const hit = SAMPLE_MODS.find((m) => m.slug === id || m.project_id === id) || SAMPLE_MODS[0];
        return { ...hit, followers: 120000, body: '## ' + hit.title + '\n\n' + hit.description + '\n\n- Fabric 1.21+\n- Нужен Fabric API', gallery: [] };
      },
      getVersions: async () => ([{ id: 'v1', version_number: '1.0.0', name: '1.0.0', game_versions: ['1.21.11'], files: [{ url: 'https://example.com/mod.jar', filename: 'mod.jar', primary: true }] }]),
      getVersion: async () => ({}),
      tags: async () => ({ loaders: [], gameVersions: [] }),
      install: async (instanceId, projectId) => {
        const mods = load('mods', {});
        const list = mods[instanceId] || [];
        const hit = SAMPLE_MODS.find((m) => m.slug === projectId || m.project_id === projectId);
        const dependencies = hit && hit.slug === 'iris'
          ? [SAMPLE_MODS.find((m) => m.slug === 'sodium'), hit]
          : [hit];
        const installed = [];
        for (const mod of dependencies) {
          const id = mod ? mod.slug : (projectId || ('mod-' + list.length));
          if (!list.find((m) => m.id === id)) {
            list.push({
              id,
              name: mod ? mod.title : projectId,
              versionNumber: '1.0.0',
              filename: id + '.jar',
              loader: 'fabric',
              source: 'modrinth',
              enabled: true,
              pinned: false
            });
            installed.push(id);
          }
        }
        mods[instanceId] = list;
        save('mods', mods);
        emit('game:progress', { stage: 'download', pct: 100, message: 'Установлено: ' + installed.join(', ') });
        return { installed };
      },
      installVersion: async (instanceId, versionId) => window.cryndel.modrinth.install(instanceId, versionId)
    },
    mods: {
      listInstalled: async (instanceId) => (load('mods', {})[instanceId] || []),
      toggle: async (instanceId, modId, enabled) => {
        const mods = load('mods', {});
        const list = mods[instanceId] || [];
        const m = list.find((x) => x.id === modId);
        if (m) m.enabled = enabled;
        save('mods', mods);
        return { ok: true };
      },
      remove: async (instanceId, modId) => {
        const mods = load('mods', {});
        mods[instanceId] = (mods[instanceId] || []).filter((m) => m.id !== modId);
        save('mods', mods);
        return { ok: true };
      },
      pin: async (instanceId, modId, pinned) => {
        const mods = load('mods', {});
        const m = (mods[instanceId] || []).find((x) => x.id === modId);
        if (m) m.pinned = pinned;
        save('mods', mods);
        return { ok: true };
      },
      addFromFile: async () => ({ ok: false, cancelled: true }),
      installBuiltin: async (instanceId, id) => window.cryndel.modrinth.install(instanceId, id),
      checkUpdates: async () => [],
      applyUpdates: async () => ({ ok: true }),
      detectConflicts: async () => [],
      verifyIntegrity: async () => [],
      scan: async () => [],
      hasMod: async () => false
    },
    lockfile: {
      load: async () => ({ version: 1, loader: 'fabric', mcVersion: '1.21.11', entries: [] }),
      export: async () => ({ ok: true })
    },
    backup: {
      create: async () => ({ ok: true, id: 'b1' }),
      list: async () => [],
      restore: async () => ({ ok: true }),
      delete: async () => ({ ok: true })
    },
    game: {
      launch: async () => {
        launching = true;
        running = true;
        const steps = [
          { stage: 'java', pct: 12, message: 'Проверяю Java 21…' },
          { stage: 'client', pct: 38, message: 'Качаю клиент 1.21.11…' },
          { stage: 'libraries', pct: 62, message: 'Библиотеки Fabric…' },
          { stage: 'assets', pct: 84, message: 'Ресурсы игры…' },
          { stage: 'start', pct: 100, message: 'Запускаю Minecraft' }
        ];
        for (const s of steps) {
          emit('game:progress', s);
          await wait(280);
        }
        launching = false;
        return { ok: true, pid: 4242 };
      },
      kill: async () => {
        running = false;
        launching = false;
        emit('game:close', { instanceId: 'preview' });
        return { ok: true };
      },
      isRunning: async () => running || launching,
      anyRunning: async () => running || launching,
      cancel: async () => {
        running = false;
        launching = false;
        emit('game:progress', { stage: 'cancel', pct: 0, message: 'Отменено' });
        return { ok: true };
      },
      onLog: (cb) => on('game:log', cb),
      onProgress: (cb) => on('game:progress', cb),
      onClose: (cb) => on('game:close', cb),
      onCrash: (cb) => on('game:crash', cb)
    },
    screenshots: {
      list: async () => [],
      open: async () => ({ ok: true }),
      openFolder: async () => ({ ok: true }),
      dataUrl: async () => null,
      copy: async () => ({ ok: true }),
      onNew: (cb) => on('screenshots:new', cb)
    },
    liveNick: {
      status: async () => ({ running: true, clients: 0, port: 21999 }),
      start: async () => ({ ok: true }),
      change: async (nick) => window.cryndel.auth.rename(nick),
      onStatusChange: (cb) => on('liveNick:statusChange', cb)
    },
    ram: {
      suggest: async () => ({ totalMb: 16384, freeMb: 8192, recommendedMb: 4096 })
    },
    server: {
      ping: async () => {
        await wait(240);
        return { online: true, ms: 42, host: 'cryndel.ru', port: 25565 };
      },
      query: async () => {
        await wait(240);
        return {
          online: true,
          maintenance: false,
          ms: 42,
          host: 'cryndel.ru',
          port: 25565,
          version: 'Paper 1.21.11',
          motd: 'Cryndel',
          players: { online: 128, max: 500 }
        };
      }
    },
    skins: {
      list: async () => [],
      importFile: async () => ({ ok: false, cancelled: true }),
      fromNick: async () => ({ ok: true, path: '' }),
      preview: async () => null,
      apply: async () => ({ ok: true }),
      importCape: async () => ({ ok: false, cancelled: true }),
      clearCape: async () => ({ ok: true }),
      capePreview: async () => null
    },
    theme: {
      read: async () => '',
      write: async () => ({ ok: true }),
      import: async () => ({ ok: false }),
      clear: async () => ({ ok: true }),
      pickBackground: async () => ({ ok: false, cancelled: true }),
      pickSplash: async () => ({ ok: false, cancelled: true }),
      pickFurryImage: async () => ({ ok: false, cancelled: true }),
      pickFurrySounds: async () => ({ ok: false, cancelled: true })
    },
    media: {
      logoUrl: async () => '',
      splashUrl: async () => '',
      bgVideoUrl: async () => '',
      bgImageUrl: async () => '',
      playFurry: async () => ({ ok: false })
    },
    // Browser-only preview (the mock API is used when the page is opened outside
    // Electron): sounds resolve to nothing, so the renderer falls back to its
    // WebAudio blips and the UI still has feedback.
    sounds: {
      payload: async () => ({ sounds: {}, music: [] }),
      list: async () => [],
      pick: async () => ({ ok: false, cancelled: true }),
      clear: async () => ({ ok: true, url: '' }),
      reset: async () => ({ sounds: {}, music: [] }),
      music: async () => [],
      regenerate: async () => ({ sounds: {}, music: [] })
    },
    catalog: {
      extraMods: async () => ({ mods: [{ id: 'cryem', name: 'Cryem' }] }),
      comfortPacks: async () => ({
        packs: [
          { id: 'bska-heavy', name: 'От BSKA', tag: 'Тяжёлый x56 модов' },
          { id: 'arkin-opt', name: 'Аркина оптимизированный', tag: 'Максимальная оптимизация' },
          { id: 'arkin-full', name: 'Аркин Полноценный', tag: 'Тяжёлая сборка' }
        ]
      }),
      recommended: async () => ({
        byLoader: {
          fabric: [
            { slug: 'iris', title: 'Iris + Sodium', reason: 'шейдеры и быстрый рендер' },
            { slug: 'lithium', title: 'Lithium', reason: 'логика' },
            { slug: 'ferrite-core', title: 'FerriteCore', reason: 'память' }
          ],
          quilt: [
            { slug: 'iris', title: 'Iris + Sodium', reason: 'шейдеры и быстрый рендер' },
            { slug: 'lithium', title: 'Lithium', reason: 'логика' },
            { slug: 'ferrite-core', title: 'FerriteCore', reason: 'память' }
          ],
          forge: [
            { slug: 'embeddium', title: 'Embeddium', reason: 'быстрый рендер' },
            { slug: 'oculus', title: 'Oculus', reason: 'шейдеры' },
            { slug: 'ferrite-core', title: 'FerriteCore', reason: 'экономия памяти' }
          ],
          neoforge: [
            { slug: 'embeddium', title: 'Embeddium', reason: 'быстрый рендер' },
            { slug: 'oculus', title: 'Oculus', reason: 'шейдеры' },
            { slug: 'ferrite-core', title: 'FerriteCore', reason: 'экономия памяти' }
          ]
        },
        common: [
          { slug: 'simple-voice-chat', title: 'Simple Voice Chat', reason: 'голосовой чат рядом с игроками', loaders: ['fabric', 'forge', 'neoforge', 'quilt'] },
          { slug: 'appleskin', title: 'AppleSkin', reason: 'показывает насыщение и голод', loaders: ['fabric', 'forge', 'neoforge', 'quilt'] },
          { slug: 'xaeros-minimap', title: "Xaero's Minimap", reason: 'миникарта и метки', loaders: ['fabric', 'forge', 'neoforge', 'quilt'] },
          { slug: 'xaeros-world-map', title: "Xaero's World Map", reason: 'карта исследованного мира', loaders: ['fabric', 'forge', 'neoforge', 'quilt'] },
          { slug: 'emotecraft', title: 'Emotecraft', reason: 'эмоции и анимации', loaders: ['fabric', 'forge', 'quilt'] },
          { slug: 'modmenu', title: 'Mod Menu', reason: 'список модов в игре', loaders: ['fabric', 'quilt'] }
        ]
      })
    },
    onboard: {
      comfort: async (nick) => {
        await window.cryndel.auth.createOffline(nick, { surveyAnswer: 'cryndel' });
        const inst = await window.cryndel.instances.create({
          name: 'Cryndel Fabric 1.21.11',
          mcVersion: '1.21.11',
          modLoader: 'fabric',
          group: 'Cryndel',
          quickPlay: { enabled: true, server: 'cryndel.ru', port: 25565 }
        });
        await window.cryndel.modrinth.install(inst.id, 'sodium');
        await window.cryndel.modrinth.install(inst.id, 'fabric-api');
        emit('game:progress', { stage: 'done', pct: 100, message: 'Готово' });
        return { ok: true, instance: inst };
      }
    },
    notes: {
      load: async (id) => (load('notes', {})[id] || ''),
      save: async (id, text) => {
        const n = load('notes', {});
        n[id] = text;
        save('notes', n);
        return { ok: true };
      }
    },
    settings: {
      get: async (key) => {
        const all = load('settings', defaultSettings());
        if (!key) return all;
        return key.split('.').reduce((a, k) => (a == null ? a : a[k]), all);
      },
      set: async (key, v) => {
        const all = load('settings', defaultSettings());
        plant(all, key, v);
        save('settings', all);
        if (typeof window !== 'undefined' && window.__cryndelMockSettingsChanged) {
          window.__cryndelMockSettingsChanged({ key, value: v });
        }
        return { ok: true };
      },
      getAll: async () => load('settings', defaultSettings()),
      reset: async () => {
        const fresh = save('settings', defaultSettings());
        if (typeof window !== 'undefined' && window.__cryndelMockSettingsChanged) {
          window.__cryndelMockSettingsChanged({ key: null, value: null });
        }
        return fresh;
      },
      onChanged: (cb) => {
        if (typeof window !== 'undefined') window.__cryndelMockSettingsChanged = cb;
        return () => { if (typeof window !== 'undefined') window.__cryndelMockSettingsChanged = null; };
      }
    },
    system: {
      openExternal: async (url) => { window.open(url, '_blank'); return { ok: true }; },
      selectDirectory: async () => null,
      openPath: async () => ({ ok: false, error: 'Только в приложении' }),
      detectJava: async () => [{ path: '/usr/bin/java', version: '21.0.4', source: 'path' }],
      copyToClipboard: async (text) => { try { await navigator.clipboard.writeText(String(text || '')); } catch (_) { /* */ } return { ok: true }; },
      getStorageInfo: async () => ({ assets: { human: '0 B' }, libraries: { human: '0 B' }, cache: { human: '0 B' }, instances: [] }),
      clearCache: async () => ({ ok: true }),
      gpus: async () => [{ id: 'auto', name: 'Авто' }, { id: 'gpu-0', name: 'Превью GPU' }]
    },
    discord: {
      toggle: async () => ({ ok: true }),
      status: async () => ({ ready: false, error: '' }),
      configure: async () => ({ ok: true })
    },
    health: {
      getStatus: async (instanceId) => {
        const mods = (load('mods', {})[instanceId] || []);
        return {
          diskUsage: '128 MB',
          lastLaunch: null,
          backupStatus: 'none',
          modCount: mods.length,
          enabledMods: mods.filter((m) => m.enabled).length,
          conflicts: 0
        };
      },
      analyzeCrash: async () => ({ findings: [], suggestion: 'Крашей нет — сборка чистая.', ru: 'Крашей нет — сборка чистая.', logs: [] }),
      fixInstance: async () => ({ ok: true }),
      autoFix: async () => ({ ok: true, message: 'Всё в порядке' }),
      getTimeline: async () => [{ at: new Date().toISOString(), text: 'Сборка создана' }]
    },
    inbox: {
      list: async () => load('inbox', []),
      dir: async () => '/preview/inbox',
      openDir: async () => ({ ok: true }),
      downloadUrl: async (url, filename) => ({ path: '/preview/' + filename, name: filename }),
      importToInstance: async () => ({ ok: true }),
      importMrpackPath: async () => {
        const inst = await window.cryndel.instances.create({ name: 'Импорт', group: 'Импорт' });
        return { ok: true, instance: inst };
      },
      importAsResourcepack: async () => ({ ok: true }),
      onProgress: (cb) => on('inbox:progress', cb),
      onSaved: (cb) => on('inbox:saved', cb)
    },
    java: { ensure: async () => ({ ok: true, path: '/usr/bin/java' }) },
    app: { getVersion: async () => '1.0.0' },
    greeting: {
      pick: async (nick) => ({ ok: true, text: `Привет, ${nick || 'игрок'}!` }),
      read: async () => ({ ok: true, greetings: { default: ['Привет, {nick}!'] } }),
      write: async (g) => ({ ok: true, greetings: g }),
      openFile: async () => ({ ok: true })
    },
    plugins: {
      list: async () => [],
      ui: async () => ({ pages: [], themes: [] }),
      modsCatalog: async () => [],
      call: async () => ({ ok: false }),
      managePermissions: async () => ({ ok: false, cancelled: true }),
      apiPackStatus: async () => ({ installed: false, version: 'Встроенная', previousVersion: '', resetUsed: false, error: '' }),
      apiPackInstall: async () => ({ ok: false, cancelled: true }),
      apiPackRollback: async () => ({ ok: false, cancelled: true }),
      apiPackReset: async () => ({ ok: false, cancelled: true }),
      onUiChanged: () => () => {},
      onModal: () => () => {},
      onToast: () => () => {},
      reload: async () => ({ loaded: 0, results: [], warnings: [] }),
      warnings: async () => [],
      dir: async () => '',
      openDir: async () => ({ ok: true }),
      install: async () => ({ ok: false, cancelled: true }),
      installExample: async () => ({ ok: false, cancelled: true }),
      installPath: async () => ({ ok: false }),
      remove: async () => ({ ok: true }),
      emit: async () => [],
      toggle: async () => ({ ok: true, active: false }),
      configGet: async () => ({}),
      configSet: async () => ({}),
      schema: async () => [],
      nav: async () => []
    },
    publish: {
      build: async () => ({ ok: false, cancelled: true }),
      inspect: async () => ({ ok: false }),
      pick: async () => ({ ok: false, cancelled: true }),
      import: async () => ({ ok: false })
    },
    browser: { onOpen: (cb) => on('browser:open', cb) },
    window: {
      minimize: async () => ({ ok: true }),
      maximize: async () => ({ ok: true, maximized: true, fullScreen: false }),
      fullscreen: async () => ({ ok: true, maximized: false, fullScreen: true }),
      close: async () => ({ ok: true }),
      show: async () => ({ ok: true, maximized: false, fullScreen: false, visible: true }),
      state: async () => ({ maximized: false, fullScreen: false }),
      setZoom: async (f) => ({ ok: true, zoom: Number(f) || 1 }),
      setSize: async (width, height) => ({ ok: true, width, height }),
      onState: (cb) => on('window:state', cb)
    }
  };
  return true;
}
