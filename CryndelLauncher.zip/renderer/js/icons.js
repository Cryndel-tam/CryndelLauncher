export const I = {
  x: '<path d="M7 7l10 10M17 7 7 17" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  folder: '<path d="M4 8h6l2 2h8v9H4z" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M4 8V6h5l1.5 2" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  dl: '<path d="M12 5v10M8 11l4 4 4-4M5 19h14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  gear: '<path d="M12 8.1a3.9 3.9 0 1 0 0 7.8 3.9 3.9 0 0 0 0-7.8Zm8.1 4.9a8.2 8.2 0 0 0 0-2l-2-.7a6.4 6.4 0 0 0-.7-1.6l.9-1.9a8.8 8.8 0 0 0-1.4-1.4l-1.9.9a6.4 6.4 0 0 0-1.6-.7l-.7-2a8.2 8.2 0 0 0-2 0l-.7 2a6.4 6.4 0 0 0-1.6.7l-1.9-.9a8.8 8.8 0 0 0-1.4 1.4l.9 1.9a6.4 6.4 0 0 0-.7 1.6l-2 .7a8.2 8.2 0 0 0 0 2l2 .7a6.4 6.4 0 0 0 .7 1.6l-.9 1.9a8.8 8.8 0 0 0 1.4 1.4l1.9-.9a6.4 6.4 0 0 0 1.6.7l.7 2a8.2 8.2 0 0 0 2 0l.7-2a6.4 6.4 0 0 0 1.6-.7l1.9.9a8.8 8.8 0 0 0 1.4-1.4l-.9-1.9a6.4 6.4 0 0 0 .7-1.6l2-.7Z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>',
  pal: '<path d="M12 4a8 8 0 1 0 0 16 3 3 0 0 0 0-6 3 3 0 0 1 0-6 8 8 0 0 0 0-4z" fill="none" stroke="currentColor" stroke-width="1.7"/><circle cx="8.5" cy="10" r="1" fill="currentColor"/><circle cx="10" cy="7.2" r="1" fill="currentColor"/><circle cx="14.5" cy="7.5" r="1" fill="currentColor"/>',
  plus: '<path d="M12 5v14M5 12h14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  play: '<path d="M8 6.5v11l9-5.5z" fill="currentColor"/>',
  copy: '<rect x="8" y="8" width="10" height="10" rx="2" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M6 16V6h10" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  open: '<path d="M14 5h5v5M19 5l-8 8M10 5H6v14h14v-4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  inst: '<rect x="4" y="5" width="7" height="7" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.7"/><rect x="13" y="5" width="7" height="7" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.7"/><rect x="4" y="14" width="7" height="6" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  home: '<path d="M4 11.5 12 4l8 7.5V20H4z" fill="none" stroke="currentColor" stroke-width="1.8"/>',
  mods: '<path d="M4 5.5h6.2v2a1.8 1.8 0 1 0 3.6 0v-2H20v6h-2a1.8 1.8 0 1 0 0 3.6h2v3.4h-6v-2a1.8 1.8 0 1 0-3.6 0v2H4v-6h2a1.8 1.8 0 1 0 0-3.6H4z" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linejoin="round"/>',
  puzzle: '<path d="M10 4h4v2a2 2 0 1 0 4 0V4h2v6h-2a2 2 0 1 0 0 4h2v6h-6v-2a2 2 0 1 0-4 0v2H4v-6h2a2 2 0 1 0 0-4H4V4h6Z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/>',
  sliders: '<path d="M4 7h9m4 0h3M4 17h3m4 0h9" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><circle cx="15" cy="7" r="2" fill="var(--panel-2)" stroke="currentColor" stroke-width="1.8"/><circle cx="9" cy="17" r="2" fill="var(--panel-2)" stroke="currentColor" stroke-width="1.8"/>',
  grid: '<rect x="4" y="4" width="6" height="6" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.7"/><rect x="14" y="4" width="6" height="6" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.7"/><rect x="4" y="14" width="6" height="6" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.7"/><rect x="14" y="14" width="6" height="6" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  search: '<circle cx="10.8" cy="10.8" r="6.3" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="m15.5 15.5 4.2 4.2" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  scan: '<path d="M12 3.5 5 6.5V12c0 4.6 2.9 7.6 7 8.5 4.1-.9 7-3.9 7-8.5V6.5z" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M8.5 12.2l2.4 2.4 4.6-5" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  mr: '<path d="M4 19V5h4l4 5 4-5h4v14h-4v-8l-4 5-4-5v8z" fill="currentColor"/>',
  shots: '<rect x="4" y="7" width="16" height="12" rx="2" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="9" cy="12" r="1.6" fill="currentColor"/>',
  net: '<circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M4 12h16M12 4c3 3 3 13 0 16M12 4c-3 3-3 13 0 16" fill="none" stroke="currentColor" stroke-width="1.5"/>',
  cab: '<path d="M12 4 5 8v8l7 4 7-4V8z" fill="none" stroke="currentColor" stroke-width="1.8"/>',
  ver: '<path d="M6 7h12M6 12h12M6 17h8" fill="none" stroke="currentColor" stroke-width="1.8"/>',
  hp: '<path d="M4 12h4l2-4 4 8 2-4h4" fill="none" stroke="currentColor" stroke-width="1.8"/>',
  chev: '<path d="M8 10l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  tab: '<rect x="4" y="6" width="16" height="12" rx="2" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M4 10h16" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  google: '<circle cx="12" cy="12" r="7.5" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M12 8.5v7M9 12h7.5" fill="none" stroke="currentColor" stroke-width="1.6"/>',
  install: '<path d="M12 4v10M8 10l4 4 4-4M6 18h12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  page: '<rect x="6" y="4" width="12" height="16" rx="2" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M9 8h6M9 12h6M9 16h4" fill="none" stroke="currentColor" stroke-width="1.5"/>',
  full: '<path d="M9 5H5v4M15 5h4v4M5 15v4h4M19 15v4h-4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  nick: '<circle cx="12" cy="9" r="3" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M6 19c1.4-3 3.4-4.5 6-4.5S16.6 16 18 19" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3m-9 0 1 13h10l1-13M10 11v5m4-5v5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>',
  plug: '<path d="M8 8V5M16 8V5M7 8h10v4.2A5 5 0 0 1 12 17a5 5 0 0 1-5-4.8zM12 17v3" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>',
  edit: '<path d="M5 16.5V19h2.5L18 8.5 15.5 6 5 16.5z" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  check: '<path d="M6 12.5l4 4 8-9" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/>',
  pin: '<path d="M12 4v10M9 7h6M10 14l-2 6 4-3 4 3-2-6" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  pause: '<path d="M9 6v12M15 6v12" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>',
  prev: '<path d="M18 6v12L9 12zM6 6v12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round"/>',
  next: '<path d="M6 6v12l9-6zM18 6v12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round"/>',
  music: '<path d="M9 17V6l9-2v11" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><ellipse cx="7" cy="17.5" rx="2.2" ry="1.9" fill="none" stroke="currentColor" stroke-width="1.6"/><ellipse cx="16" cy="15.5" rx="2.2" ry="1.9" fill="none" stroke="currentColor" stroke-width="1.6"/>',
  refresh: '<path d="M5 12a7 7 0 0 1 12-4.5M19 12a7 7 0 0 1-12 4.5M17 4v4h-4M7 20v-4h4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  file: '<path d="M7 4h7l4 4v12H7z" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M14 4v4h4" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  export: '<path d="M12 14V5M8 9l4-4 4 4M5 19h14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  shield: '<path d="M12 4 5 7v5c0 5 3.2 8 7 9 3.8-1 7-4 7-9V7z" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  on: '<circle cx="12" cy="12" r="7" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M12 8v8" fill="none" stroke="currentColor" stroke-width="1.8"/>',
  off: '<circle cx="12" cy="12" r="7" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M9 9l6 6M15 9l-6 6" fill="none" stroke="currentColor" stroke-width="1.7"/>'
};

const ICON_OVERRIDES = new Set(['gear', 'trash', 'mr', 'mods', 'plug']);
let overrides = {};

const SVG_TAGS = new Set(['path', 'circle', 'rect', 'line', 'polyline', 'polygon', 'ellipse']);
const SVG_ATTRIBUTES = new Set([
  'd', 'cx', 'cy', 'r', 'rx', 'ry', 'x', 'y', 'x1', 'y1', 'x2', 'y2',
  'width', 'height', 'points', 'fill', 'stroke', 'stroke-width',
  'stroke-linecap', 'stroke-linejoin', 'fill-rule', 'opacity'
]);

function customIcon(name) {
  return ICON_OVERRIDES.has(name) && overrides[name] && typeof overrides[name] === 'object'
    ? overrides[name]
    : null;
}

export function sanitizeIconSvg(source) {
  const text = String(source || '');
  if (!text.trim() || text.length > 24 * 1024 || typeof DOMParser === 'undefined') {
    throw new Error('SVG-файл пустой, слишком большой или не поддерживается');
  }
  const parsed = new DOMParser().parseFromString(text, 'image/svg+xml');
  const root = parsed.documentElement;
  if (!root || root.localName !== 'svg' || parsed.querySelector('parsererror')) {
    throw new Error('Некорректный SVG-файл');
  }
  const viewBox = (root.getAttribute('viewBox') || '0 0 24 24').trim();
  const values = viewBox.split(/[\s,]+/).map(Number);
  if (values.length !== 4 || values.some((value) => !Number.isFinite(value))
    || values[2] <= 0 || values[3] <= 0 || values[2] > 1000 || values[3] > 1000) {
    throw new Error('SVG должен иметь корректный viewBox');
  }
  let elementCount = 0;
  const cleanNode = (node) => {
    elementCount += 1;
    if (elementCount > 256) throw new Error('SVG содержит слишком много элементов');
    if (node.nodeType !== 1 || !SVG_TAGS.has(node.localName)) {
      throw new Error('SVG может содержать только безопасные геометрические элементы');
    }
    let markup = `<${node.localName}`;
    for (const attr of [...node.attributes]) {
      const name = attr.name.toLowerCase();
      const value = attr.value.trim();
      if (!SVG_ATTRIBUTES.has(name)) throw new Error(`Недопустимый атрибут SVG: ${name}`);
      if ((name === 'fill' || name === 'stroke')
        && !/^(none|currentcolor|#(?:[\da-f]{3}|[\da-f]{4}|[\da-f]{6}|[\da-f]{8})|[a-z]+)$/i.test(value)) {
        throw new Error('В SVG разрешены только однотонные цвета');
      }
      if (['stroke-linecap', 'stroke-linejoin', 'fill-rule'].includes(name)
        && !/^(butt|round|square|miter|bevel|arcs|nonzero|evenodd)$/i.test(value)) {
        throw new Error(`Недопустимое значение SVG: ${name}`);
      }
      if (name === 'opacity' && (!/^(?:0(?:\.\d+)?|1(?:\.0+)?)$/.test(value))) {
        throw new Error('Недопустимое значение SVG: opacity');
      }
      if (name !== 'd' && name !== 'points' && name !== 'fill' && name !== 'stroke'
        && !['stroke-linecap', 'stroke-linejoin', 'fill-rule'].includes(name)
        && name !== 'opacity' && !/^[\d.,+\-\s]+$/.test(value)) {
        throw new Error(`Недопустимое значение SVG: ${name}`);
      }
      if ((name === 'd' || name === 'points') && !/^[\da-z.,+\-\s]+$/i.test(value)) {
        throw new Error(`Недопустимая геометрия SVG: ${name}`);
      }
      markup += ` ${name}="${value.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;')}"`;
    }
    if (!node.childElementCount) return `${markup}/>`;
    markup += '>';
    for (const child of node.children) markup += cleanNode(child);
    return `${markup}</${node.localName}>`;
  };
  let body = '';
  for (const child of root.children) body += cleanNode(child);
  if (!body) throw new Error('SVG не содержит рисунка');
  return { viewBox, body };
}

export function setIconOverrides(next = {}) {
  overrides = {};
  if (next && typeof next === 'object' && !Array.isArray(next)) {
    for (const name of ICON_OVERRIDES) {
      const value = next[name];
      if (typeof value === 'string' && I[value]) overrides[name] = value;
      else if (value && typeof value === 'object') {
        try {
          overrides[name] = sanitizeIconSvg(`<svg viewBox="${String(value.viewBox || '0 0 24 24')}">${String(value.body || '')}</svg>`);
        } catch (err) {
          console.warn(`Saved custom ${name} icon was rejected`, err);
        }
      }
    }
  }
  document.querySelectorAll('svg.app-icon[data-icon]').forEach((node) => {
    const name = node.getAttribute('data-icon');
    node.innerHTML = iconContent(name);
    const custom = customIcon(name);
    node.setAttribute('viewBox', custom ? custom.viewBox : '0 0 24 24');
  });
}

function iconContent(name) {
  if (ICON_OVERRIDES.has(name)) {
    const custom = overrides[name];
    if (typeof custom === 'string' && I[custom]) return I[custom];
    const safe = customIcon(name);
    if (safe) return safe.body;
  }
  return I[name] || '';
}

export function svg(name, cls = '') {
  const d = iconContent(name);
  const custom = customIcon(name);
  const viewBox = custom ? custom.viewBox : '0 0 24 24';
  return `<svg class="app-icon icon-${name}${cls ? ' ' + cls : ''}" data-icon="${name}" viewBox="${viewBox}" aria-hidden="true">${d}</svg>`;
}
