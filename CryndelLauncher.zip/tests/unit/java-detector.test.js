const EmberFinder = require('../../electron/managers/java-detector');

describe('EmberFinder.majorFromInstance', () => {
  const j = new EmberFinder();
  test('1.21 needs 21', () => {
    expect(j.majorFromInstance({ mcVersion: '1.21.4' })).toBe(21);
  });
  test('1.20 needs 17', () => {
    expect(j.majorFromInstance({ mcVersion: '1.20.1' })).toBe(17);
  });
  test('1.16 needs 8', () => {
    expect(j.majorFromInstance({ mcVersion: '1.16.5' })).toBe(8);
  });
});
