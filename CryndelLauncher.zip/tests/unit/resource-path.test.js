const fs = require('fs');
const path = require('path');
const resourcePath = require('../../electron/utils/resource-path');

describe('resourcePath', () => {
  test('prefers the external resources directory in a packaged app', () => {
    const file = path.join('app-resources', 'resources', 'builds-catalog.json');
    const result = resourcePath('builds-catalog.json', {
      resourcesPath: 'app-resources',
      app: { getAppPath: () => 'app.asar' },
      existsSync: (candidate) => candidate === file
    });

    expect(result).toBe(file);
  });

  test('finds catalog files from the source tree', () => {
    const expected = path.resolve(__dirname, '..', '..', 'resources', 'builds-catalog.json');
    const result = resourcePath('builds-catalog.json', {
      resourcesPath: '',
      existsSync: fs.existsSync
    });

    expect(result).toBe(expected);
  });
});
