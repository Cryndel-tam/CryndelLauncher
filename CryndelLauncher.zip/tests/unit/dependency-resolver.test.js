const WeavePlanner = require('../../electron/managers/dependency-resolver');

describe('WeavePlanner', () => {
  test('installs required deps and skips cycles', async () => {
    const versions = {
      A: {
        project_id: 'pA',
        version_number: '1',
        files: [{ primary: true, url: 'uA', filename: 'a.jar', hashes: { sha512: 'hA' }, size: 1 }],
        dependencies: [{ dependency_type: 'required', version_id: 'B' }, { dependency_type: 'optional', version_id: 'C' }]
      },
      B: {
        project_id: 'pB',
        version_number: '1',
        files: [{ primary: true, url: 'uB', filename: 'b.jar', hashes: { sha512: 'hB' }, size: 1 }],
        dependencies: [{ dependency_type: 'required', version_id: 'A' }]
      }
    };
    const placed = [];
    const modrinth = { getVersion: async (id) => versions[id] };
    const modManager = {
      downloadAndPlace: async (iid, url, filename) => { placed.push(filename); }
    };
    const planner = new WeavePlanner(modrinth, modManager);
    const res = await planner.resolveAndInstall('i1', 'A');
    const flat = planner.flatten(res);
    expect(flat.map((x) => x.filename).sort()).toEqual(['a.jar', 'b.jar']);
    expect(placed).toEqual(['a.jar', 'b.jar']);
  });
});
