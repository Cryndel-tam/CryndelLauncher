const http = require('http');
const fs = require('fs-extra');
const os = require('os');
const path = require('path');

const InboxBay = require('../../electron/managers/inbox-manager');

let server;
let baseUrl;
let tmpRoot;

beforeAll(async () => {
  tmpRoot = await fs.mkdtemp(path.join(os.tmpdir(), 'cryndel-inbox-'));
  process.env.CRYNDEL_HOME = tmpRoot;
  server = http.createServer((req, res) => {
    const body = Buffer.from('cryndel-payload-'.repeat(64));
    res.writeHead(200, { 'Content-Type': 'application/java-archive', 'Content-Length': String(body.length) });
    res.end(body);
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  baseUrl = 'http://127.0.0.1:' + server.address().port;
});

afterAll(async () => {
  if (server) await new Promise((r) => server.close(r));
  if (tmpRoot) await fs.remove(tmpRoot);
});

describe('InboxBay', () => {
  test('saves downloads into the launcher downloads dir, not the OS one', async () => {
    const inbox = new InboxBay();
    const dir = await inbox.ensure();
    expect(dir).toBe(path.join(tmpRoot, 'CL-Downloads'));

    const dest = await inbox.downloadUrl(baseUrl + '/cool-mod.jar', 'cool-mod.jar');
    expect(dest).toBe(path.join(tmpRoot, 'CL-Downloads', 'cool-mod.jar'));
    expect(await fs.pathExists(dest)).toBe(true);
    expect((await fs.stat(dest)).size).toBeGreaterThan(0);
  });

  test('reports progress while streaming', async () => {
    const inbox = new InboxBay();
    const seen = [];
    await inbox.downloadUrl(baseUrl + '/thing.zip', 'thing.zip', (p) => seen.push(p));
    expect(seen.length).toBeGreaterThan(0);
    const last = seen[seen.length - 1];
    expect(last.filename).toBe('thing.zip');
    expect(last.pct).toBe(100);
    expect(last.loaded).toBe(last.total);
  });

  test('classifies saved files by extension', async () => {
    const inbox = new InboxBay();
    await inbox.downloadUrl(baseUrl + '/pack.mrpack', 'pack.mrpack');
    const items = await inbox.list();
    const names = items.map((i) => i.name);
    expect(names).toContain('cool-mod.jar');
    expect(names).toContain('pack.mrpack');
    expect(items.find((i) => i.name === 'cool-mod.jar').kind).toBe('mod');
    expect(items.find((i) => i.name === 'pack.mrpack').kind).toBe('modpack');
  });

  test('sanitizes hostile filenames instead of escaping the dir', async () => {
    const inbox = new InboxBay();
    const dest = await inbox.saveBuffer('../../evil.jar', Buffer.from('x'));
    expect(path.dirname(dest)).toBe(path.join(tmpRoot, 'CL-Downloads'));
  });

  test('never overwrites an existing download: a second copy gets a suffix', async () => {
    const inbox = new InboxBay();
    const first = await inbox.downloadUrl(baseUrl + '/dup.jar', 'dup.jar');
    const second = await inbox.downloadUrl(baseUrl + '/dup.jar', 'dup.jar');
    expect(first).not.toBe(second);
    expect(path.basename(second)).toBe('dup (2).jar');
    expect(await fs.pathExists(first)).toBe(true);
    expect(await fs.pathExists(second)).toBe(true);
  });
});
