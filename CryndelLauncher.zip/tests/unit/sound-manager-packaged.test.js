const fs = require('fs-extra');
const os = require('os');
const path = require('path');

const mockApp = {
  isPackaged: true,
  getPath: jest.fn()
};

jest.mock('electron', () => ({ app: mockApp }), { virtual: true });

const SoundForge = require('../../electron/managers/sound-manager');
const CryndelPathVault = require('../../electron/utils/paths');

describe('packaged sound manager paths', () => {
  let tempRoot;
  let resourcesPathDescriptor;
  let manager;

  beforeAll(async () => {
    tempRoot = await fs.mkdtemp(path.join(os.tmpdir(), 'cryndel-sounds-'));
    mockApp.getPath.mockReturnValue(path.join(tempRoot, 'userData'));
    resourcesPathDescriptor = Object.getOwnPropertyDescriptor(process, 'resourcesPath');
    Object.defineProperty(process, 'resourcesPath', {
      configurable: true,
      value: path.join(tempRoot, 'resources')
    });
    manager = new SoundForge({ get: jest.fn().mockResolvedValue('') });

    await fs.ensureDir(manager.bundledMusicDir());
    await fs.ensureDir(manager.bundledRoot());
    await fs.writeFile(path.join(manager.bundledMusicDir(), 'track.mp3'), 'bundled track');
    await fs.writeFile(path.join(manager.bundledRoot(), 'interfeyse.wav'), 'bundled sound');
  });

  afterAll(async () => {
    await fs.remove(tempRoot);
    if (resourcesPathDescriptor) {
      Object.defineProperty(process, 'resourcesPath', resourcesPathDescriptor);
    } else {
      delete process.resourcesPath;
    }
  });

  test('writes generated files to user data and reads packaged media', async () => {
    await manager.ensure();
    const fallback = await manager.ensureDefault('klick');
    const music = await manager.listMusic();
    const sound = await manager.resolve('interfeyse');

    expect(manager.root()).toBe(path.join(CryndelPathVault.userRoot(), 'muzick'));
    expect(fallback).toBe(path.join(manager.root(), '_defaults', 'klick.wav'));
    expect(await fs.pathExists(fallback)).toBe(true);
    expect(music).toContain(path.join(manager.bundledMusicDir(), 'track.mp3'));
    expect(sound).toBe(path.join(manager.bundledRoot(), 'interfeyse.wav'));
    expect(await fs.pathExists(path.join(manager.bundledMusicDir(), 'klick.wav'))).toBe(false);
  });
});
