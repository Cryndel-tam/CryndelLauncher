const fs = require('fs-extra');
const path = require('path');
const os = require('os');
const EmberPilot = require('../../electron/managers/game-launcher');

function makeLauncher(settings) {
  const g = Object.create(EmberPilot.prototype);
  g.settings = {
    getAll: async () => settings,
    get: async (k) => settings[k.split('.')[0]] && settings[k.split('.')[0]][k.split('.')[1]]
  };
  return g;
}

async function run(settings, extra) {
  const g = makeLauncher(settings);
  const dir = path.join(os.tmpdir(), 'cryndel-opt-' + Math.random().toString(36).slice(2));
  await fs.ensureDir(dir);
  await g.writeGameOptions(dir, extra || {});
  const text = await fs.readFile(path.join(dir, 'options.txt'), 'utf8');
  await fs.remove(dir);
  return text;
}

const line = (text, key) => {
  const m = new RegExp(`^${key}:(.*)$`, 'm').exec(text);
  return m ? m[1] : undefined;
};

describe('writeGameOptions', () => {
  const base = { ui: { language: 'ru' }, game: {} };

  test('writes the Russian language code', async () => {
    const text = await run(base);
    expect(line(text, 'lang')).toBe('ru_ru');
  });

  test('an English launcher writes en_us', async () => {
    const text = await run({ ui: { language: 'en' }, game: {} });
    expect(line(text, 'lang')).toBe('en_us');
  });

  test('difficulty is a number, not a word', async () => {
    const text = await run({ ui: {}, game: { difficulty: 'hard' } });
    expect(line(text, 'difficulty')).toBe('3');
  });

  test('chatVisibility is a number', async () => {
    const text = await run({ ui: {}, game: { chatVisibility: 'hidden' } });
    expect(line(text, 'chatVisibility')).toBe('2');
  });

  test('particles is a number', async () => {
    const text = await run({ ui: {}, game: { particlesSetting: 'minimal' } });
    expect(line(text, 'particles')).toBe('2');
  });

  test('graphics writes the modern graphicsPreset key (quoted)', async () => {
    const text = await run({ ui: {}, game: { graphics: 'fancy' } });
    expect(line(text, 'graphicsPreset')).toBe('"fancy"');
  });

  test('graphics also writes the legacy numeric graphicsMode', async () => {
    const text = await run({ ui: {}, game: { graphics: 'fast' } });
    expect(line(text, 'graphicsMode')).toBe('0');
  });

  test('writes a full options.txt when the file is missing', async () => {
    const text = await run(base);
    expect(text).toMatch(/^version:/m);
    expect(line(text, 'forceUnicodeFont')).toBe('true');
    expect(line(text, 'lang')).toBe('ru_ru');
  });

  test('maps FOV 70 to the game 0.0 scale', async () => {
    const text = await run({ ui: {}, game: { fov: 70 } });
    expect(Number(line(text, 'fov'))).toBeCloseTo(0, 3);
  });

  test('maps volume 100 to 1.0', async () => {
    const text = await run({ ui: {}, game: { masterVolume: 100 } });
    expect(Number(line(text, 'soundCategory_master'))).toBeCloseTo(1, 2);
  });

  test('existing options are updated in place, not duplicated', async () => {
    const g = makeLauncher({ ui: { language: 'ru' }, game: {} });
    const dir = path.join(os.tmpdir(), 'cryndel-opt-dup');
    await fs.ensureDir(dir);
    await fs.writeFile(path.join(dir, 'options.txt'), 'version:4671\nlang:en_us\nlang:en_us\n');
    await g.writeGameOptions(dir, {});
    const text = await fs.readFile(path.join(dir, 'options.txt'), 'utf8');
    const hits = (text.match(/^lang:/gm) || []).length;
    expect(hits).toBe(2); // both existing lines replaced, none appended
    expect(line(text, 'lang')).toBe('ru_ru');
    await fs.remove(dir);
  });

  test('creates servers.dat with the Cryndel server', async () => {
    const g = makeLauncher({ ui: {}, game: {} });
    const dir = path.join(os.tmpdir(), 'cryndel-srv');
    await fs.ensureDir(dir);
    await g.writeGameOptions(dir, { instance: { addServer: true, serverHost: 'cryndel.ru', serverPort: 25565 } });
    expect(await fs.pathExists(path.join(dir, 'servers.dat'))).toBe(true);
    const { readServersDat } = require('../../electron/utils/nbt');
    const servers = readServersDat(await fs.readFile(path.join(dir, 'servers.dat')));
    expect(servers[0].ip).toBe('cryndel.ru');
    await fs.remove(dir);
  });
});

describe('ensureLanguageAsset', () => {
  test('downloads the language object when missing', async () => {
    const g = Object.create(EmberPilot.prototype);
    g.settings = { getAll: async () => ({ ui: { language: 'ru' } }) };
    const downloaded = [];
    g.downloadFile = async (url, dest) => { downloaded.push({ url, dest }); };
    const objects = { 'minecraft/lang/ru_ru.json': { hash: 'abcdef1234' } };
    await g.ensureLanguageAsset(objects);
    expect(downloaded).toHaveLength(1);
    expect(downloaded[0].url).toContain('ab/abcdef1234');
  });

  test('retries a failed language download', async () => {
    const g = Object.create(EmberPilot.prototype);
    g.settings = { getAll: async () => ({ ui: { language: 'ru' } }) };
    let calls = 0;
    g.downloadFile = async () => {
      calls += 1;
      if (calls < 3) throw new Error('network');
    };
    await g.ensureLanguageAsset({ 'minecraft/lang/ru_ru.json': { hash: 'ff00112233' } });
    expect(calls).toBe(3);
  });

  test('does nothing when the language object is absent', async () => {
    const g = Object.create(EmberPilot.prototype);
    g.settings = { getAll: async () => ({ ui: { language: 'ru' } }) };
    let called = false;
    g.downloadFile = async () => { called = true; };
    await g.ensureLanguageAsset({});
    expect(called).toBe(false);
  });
});
