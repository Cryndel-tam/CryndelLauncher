const fs = require('fs-extra');
const AdmZip = require('adm-zip');
const os = require('os');
const path = require('path');
const PluginForge = require('../../electron/managers/plugin-manager');

describe('plugin UI and capability permissions', () => {
  let root;
  let plugins;
  let oldHome;

  beforeEach(async () => {
    oldHome = process.env.CRYNDEL_HOME;
    root = await fs.mkdtemp(path.join(os.tmpdir(), 'cryndel-plugin-test-'));
    process.env.CRYNDEL_HOME = root;
    plugins = new PluginForge({
      settings: {
        get: async (key) => (key === 'ui.theme' ? 'dark' : undefined),
        set: jest.fn(async () => undefined)
      }
    });
    await plugins.ensure();
  });

  afterEach(async () => {
    await fs.remove(root);
    if (oldHome === undefined) delete process.env.CRYNDEL_HOME;
    else process.env.CRYNDEL_HOME = oldHome;
  });

  test('registers sandbox page only with the ui grant', () => {
    expect(() => plugins.registerUiPage('sample', { id: 'home', html: '<h1>Hi</h1>' }))
      .toThrow('Плагину не выдано разрешение ui');

    plugins.grants.set('sample', ['ui']);
    plugins.registerUiPage('sample', { id: 'home', title: 'Моя страница', html: '<h1>Hi</h1>' });
    expect(plugins.getUiContributions().pages).toEqual([
      expect.objectContaining({ pluginId: 'sample', id: 'home', title: 'Моя страница' })
    ]);
  });

  test('does not grant network access until the user accepts it', () => {
    expect(plugins.hasPermission('sample', 'net')).toBe(false);
    plugins.grants.set('sample', ['net']);
    expect(plugins.hasPermission('sample', 'net')).toBe(true);
  });

  test('installs a plugin ZIP wrapped in its own folder', async () => {
    const zipPath = path.join(root, 'sample.zip');
    const archive = new AdmZip();
    archive.addFile('sample-plugin/manifest.json', Buffer.from(JSON.stringify({
      id: 'sample',
      name: 'Sample',
      main: 'index.js',
      permissions: ['ui']
    })));
    archive.addFile('sample-plugin/index.js', Buffer.from('module.exports = { activate() {} };'));
    await fs.writeFile(zipPath, archive.toBuffer());

    const result = await plugins.installFromZip(zipPath, ['ui']);
    expect(result.ok).toBe(true);
    expect(await fs.pathExists(path.join(plugins.dir(), 'sample', 'manifest.json'))).toBe(true);
    expect(await fs.pathExists(path.join(plugins.dir(), 'sample', 'index.js'))).toBe(true);
    expect(plugins.grants.get('sample')).toEqual(['ui']);
  });

  test('rejects a main script path that escapes the plugin directory', async () => {
    const pluginDir = path.join(plugins.dir(), 'unsafe');
    await fs.ensureDir(pluginDir);
    await fs.writeJson(path.join(pluginDir, 'manifest.json'), {
      id: 'unsafe',
      api: 2,
      main: '../outside.js'
    });

    await expect(plugins.loadOne('unsafe'))
      .resolves.toEqual(expect.objectContaining({ ok: false, error: 'Путь main-файла выходит за пределы папки плагина' }));
  });

  test('accepts presentation CSS but rejects external resources', () => {
    plugins.grants.set('sample', ['ui.theme']);
    expect(plugins.setPluginTheme('sample', ':root { --accent: #6ad; }').ok).toBe(true);
    expect(() => plugins.setPluginTheme('sample', 'body { background: url(https://example.com/x); }'))
      .toThrow('CSS темы не должен загружать внешние ресурсы или код');
  });

  test('checks capability grants before reading or changing launcher settings', async () => {
    plugins.loaded.set('sample', { api: { ui: { toast: jest.fn() } } });
    await expect(plugins.callCapability('sample', 'settings.get', ['ui.theme']))
      .rejects.toThrow('Не выдано разрешение: settings.read');
    plugins.grants.set('sample', ['settings.read', 'settings.write']);
    await expect(plugins.callCapability('sample', 'settings.get', ['game.javaPath']))
      .rejects.toThrow('Этот раздел настроек недоступен плагинам');
    await expect(plugins.callCapability('sample', 'settings.set', ['ui.__proto__.theme', 'dark']))
      .rejects.toThrow('Недопустимый ключ настройки');
    await expect(plugins.callCapability('sample', 'settings.set', ['ui.theme', 'ocean']))
      .resolves.toEqual({ ok: true });
  });

  test('does not allow install requests without the install grant', async () => {
    plugins.loaded.set('sample', { api: { ui: { toast: jest.fn() } } });
    await expect(plugins.callCapability('sample', 'install.modrinth', ['instance', 'project']))
      .rejects.toThrow('Не выдано разрешение: install');
  });

  test('lists declared plugin mods only when install permission is granted', () => {
    plugins.loaded.set('sample', {
      manifest: {
        providedMods: [{
          id: 'demo_mod',
          name: 'Demo Mod',
          file: 'mods/demo.jar',
          loaders: ['fabric']
        }]
      }
    });
    expect(plugins.getPluginMods()).toEqual([]);
    plugins.grants.set('sample', ['install']);
    expect(plugins.getPluginMods()).toEqual([
      expect.objectContaining({ pluginId: 'sample', id: 'demo_mod', loaders: ['fabric'] })
    ]);
    expect(plugins.getPluginMods()[0].file).toBeUndefined();
  });

  test('copies only a plugin-local SVG when applying wallpaper', async () => {
    const pluginDir = path.join(plugins.dir(), 'sample');
    await fs.ensureDir(pluginDir);
    await fs.writeFile(path.join(pluginDir, 'wallpaper.svg'), '<svg><rect width="10" height="10" fill="#123456"/></svg>');
    plugins.grants.set('sample', ['wallpaper']);
    plugins.loaded.set('sample', { api: { ui: { toast: jest.fn() } } });

    await expect(plugins.callCapability('sample', 'wallpaper.set', ['wallpaper.svg']))
      .resolves.toEqual({ ok: true });
    expect(plugins.hub.settings.set).toHaveBeenCalledWith('ui.backgroundKind', 'image');
    expect(await fs.pathExists(path.join(root, 'data', 'plugin-wallpapers', 'sample.svg'))).toBe(true);
    await fs.writeFile(path.join(pluginDir, 'wallpaper.svg'), '<svg><script>alert(1)</script></svg>');
    await expect(plugins.callCapability('sample', 'wallpaper.set', ['wallpaper.svg']))
      .rejects.toThrow('SVG обоев содержит неподдерживаемые элементы');
  });

  test('installs a declared local mod only into a compatible build', async () => {
    const pluginDir = path.join(plugins.dir(), 'sample');
    await fs.ensureDir(path.join(pluginDir, 'mods'));
    await fs.writeFile(path.join(pluginDir, 'mods', 'demo.jar'), 'demo');
    const installPluginMod = jest.fn(async () => ({ ok: true, filename: 'demo_mod.jar' }));
    plugins.hub.instances = { get: async () => ({ id: 'instance', modLoader: 'fabric', mcVersion: '1.21.1' }) };
    plugins.hub.mods = { installPluginMod };
    plugins.hub.timeline = null;
    plugins.grants.set('sample', ['install']);
    plugins.loaded.set('sample', {
      manifest: {
        providedMods: [{
          id: 'demo_mod',
          name: 'Demo Mod',
          file: 'mods/demo.jar',
          loaders: ['fabric'],
          gameVersions: ['1.21.1']
        }]
      }
    });

    await expect(plugins.callCapability('sample', 'install.localMod', ['instance', 'demo_mod']))
      .resolves.toEqual({ ok: true, filename: 'demo_mod.jar' });
    expect(installPluginMod).toHaveBeenCalledWith(
      'instance',
      path.join(pluginDir, 'mods', 'demo.jar'),
      'demo_mod',
      'sample',
      'Demo Mod'
    );
    plugins.hub.instances.get = async () => ({ id: 'instance', modLoader: 'forge', mcVersion: '1.21.1' });
    await expect(plugins.callCapability('sample', 'install.localMod', ['instance', 'demo_mod']))
      .rejects.toThrow('Мод не поддерживает загрузчик forge');
  });
});
