const { suggestMemoryMb } = require('../../electron/managers/ram-advisor');

describe('suggestMemoryMb', () => {
  test('returns bounded recommendation', () => {
    const r = suggestMemoryMb();
    expect(r.totalMb).toBeGreaterThan(0);
    expect(r.recommendedMb).toBeGreaterThanOrEqual(2048);
    expect(r.recommendedMb).toBeLessThanOrEqual(8192);
    expect(r.recommendedMb).toBeLessThan(r.totalMb);
  });
});
