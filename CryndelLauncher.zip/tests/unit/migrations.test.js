const { migrateUsers, migrateInstances, migrateSettings } = require('../../electron/storage/migrations');

describe('migrations', () => {
  test('users v1 to v2', () => {
    const next = migrateUsers({ version: 1, users: [{ nick: 'A' }] });
    expect(next.version).toBe(2);
    expect(next.users[0].stats).toBeTruthy();
  });

  test('instances array to doc', () => {
    const next = migrateInstances([{ id: 'i', name: 'x' }]);
    expect(next.version).toBe(2);
    expect(next.instances[0].quickPlay).toBeTruthy();
  });

  test('settings merge keeps unknown', () => {
    const next = migrateSettings({ ui: { language: 'en' } });
    expect(next.version).toBe(16);
    expect(next.ui.language).toBe('en');
    expect(next.modrinth.enabled).toBe(true);
    // New interface/game knobs land with sane defaults so nothing reads undefined.
    expect(next.ui.density).toBe('normal');
    expect(next.ui.uiScale).toBe(100);
    expect(next.game.rawMouseInput).toBe(true);
    expect(next.ui.glassBlur).toBe(0);
    expect(next.game.smoothLighting).toBe(true);
    expect(next.game.clouds).toBe('default');
    expect(next.game.pauseOnLostFocus).toBe(true);
    expect(next.game.mouseSensitivityPct).toBe(100);
    expect(next.game.skinModel).toBe('default');
    expect(next.ui.navLabels).toBe(true);
    expect(next.ui.bgBlur).toBe(0);
    expect(next.ui.toastDuration).toBe(4200);
    expect(next.ui.dockPos).toBe('right');
    expect(next.ui.headerAutoHide).toBe(true);
    expect(next.ui.greetingEnabled).toBe(true);
    expect(next.ui.pluginsEnabled).toBe(true);
    expect(next.ui.homeButtons).toBe(true);
    expect(next.ui.musicAutoplay).toBe(false);
    expect(next.ui.ambientEffects).toBe(true);
    expect(next.ui.blurEffects).toBe(true);
    expect(next.ui.particleCount).toBe(28);
    expect(next.ui.animations).toBe(true);
    expect(next.ui.animationInteractions).toBe(true);
    expect(next.ui.animationNotifications).toBe(true);
    expect(next.ui.animationBackground).toBe(false);
    expect(next.ui.animationDuration).toBe(140);
    expect(next.ui.iconAnimations).toBe(true);
    expect(next.ui.pauseEffectsOnScroll).toBeUndefined();
    expect(next.ui.bgDim).toBe(0.72);
    expect(next.ui.bgVeil).toBe(0.8);
  });

  test('music autoplay defaults off and migrates existing installs to off', () => {
    const next = migrateSettings({
      version: 10,
      ui: { musicAutoplay: true }
    });
    expect(next.version).toBe(16);
    expect(next.ui.musicAutoplay).toBe(false);
  });

  test('explicit music autoplay preference is preserved after migration', () => {
    const next = migrateSettings({
      version: 11,
      ui: { musicAutoplay: true }
    });
    expect(next.ui.musicAutoplay).toBe(true);
  });

  test('light page animation is enabled by default when upgrading', () => {
    const next = migrateSettings({
      version: 13,
      ui: {
        animations: false,
        animationInteractions: false,
        animationNotifications: false,
        animationDuration: 500
      }
    });
    expect(next.version).toBe(16);
    expect(next.ui.animations).toBe(true);
    expect(next.ui.animationInteractions).toBe(false);
    expect(next.ui.animationNotifications).toBe(false);
    expect(next.ui.animationDuration).toBe(300);
  });

  test('night wallpaper defaults are brightened without overwriting custom values', () => {
    const defaults = migrateSettings({
      version: 14,
      ui: { theme: 'dark', bgDim: 0.55, bgVeil: 1 }
    });
    expect(defaults.ui.bgDim).toBe(0.72);
    expect(defaults.ui.bgVeil).toBe(0.8);

    const custom = migrateSettings({
      version: 14,
      ui: { theme: 'dark', bgDim: 0.4, bgVeil: 0.65 }
    });
    expect(custom.ui.bgDim).toBe(0.4);
    expect(custom.ui.bgVeil).toBe(0.65);
  });

  test('legacy tray-hide default becomes minimise, with restore on exit', () => {
    const next = migrateSettings({ version: 5, launcher: { hideToTrayOnLaunch: true, minimizeToTray: true } });
    expect(next.launcher.hideToTrayOnLaunch).toBe(false);
    expect(next.launcher.showOnGameExit).toBe(true);
    expect(next.game.autoAddServer).toBe(true);
  });

  test('legacy 80% browser zoom is reset to 100%', () => {
    const next = migrateSettings({ version: 3, browser: { zoom: 80 }, cabinet: { zoom: 80 } });
    expect(next.browser.zoom).toBe(100);
    expect(next.cabinet.zoom).toBe(100);
  });

  test('a deliberate zoom choice is preserved', () => {
    const next = migrateSettings({ version: 3, browser: { zoom: 125 } });
    expect(next.browser.zoom).toBe(125);
  });
});
